import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  TurfOwnerProfile,
  Turf,
  Slot,
  Booking,
  BookingSource,
  PaymentMethod,
  PaymentStatus,
  StaffAssignment,
  OwnerWallet,
  WithdrawalRequest,
  CancellationPolicy,
  Review,
  Dispute,
  AppNotification,
  PlatformSettings,
  OpenMatch,
  MatchParticipant,
  OpenMatchSkillLevel,
  OpenMatchStatus,
  Tournament,
  TournamentTeam,
  TournamentMatch,
  TournamentStatus,
  TournamentMatchStatus,
} from '../types';
import { ADMIN_LOGIN_EMAIL, ADMIN_LOGIN_PASSWORD, DEMO_USER_PASSWORD } from '../config/authConfig';
import { buildActivationEmail, buildPasswordResetEmail } from '../utils/emailTemplates';
import {
  INITIAL_USERS,
  INITIAL_OWNER_PROFILES,
  INITIAL_TURFS,
  INITIAL_SLOTS,
  INITIAL_BOOKINGS,
  INITIAL_STAFF_ASSIGNMENTS,
  INITIAL_WALLETS,
  INITIAL_WITHDRAWALS,
  INITIAL_CANCELLATION_POLICIES,
  INITIAL_REVIEWS,
  INITIAL_DISPUTES,
  INITIAL_NOTIFICATIONS,
  INITIAL_PLATFORM_SETTINGS,
  INITIAL_OPEN_MATCHES,
  INITIAL_MATCH_PARTICIPANTS,
  INITIAL_TOURNAMENTS,
  INITIAL_TOURNAMENT_TEAMS,
  INITIAL_TOURNAMENT_MATCHES,
  getTodayDateString,
} from '../data/mockData';

interface AppContextType {
  // Current active impersonated user & role
  currentUser: User;
  isAuthenticated: boolean;
  isSignInModalOpen: boolean;
  setIsSignInModalOpen: (open: boolean) => void;
  isGetStartedModalOpen: boolean;
  setIsGetStartedModalOpen: (open: boolean) => void;
  signInRolePreset?: UserRole;
  openSignInModal: (role?: UserRole) => void;
  openGetStartedModal: (role?: 'player' | 'turf_owner') => void;
  loginUser: (userId: string) => void;
  loginAsRole: (role: UserRole) => void;
  loginWithCredentials: (email: string, password: string) => { success: boolean; message: string };
  logoutUser: () => void;
  playerActiveTab: 'explore' | 'my_bookings' | 'favorites' | 'squads' | 'tournaments';
  setPlayerActiveTab: (tab: 'explore' | 'my_bookings' | 'favorites' | 'squads' | 'tournaments') => void;
  ownerActiveTab: 'bookings' | 'turfs' | 'slots' | 'staff' | 'wallet' | 'tournaments';
  setOwnerActiveTab: (tab: 'bookings' | 'turfs' | 'slots' | 'staff' | 'wallet' | 'tournaments') => void;
  adminActiveTab: 'approvals' | 'users' | 'withdrawals' | 'policy_engine' | 'settings' | 'reports' | 'bookings' | 'disputes' | 'tournaments';
  setAdminActiveTab: (tab: 'approvals' | 'users' | 'withdrawals' | 'policy_engine' | 'settings' | 'reports' | 'bookings' | 'disputes' | 'tournaments') => void;
  openOwnerManualBookingModal: boolean;
  setOpenOwnerManualBookingModal: (open: boolean) => void;
  openStaffManualBookingModal: boolean;
  setOpenStaffManualBookingModal: (open: boolean) => void;
  registerNewUser: (params: {
    name: string;
    email: string;
    phone: string;
    role: UserRole;
    businessName?: string;
    nidOrTradeLicense?: string;
    payoutMethod?: 'bkash' | 'nagad' | 'rocket' | 'bank_account';
    accountNumber?: string;
    password?: string;
  }) => User;
  verifyActivationCode: (code: string) => { success: boolean; message: string };
  resendActivationCode: () => { success: boolean; message: string };
  requestPasswordReset: (email: string) => { success: boolean; message: string };
  resetPasswordWithCode: (email: string, code: string, newPassword: string) => { success: boolean; message: string };
  switchUser: (userId: string) => void;
  switchRoleDirectly: (role: UserRole) => void;

  // Data
  users: User[];
  ownerProfiles: TurfOwnerProfile[];
  turfs: Turf[];
  slots: Slot[];
  bookings: Booking[];
  staffAssignments: StaffAssignment[];
  wallets: Record<string, OwnerWallet>;
  withdrawals: WithdrawalRequest[];
  cancellationPolicies: CancellationPolicy[];
  reviews: Review[];
  disputes: Dispute[];
  notifications: AppNotification[];
  settings: PlatformSettings;
  favorites: string[];

  // Section 49: Squads & Open Matches Data
  openMatches: OpenMatch[];
  matchParticipants: MatchParticipant[];

  // Section 50: Tournaments Data
  tournaments: Tournament[];
  tournamentTeams: TournamentTeam[];
  tournamentMatches: TournamentMatch[];

  // Actions: Booking & Slots
  lockSlot: (slotId: string) => boolean;
  lockSlots: (slotIds: string[]) => boolean;
  unlockSlot: (slotId: string) => void;
  unlockSlots: (slotIds: string[]) => void;
  createOnlineBooking: (slotId: string | string[], paymentMethod: PaymentMethod, addonSelections?: Array<{ addonId: string; quantity: number }>) => Booking | null;
  createManualBooking: (params: {
    turfId: string;
    slotId: string;
    customerName: string;
    customerPhone: string;
    paymentMethod: PaymentMethod;
    paymentStatus: PaymentStatus;
    paymentReference?: string;
    notes?: string;
  }) => Booking | null;
  cancelBooking: (bookingId: string, reason: string, isOwnerInitiated?: boolean) => { success: boolean; refundAmount: number; message: string };
  checkInBooking: (bookingId: string) => boolean;
  completeBooking: (bookingId: string) => boolean;
  toggleSlotBlock: (slotId: string) => void;
  addSlot: (turfId: string, date: string, startTime: string, endTime: string, price: number) => void;

  // Actions: Turf Management
  createTurf: (turfData: Omit<Turf, 'id' | 'createdAt' | 'rating' | 'reviewCount'>) => void;
  updateTurf: (turfId: string, updates: Partial<Turf>) => void;
  deleteTurf: (turfId: string) => { success: boolean; message: string };
  approveTurf: (turfId: string) => void;
  rejectTurf: (turfId: string) => void;

  // Actions: User & Staff Management
  approveOwner: (userId: string) => void;
  rejectOwner: (userId: string) => void;
  updateOwnerPayoutDetails: (updates: {
    payoutMethod: 'bkash' | 'nagad' | 'rocket' | 'bank_account';
    accountNumber: string;
    bankName?: string;
    branchName?: string;
    accountHolderName?: string;
  }) => { success: boolean; message: string };
  toggleUserSuspension: (userId: string) => void;
  createStaff: (name: string, email: string, phone: string, turfIds: string[], permissions: string[]) => void;
  updateStaffPermissions: (staffId: string, permissions: string[], turfIds: string[]) => void;

  // Actions: Financials & Withdrawals
  requestWithdrawal: (amount: number, payoutMethod: string, payoutDetails: string) => { success: boolean; message: string };
  approveWithdrawal: (withdrawalId: string, reference: string) => void;
  rejectWithdrawal: (withdrawalId: string, reason: string) => void;
  updatePlatformSettings: (updates: Partial<PlatformSettings>) => void;

  // Actions: Policy & Disputes & Reviews
  addCancellationPolicy: (policy: Omit<CancellationPolicy, 'id'>) => void;
  updateCancellationPolicy: (policyId: string, updates: Partial<CancellationPolicy>) => void;
  calculateRefund: (booking: Booking, isOwnerCancel?: boolean) => { refundPercentage: number; playerRefund: number; adminKeep: number; gatewayFeeDeducted: number };
  addReview: (bookingId: string, rating: number, comment: string) => void;
  raiseDispute: (bookingId: string, category: Dispute['category'], description: string) => void;
  resolveDispute: (disputeId: string, resolution: string) => void;
  toggleFavorite: (turfId: string) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;

  // Section 49: Squads & Open Matches Actions
  createOpenMatch: (params: {
    bookingId: string;
    skillLevel: OpenMatchSkillLevel;
    maxPlayers: number;
    notes?: string;
  }) => { success: boolean; message: string; match?: OpenMatch };
  updateOpenMatch: (matchId: string, updates: Partial<OpenMatch>) => void;
  cancelOpenMatch: (matchId: string) => { success: boolean; message: string };
  joinOpenMatch: (matchId: string) => { success: boolean; message: string };
  leaveOpenMatch: (matchId: string) => { success: boolean; message: string };
  removeMatchParticipant: (matchId: string, playerId: string) => { success: boolean; message: string };

  // Section 50: Tournaments Actions
  createTournament: (params: {
    turfId: string;
    name: string;
    sportType: string;
    format: string;
    startDate: string;
    endDate: string;
    maxTeams: number;
    entryFeeAmount?: number;
    prizePoolNote?: string;
    description: string;
  }) => Tournament;
  updateTournament: (id: string, updates: Partial<Tournament>) => void;
  cancelTournament: (id: string) => void;
  registerTournamentTeam: (tournamentId: string, teamName: string, rosterNotes?: string) => { success: boolean; message: string; team?: TournamentTeam };
  withdrawTournamentTeam: (tournamentId: string, teamId: string) => { success: boolean; message: string };
  addOrUpdateTournamentMatch: (tournamentId: string, matchData: {
    id?: string;
    roundName: string;
    teamAId?: string;
    teamBId?: string;
    teamAName?: string;
    teamBName?: string;
    scheduledDate: string;
    scheduledStartTime: string;
    scheduledEndTime: string;
    slotId?: string;
    scoreA?: number;
    scoreB?: number;
    winnerTeamId?: string;
    status?: TournamentMatchStatus;
  }) => TournamentMatch;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUserId, setCurrentUserId] = useState<string>('user-player-1');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [playerActiveTab, setPlayerActiveTab] = useState<'explore' | 'my_bookings' | 'favorites' | 'squads' | 'tournaments'>('explore');
  const [ownerActiveTab, setOwnerActiveTab] = useState<'bookings' | 'turfs' | 'slots' | 'staff' | 'wallet' | 'tournaments'>('bookings');
  const [adminActiveTab, setAdminActiveTab] = useState<'approvals' | 'users' | 'withdrawals' | 'policy_engine' | 'settings' | 'reports' | 'bookings' | 'disputes' | 'tournaments'>('approvals');
  const [openOwnerManualBookingModal, setOpenOwnerManualBookingModal] = useState<boolean>(false);
  const [openStaffManualBookingModal, setOpenStaffManualBookingModal] = useState<boolean>(false);
  const [isSignInModalOpen, setIsSignInModalOpen] = useState<boolean>(false);
  const [isGetStartedModalOpen, setIsGetStartedModalOpen] = useState<boolean>(false);
  const [signInRolePreset, setSignInRolePreset] = useState<UserRole | undefined>(undefined);
  const [ownerProfiles, setOwnerProfiles] = useState<TurfOwnerProfile[]>(INITIAL_OWNER_PROFILES);
  const [turfs, setTurfs] = useState<Turf[]>(INITIAL_TURFS);
  const [slots, setSlots] = useState<Slot[]>(() => {
    if (typeof window === 'undefined') return INITIAL_SLOTS;

    try {
      const storedSlots = window.sessionStorage.getItem('turfy-slot-state');
      if (storedSlots) {
        const parsedSlots = JSON.parse(storedSlots) as Slot[];
        if (Array.isArray(parsedSlots) && parsedSlots.length > 0) {
          return parsedSlots;
        }
      }
    } catch {
      // Ignore malformed session data and fall back to mock defaults.
    }

    return INITIAL_SLOTS;
  });
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [staffAssignments, setStaffAssignments] = useState<StaffAssignment[]>(INITIAL_STAFF_ASSIGNMENTS);
  const [wallets, setWallets] = useState<Record<string, OwnerWallet>>(INITIAL_WALLETS);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>(INITIAL_WITHDRAWALS);
  const [cancellationPolicies, setCancellationPolicies] = useState<CancellationPolicy[]>(INITIAL_CANCELLATION_POLICIES);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [disputes, setDisputes] = useState<Dispute[]>(INITIAL_DISPUTES);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [settings, setSettings] = useState<PlatformSettings>(INITIAL_PLATFORM_SETTINGS);
  const [favorites, setFavorites] = useState<string[]>(['turf-1']);
  const [passwordResetCodes, setPasswordResetCodes] = useState<Record<string, string>>({}); // email (lowercase) -> code

  // Section 49 & 50 State
  const [openMatches, setOpenMatches] = useState<OpenMatch[]>(INITIAL_OPEN_MATCHES);
  const [matchParticipants, setMatchParticipants] = useState<MatchParticipant[]>(INITIAL_MATCH_PARTICIPANTS);
  const [tournaments, setTournaments] = useState<Tournament[]>(INITIAL_TOURNAMENTS);
  const [tournamentTeams, setTournamentTeams] = useState<TournamentTeam[]>(INITIAL_TOURNAMENT_TEAMS);
  const [tournamentMatches, setTournamentMatches] = useState<TournamentMatch[]>(INITIAL_TOURNAMENT_MATCHES);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.sessionStorage.setItem('turfy-slot-state', JSON.stringify(slots));
    }
  }, [slots]);

  const currentUser = users.find((u) => u.id === currentUserId) || users[0];

  useEffect(() => {
    let cancelled = false;

    const loadTurfsFromApi = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/turfs');
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const result = await response.json();

        if (!cancelled && result?.success && Array.isArray(result.data)) {
          setTurfs(result.data);
        }
      } catch (error) {
        if (!cancelled) {
          console.warn('Unable to load turfs from backend, keeping mock data:', error);
        }
      }
    };

    loadTurfsFromApi();

    return () => {
      cancelled = true;
    };
  }, []);

  const switchUser = (userId: string) => {
    setCurrentUserId(userId);
    setIsAuthenticated(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const switchRoleDirectly = (role: UserRole) => {
    const userForRole = users.find((u) => u.role === role);
    if (userForRole) {
      setCurrentUserId(userForRole.id);
      setIsAuthenticated(true);
      if (role === 'player') {
        setPlayerActiveTab('my_bookings');
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const openSignInModal = (role?: UserRole) => {
    setSignInRolePreset(role);
    setIsGetStartedModalOpen(false);
    setIsSignInModalOpen(true);
  };

  const openGetStartedModal = (role?: 'player' | 'turf_owner') => {
    setIsSignInModalOpen(false);
    setIsGetStartedModalOpen(true);
  };

  const loginUser = (userId: string) => {
    const user = users.find((u) => u.id === userId);
    if (user) {
      setCurrentUserId(user.id);
      setIsAuthenticated(true);
      setIsSignInModalOpen(false);
      setIsGetStartedModalOpen(false);
      if (user.role === 'player') {
        setPlayerActiveTab('my_bookings');
      }
      sendNotification(
        user.id,
        user.role,
        'system',
        'Signed In Successfully',
        `Welcome back, ${user.name}! Active role: ${user.role.replace('_', ' ').toUpperCase()}`
      );
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const loginAsRole = (role: UserRole) => {
    const user = users.find((u) => u.role === role);
    if (user) {
      setCurrentUserId(user.id);
      setIsAuthenticated(true);
      setIsSignInModalOpen(false);
      setIsGetStartedModalOpen(false);
      if (role === 'player') {
        setPlayerActiveTab('my_bookings');
      }
      sendNotification(
        user.id,
        user.role,
        'system',
        'Role Activated',
        `Switched to ${role.replace('_', ' ').toUpperCase()} workspace (${user.name})`
      );
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const loginWithCredentials = (email: string, password: string): { success: boolean; message: string } => {
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedEmail || !password) {
      return { success: false, message: 'Please enter both email and password.' };
    }

    // Admin login is validated strictly against the configurable admin credentials.
    if (trimmedEmail === ADMIN_LOGIN_EMAIL.toLowerCase()) {
      if (password !== ADMIN_LOGIN_PASSWORD) {
        return { success: false, message: 'Incorrect admin password.' };
      }
      const adminUser = users.find((u) => u.role === 'admin');
      if (!adminUser) {
        return { success: false, message: 'Admin account is not configured.' };
      }
      loginUser(adminUser.id);
      return { success: true, message: `Welcome back, ${adminUser.name}.` };
    }

    const account = users.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (!account) {
      return { success: false, message: 'No account found for this email.' };
    }

    if (account.role === 'admin') {
      return { success: false, message: 'Please use the configured admin email to sign in.' };
    }

    const expectedPassword = account.password || DEMO_USER_PASSWORD;
    if (password !== expectedPassword) {
      return { success: false, message: 'Incorrect password.' };
    }

    if (account.status === 'suspended' || account.status === 'deactivated') {
      return { success: false, message: 'This account has been suspended. Contact support.' };
    }

    loginUser(account.id);
    return { success: true, message: `Welcome back, ${account.name}.` };
  };

  const logoutUser = () => {
    setIsAuthenticated(false);
    const defaultPlayer = users.find((u) => u.role === 'player') || users[0];
    setCurrentUserId(defaultPlayer.id);
    setIsSignInModalOpen(false);
    setIsGetStartedModalOpen(false);
    setPlayerActiveTab('explore');
    sendNotification(defaultPlayer.id, 'player', 'system', 'Signed Out', 'You are now browsing in Guest Mode.');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Sends a branded transactional email via the first active SMTP config in Admin Settings.
  const sendTransactionalEmail = async (toEmail: string, subject: string, html: string) => {
    const smtp = (settings.smtpConfigs || []).find((c) => c.isActive);
    if (!smtp) return;
    try {
      await fetch('http://localhost:5000/api/email/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...smtp, toEmail, subject, html }),
      });
    } catch {
      // Best-effort: email server may not be running locally; ignore network errors here.
    }
  };

  const generateSixDigitCode = () => String(Math.floor(100000 + Math.random() * 900000));

  const registerNewUser = (params: {
    name: string;
    email: string;
    phone: string;
    role: UserRole;
    businessName?: string;
    nidOrTradeLicense?: string;
    payoutMethod?: 'bkash' | 'nagad' | 'rocket' | 'bank_account';
    accountNumber?: string;
    password?: string;
  }): User => {
    const newId = `user-${params.role}-${Date.now().toString().slice(-4)}`;
    const avatar =
      params.role === 'player'
        ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
        : params.role === 'turf_owner'
        ? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'
        : params.role === 'staff'
        ? 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150'
        : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150';

    const activationCode = generateSixDigitCode();

    const newUser: User = {
      id: newId,
      name: params.name,
      email: params.email,
      phone: params.phone,
      role: params.role,
      status: params.role === 'turf_owner' ? 'pending_approval' : 'active',
      avatar,
      createdAt: new Date().toISOString(),
      password: params.password || DEMO_USER_PASSWORD,
      emailVerified: false,
      activationCode,
    };

    setUsers((prev) => [newUser, ...prev]);

    if (params.role === 'turf_owner') {
      const newProfile: TurfOwnerProfile = {
        id: `profile-${Date.now().toString().slice(-4)}`,
        userId: newId,
        businessName: params.businessName || `${params.name}'s Sports Venue`,
        nidOrTradeLicense: params.nidOrTradeLicense || 'TRAD/DNCC/098765/2026',
        payoutMethod: params.payoutMethod || 'bkash',
        payoutDetails: {
          accountNumber: params.accountNumber || params.phone,
          accountHolderName: params.name,
        },
        approvalStatus: 'pending_approval',
      };
      setOwnerProfiles((prev) => [newProfile, ...prev]);

      setWallets((prev) => ({
        ...prev,
        [newId]: {
          ownerId: newId,
          availableBalance: 0,
          heldBalance: 0,
          totalEarnings: 0,
          totalWithdrawn: 0,
        },
      }));
    }

    setCurrentUserId(newId);
    setIsAuthenticated(true);
    setIsGetStartedModalOpen(false);
    setIsSignInModalOpen(false);

    sendNotification(
      newId,
      params.role,
      'system',
      'Account Created',
      `Welcome to Turfyslot, ${params.name}! Your ${params.role.replace('_', ' ').toUpperCase()} profile is created.`
    );

    const activationEmail = buildActivationEmail(params.name, activationCode);
    sendTransactionalEmail(params.email, activationEmail.subject, activationEmail.html);

    return newUser;
  };

  const verifyActivationCode = (code: string): { success: boolean; message: string } => {
    if (currentUser.emailVerified) {
      return { success: true, message: 'Your email is already verified.' };
    }
    if (!code.trim() || code.trim() !== currentUser.activationCode) {
      return { success: false, message: 'Invalid activation code. Please check your email and try again.' };
    }
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, emailVerified: true, activationCode: undefined } : u))
    );
    return { success: true, message: 'Email verified successfully! Your account is now fully activated.' };
  };

  const resendActivationCode = (): { success: boolean; message: string } => {
    if (currentUser.emailVerified) {
      return { success: false, message: 'Your email is already verified.' };
    }
    const newCode = generateSixDigitCode();
    setUsers((prev) => prev.map((u) => (u.id === currentUser.id ? { ...u, activationCode: newCode } : u)));
    const activationEmail = buildActivationEmail(currentUser.name, newCode);
    sendTransactionalEmail(currentUser.email, activationEmail.subject, activationEmail.html);
    return { success: true, message: `A new activation code was sent to ${currentUser.email}.` };
  };

  const requestPasswordReset = (email: string): { success: boolean; message: string } => {
    const trimmedEmail = email.trim().toLowerCase();
    const account = users.find((u) => u.email.toLowerCase() === trimmedEmail);
    if (!account) {
      return { success: false, message: 'No account found for this email.' };
    }
    const code = generateSixDigitCode();
    setPasswordResetCodes((prev) => ({ ...prev, [trimmedEmail]: code }));
    const resetEmail = buildPasswordResetEmail(account.name, code);
    sendTransactionalEmail(account.email, resetEmail.subject, resetEmail.html);
    return { success: true, message: `A password reset code was sent to ${account.email}.` };
  };

  const resetPasswordWithCode = (email: string, code: string, newPassword: string): { success: boolean; message: string } => {
    const trimmedEmail = email.trim().toLowerCase();
    const expectedCode = passwordResetCodes[trimmedEmail];
    if (!expectedCode || expectedCode !== code.trim()) {
      return { success: false, message: 'Invalid or expired reset code.' };
    }
    if (newPassword.trim().length < 8) {
      return { success: false, message: 'Password must be at least 8 characters long.' };
    }
    setUsers((prev) =>
      prev.map((u) => (u.email.toLowerCase() === trimmedEmail ? { ...u, password: newPassword.trim() } : u))
    );
    setPasswordResetCodes((prev) => {
      const next = { ...prev };
      delete next[trimmedEmail];
      return next;
    });
    return { success: true, message: 'Password reset successfully. You can now sign in with your new password.' };
  };


  // Add Notification Helper
  const sendNotification = (userId: string, role: UserRole, type: AppNotification['type'], title: string, message: string) => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId,
      role,
      type,
      title,
      message,
      read: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Slot Locking with 10-Minute TTL
  const lockSlot = (slotId: string): boolean => {
    const slot = slots.find((s) => s.id === slotId);
    if (!slot || slot.status !== 'available') return false;

    const lockedUntil = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    setSlots((prev) =>
      prev.map((s) => (s.id === slotId ? { ...s, status: 'locked', lockedUntil, lockedByUserId: currentUser.id } : s))
    );
    return true;
  };

  const lockSlots = (slotIds: string[]): boolean => {
    if (slotIds.length === 0) return false;

    const shouldLock = slotIds.every((slotId) => {
      const slot = slots.find((s) => s.id === slotId);
      return !!slot && slot.status === 'available';
    });

    if (!shouldLock) return false;

    const lockedUntil = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    setSlots((prev) =>
      prev.map((s) =>
        slotIds.includes(s.id)
          ? { ...s, status: 'locked', lockedUntil, lockedByUserId: currentUser.id }
          : s
      )
    );
    return true;
  };

  const unlockSlot = (slotId: string) => {
    setSlots((prev) =>
      prev.map((s) => (s.id === slotId && s.status === 'locked' ? { ...s, status: 'available', lockedUntil: undefined, lockedByUserId: undefined } : s))
    );
  };

  const unlockSlots = (slotIds: string[]) => {
    if (slotIds.length === 0) return;

    setSlots((prev) =>
      prev.map((s) =>
        slotIds.includes(s.id) && s.status === 'locked'
          ? { ...s, status: 'available', lockedUntil: undefined, lockedByUserId: undefined }
          : s
      )
    );
  };

  // Resolve Cancellation Policy for a given turf
  const resolvePolicyForTurf = (turfId: string): CancellationPolicy => {
    const turf = turfs.find((t) => t.id === turfId);
    if (turf?.cancellationPolicyId) {
      const p = cancellationPolicies.find((cp) => cp.id === turf.cancellationPolicyId);
      if (p) return p;
    }
    const defaultP = cancellationPolicies.find((cp) => cp.isDefault);
    return defaultP || cancellationPolicies[0];
  };

  // Calculate Refund Matrix (Section 10.3 & Section 47)
  const calculateRefund = (booking: Booking, isOwnerCancel = false) => {
    if (isOwnerCancel) {
      // Owner-initiated cancellation: ALWAYS 100% refund of base amount + platform fee.
      // SSLCommerz payment gateway fee is kept by gateway and never refundable.
      const playerRefund = booking.baseAmount + (booking.bookingSource === 'online' ? booking.platformFeeAmount : 0);
      return {
        refundPercentage: 100,
        playerRefund,
        adminKeep: 0,
        gatewayFeeDeducted: booking.gatewayFeeAmount,
      };
    }

    // Player-initiated cancellation: resolved via hours remaining before slot start
    const policy = resolvePolicyForTurf(booking.turfId);
    const slotDate = new Date(`${booking.date}T${booking.startTime}:00`);
    const now = new Date();
    const hoursRemaining = Math.max(0, (slotDate.getTime() - now.getTime()) / (1000 * 60 * 60));

    let matchedTier = policy.tiers.find((tier) => {
      const min = tier.minHoursBefore;
      const max = tier.maxHoursBefore ?? 99999;
      return hoursRemaining >= min && hoursRemaining < max;
    });

    if (!matchedTier && hoursRemaining >= 24) {
      matchedTier = policy.tiers.find((t) => t.refundPercentage === 100) || policy.tiers[0];
    } else if (!matchedTier) {
      matchedTier = policy.tiers[policy.tiers.length - 1];
    }

    const refundPercentage = matchedTier?.refundPercentage ?? 0;
    const baseRefund = (booking.baseAmount * refundPercentage) / 100;

    let playerRefund = 0;
    let adminKeep = booking.platformFeeAmount;

    if (booking.bookingSource === 'online') {
      // Online booking: Gateway fee non-refundable, platform fee kept by admin
      playerRefund = baseRefund;
    } else {
      // Manual booking: No gateway fee exists. Platform fee is non-refundable on player cancellation
      playerRefund = Math.max(0, baseRefund - booking.platformFeeAmount);
    }

    return {
      refundPercentage,
      playerRefund,
      adminKeep,
      gatewayFeeDeducted: booking.gatewayFeeAmount,
    };
  };

  // Create Online Booking (Section 10.1 & 10.2)
  const createOnlineBooking = (
    slotId: string | string[],
    paymentMethod: PaymentMethod = 'sslcommerz',
    addonSelections: Array<{ addonId: string; quantity: number }> = []
  ): Booking | null => {
    const selectedSlotIds = Array.isArray(slotId) ? slotId : [slotId];
    const selectedSlots = selectedSlotIds
      .map((id) => slots.find((s) => s.id === id))
      .filter((slot): slot is Slot => !!slot);

    if (selectedSlots.length === 0) return null;

    const turf = turfs.find((t) => t.id === selectedSlots[0].turfId);
    if (!turf) return null;

    const selectedAddons = (turf.addons || [])
      .filter((addon) => addon.isActive)
      .map((addon) => {
        const quantity = addonSelections.find((item) => item.addonId === addon.id)?.quantity ?? 0;
        if (quantity <= 0) return null;

        return {
          id: `booking-addon-${Date.now()}-${addon.id}`,
          addonId: addon.id,
          name: addon.name,
          price: addon.price,
          quantity,
          totalPrice: addon.price * quantity,
          category: addon.category,
        };
      })
      .filter(Boolean) as Booking['bookingAddons'];

    const baseAmount = selectedSlots.reduce((sum, slot) => sum + slot.price, 0);
    const addonTotal = selectedAddons.reduce((sum, item) => sum + item.totalPrice, 0);
    const subtotal = baseAmount + addonTotal;
    const commissionRate = turf.commissionRateOverride ?? settings.globalCommissionRate;
    const platformFeeRate = settings.platformFeeRate;
    const gatewayFeeRate = settings.gatewayFeeRate;

    const commissionAmount = Math.round((subtotal * commissionRate) / 100);
    const platformFeeAmount = Math.round((subtotal * platformFeeRate) / 100);
    const gatewayFeeAmount = Math.round(((subtotal + platformFeeAmount) * gatewayFeeRate) / 100);
    const totalPaid = subtotal + platformFeeAmount + gatewayFeeAmount;
    const netOwnerAmount = subtotal - commissionAmount;

    const bookingNumber = `TS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newBooking: Booking = {
      id: `booking-${Date.now()}`,
      bookingNumber,
      playerId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      customerEmail: currentUser.email,
      turfId: turf.id,
      turfName: turf.name,
      slotId: selectedSlots[0].id,
      slotIds: selectedSlotIds,
      date: selectedSlots[0].date,
      startTime: selectedSlots[0].startTime,
      endTime: selectedSlots[selectedSlots.length - 1].endTime,
      totalHours: selectedSlots.length,
      bookingSource: 'online',
      status: 'confirmed',
      baseAmount,
      addonTotal,
      bookingAddons: selectedAddons,
      commissionAmount,
      platformFeeAmount,
      hasGatewayFee: true,
      gatewayFeeAmount,
      totalPaid,
      netOwnerAmount,
      paymentMethod,
      paymentStatus: 'paid',
      paymentReference: `SSL-TXN-${Date.now().toString().slice(-8)}`,
      qrCode: `QR_${bookingNumber}_VALID`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Update selected slots to booked
    setSlots((prev) =>
      prev.map((s) =>
        selectedSlotIds.includes(s.id)
          ? { ...s, status: 'booked', lockedUntil: undefined, lockedByUserId: undefined }
          : s
      )
    );
    setBookings((prev) => [newBooking, ...prev]);

    // Update Turf Owner Wallet: Add to held balance (in active cancellation window)
    setWallets((prev) => {
      const ownerWallet = prev[turf.ownerId] || {
        ownerId: turf.ownerId,
        availableBalance: 0,
        heldBalance: 0,
        totalEarnings: 0,
        totalWithdrawn: 0,
      };
      return {
        ...prev,
        [turf.ownerId]: {
          ...ownerWallet,
          heldBalance: ownerWallet.heldBalance + netOwnerAmount,
          totalEarnings: ownerWallet.totalEarnings + netOwnerAmount,
        },
      };
    });

    // Notify Player & Owner
    sendNotification(
      currentUser.id,
      'player',
      'booking',
      'Booking Confirmed!',
      `Booking ${bookingNumber} for ${turf.name} on ${selectedSlots[0].date} (${selectedSlots[0].startTime}) is confirmed. Show QR at counter.`
    );
    sendNotification(
      turf.ownerId,
      'turf_owner',
      'payment',
      'New Online Booking',
      `${currentUser.name} booked ${turf.name} for ${selectedSlots[0].date} (${selectedSlots[0].startTime}). Net: ৳${netOwnerAmount}.`
    );

    return newBooking;
  };

  // Create Manual / Offline Booking (Section 7.4 & 47.13)
  const createManualBooking = ({
    turfId,
    slotId,
    customerName,
    customerPhone,
    paymentMethod,
    paymentStatus,
    paymentReference,
    notes,
  }: {
    turfId: string;
    slotId: string;
    customerName: string;
    customerPhone: string;
    paymentMethod: PaymentMethod;
    paymentStatus: PaymentStatus;
    paymentReference?: string;
    notes?: string;
  }): Booking | null => {
    const slot = slots.find((s) => s.id === slotId);
    if (!slot) return null;
    const turf = turfs.find((t) => t.id === turfId);
    if (!turf) return null;

    const baseAmount = slot.price;
    const commissionRate = turf.commissionRateOverride ?? settings.globalCommissionRate;
    const platformFeeRate = settings.platformFeeRate;

    const commissionAmount = Math.round((baseAmount * commissionRate) / 100);
    const platformFeeAmount = Math.round((baseAmount * platformFeeRate) / 100);
    // Manual bookings have NO SSLCommerz gateway fee (0 TK)!
    const gatewayFeeAmount = 0;
    const totalPaid = baseAmount + platformFeeAmount;
    const netOwnerAmount = baseAmount - commissionAmount;

    const bookingSource: BookingSource = currentUser.role === 'staff' ? 'manual_staff' : currentUser.role === 'admin' ? 'admin' : 'manual_owner';
    const bookingNumber = `TS-MN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newBooking: Booking = {
      id: `booking-${Date.now()}`,
      bookingNumber,
      customerName,
      customerPhone,
      turfId: turf.id,
      turfName: turf.name,
      slotId: slot.id,
      date: slot.date,
      startTime: slot.startTime,
      endTime: slot.endTime,
      bookingSource,
      status: 'confirmed',
      baseAmount,
      commissionAmount,
      platformFeeAmount,
      hasGatewayFee: false,
      gatewayFeeAmount: 0,
      totalPaid,
      netOwnerAmount,
      paymentMethod,
      paymentStatus,
      paymentReference: paymentReference || `MANUAL-${Date.now().toString().slice(-6)}`,
      notes,
      qrCode: `QR_${bookingNumber}_MANUAL`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setSlots((prev) => prev.map((s) => (s.id === slotId ? { ...s, status: 'booked', lockedUntil: undefined, lockedByUserId: undefined } : s)));
    setBookings((prev) => [newBooking, ...prev]);

    // Update Owner Wallet: manual bookings are collected offline by owner
    setWallets((prev) => {
      const ownerWallet = prev[turf.ownerId] || {
        ownerId: turf.ownerId,
        availableBalance: 0,
        heldBalance: 0,
        totalEarnings: 0,
        totalWithdrawn: 0,
      };
      return {
        ...prev,
        [turf.ownerId]: {
          ...ownerWallet,
          heldBalance: ownerWallet.heldBalance + netOwnerAmount,
          totalEarnings: ownerWallet.totalEarnings + netOwnerAmount,
        },
      };
    });

    sendNotification(
      turf.ownerId,
      'turf_owner',
      'booking',
      'Manual Booking Created',
      `Manual entry ${bookingNumber} created for ${customerName} (${slot.date} ${slot.startTime}). Source: ${bookingSource}.`
    );

    return newBooking;
  };

  // Cancel Booking with Refund Logic
  const cancelBooking = (bookingId: string, reason: string, isOwnerInitiated = false) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return { success: false, refundAmount: 0, message: 'Booking not found' };

    // Owner-controlled cancellation cutoff: player cannot self-cancel too close to slot start
    if (!isOwnerInitiated) {
      const turf = turfs.find((t) => t.id === booking.turfId);
      const cutoffHours = turf?.cancellationCutoffHours ?? settings.defaultCancellationWindowHours ?? 3;
      const slotStart = new Date(`${booking.date}T${booking.startTime}:00`);
      const hoursRemaining = (slotStart.getTime() - Date.now()) / (1000 * 60 * 60);

      if (hoursRemaining < cutoffHours) {
        return {
          success: false,
          refundAmount: 0,
          message: `Cancellation window has closed. This turf requires cancellation at least ${cutoffHours} hour(s) before the slot start time.`,
        };
      }
    }

    const refundCalc = calculateRefund(booking, isOwnerInitiated);

    setBookings((prev) =>
      prev.map((b) =>
        b.id === bookingId
          ? {
              ...b,
              status: refundCalc.playerRefund > 0 ? 'refunded' : 'cancelled',
              cancellationReason: reason,
              cancelledBy: currentUser.id,
              cancelledAt: new Date().toISOString(),
              refundAmount: refundCalc.playerRefund,
              updatedAt: new Date().toISOString(),
            }
          : b
      )
    );

    // Release slot back to available
    setSlots((prev) => prev.map((s) => (s.id === booking.slotId ? { ...s, status: 'available' } : s)));

    // Reconcile Wallet: Deduct net owner amount from held or available balance
    setWallets((prev) => {
      const ownerWallet = prev[booking.turfId] || prev['user-owner-1'];
      if (!ownerWallet) return prev;
      return {
        ...prev,
        [ownerWallet.ownerId]: {
          ...ownerWallet,
          heldBalance: Math.max(0, ownerWallet.heldBalance - booking.netOwnerAmount),
          totalEarnings: Math.max(0, ownerWallet.totalEarnings - booking.netOwnerAmount),
        },
      };
    });

    if (booking.playerId) {
      sendNotification(
        booking.playerId,
        'player',
        'refund',
        `Booking ${booking.bookingNumber} Cancelled`,
        `Refund of ৳${refundCalc.playerRefund} processed according to policy (${refundCalc.refundPercentage}% tier).`
      );
    }

    // Section 49.4 Rule 5: If captain cancels underlying booking, Open Match auto-cancels and participants are notified
    setOpenMatches((prev) =>
      prev.map((m) => {
        if (m.bookingId === bookingId && m.status !== 'cancelled') {
          const participants = matchParticipants.filter((p) => p.matchId === m.id && p.status === 'joined' && p.playerId !== currentUser.id);
          participants.forEach((p) => {
            sendNotification(
              p.playerId,
              'player',
              'booking',
              'Open Match Cancelled',
              `The captain cancelled the booking for ${m.turfName} (${m.date} ${m.startTime}). As per terms, payments are settled directly with the captain.`
            );
          });
          return { ...m, status: 'cancelled', updatedAt: new Date().toISOString() };
        }
        return m;
      })
    );

    return {
      success: true,
      refundAmount: refundCalc.playerRefund,
      message: `Booking cancelled successfully. ৳${refundCalc.playerRefund} refund calculated.`,
    };
  };

  // Check In & Complete
  const checkInBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'checked_in', updatedAt: new Date().toISOString() } : b))
    );
    return true;
  };

  const completeBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => {
        if (b.id === bookingId) {
          // Release held funds to available balance upon completion
          setWallets((wPrev) => {
            const w = wPrev[b.turfId] || wPrev['user-owner-1'];
            if (!w) return wPrev;
            return {
              ...wPrev,
              [w.ownerId]: {
                ...w,
                heldBalance: Math.max(0, w.heldBalance - b.netOwnerAmount),
                availableBalance: w.availableBalance + b.netOwnerAmount,
              },
            };
          });
          return { ...b, status: 'completed', updatedAt: new Date().toISOString() };
        }
        return b;
      })
    );
    return true;
  };

  // Slot Management
  const toggleSlotBlock = (slotId: string) => {
    setSlots((prev) =>
      prev.map((s) => {
        if (s.id === slotId) {
          if (s.status === 'booked') return s; // Cannot block booked slot directly
          return { ...s, status: s.status === 'blocked' ? 'available' : 'blocked' };
        }
        return s;
      })
    );
  };

  const addSlot = (turfId: string, date: string, startTime: string, endTime: string, price: number) => {
    const newSlot: Slot = {
      id: `slot-${Date.now()}`,
      turfId,
      date,
      startTime,
      endTime,
      price,
      status: 'available',
    };
    setSlots((prev) => [...prev, newSlot]);
  };

  // Turf Management
  const createTurf = (turfData: Omit<Turf, 'id' | 'createdAt' | 'rating' | 'reviewCount'>) => {
    const newTurf: Turf = {
      ...turfData,
      id: `turf-${Date.now()}`,
      rating: 0,
      reviewCount: 0,
      createdAt: new Date().toISOString(),
      status: 'pending_review', // Needs admin approval per Section 7.2
    };
    setTurfs((prev) => [newTurf, ...prev]);

    // Send notification to admin
    sendNotification(
      'user-admin-1',
      'admin',
      'approval',
      'New Turf Submission',
      `${turfData.name} by ${turfData.ownerName} was submitted for review.`
    );
  };

  const updateTurf = (turfId: string, updates: Partial<Turf>) => {
    setTurfs((prev) => prev.map((t) => (t.id === turfId ? { ...t, ...updates } : t)));
  };

  const deleteTurf = (turfId: string): { success: boolean; message: string } => {
    const turf = turfs.find((t) => t.id === turfId);
    if (!turf) return { success: false, message: 'Turf not found.' };

    const hasActiveBookings = bookings.some(
      (b) => b.turfId === turfId && ['pending_payment', 'confirmed', 'checked_in'].includes(b.status)
    );
    if (hasActiveBookings) {
      return {
        success: false,
        message: 'This turf has active or upcoming bookings. Cancel or complete them before deleting.',
      };
    }

    setTurfs((prev) => prev.filter((t) => t.id !== turfId));
    setSlots((prev) => prev.filter((s) => s.turfId !== turfId));

    return { success: true, message: `"${turf.name}" was deleted successfully.` };
  };

  const approveTurf = (turfId: string) => {
    setTurfs((prev) => prev.map((t) => (t.id === turfId ? { ...t, status: 'active' } : t)));
    const turf = turfs.find((t) => t.id === turfId);
    if (turf) {
      sendNotification(turf.ownerId, 'turf_owner', 'approval', 'Turf Approved!', `Your turf "${turf.name}" is now live and publicly bookable.`);
    }
  };

  const rejectTurf = (turfId: string) => {
    setTurfs((prev) => prev.map((t) => (t.id === turfId ? { ...t, status: 'inactive' } : t)));
  };

  // Owner & User Management
  const approveOwner = (userId: string) => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, status: 'active' } : u)));
    setOwnerProfiles((prev) =>
      prev.map((p) =>
        p.userId === userId
          ? { ...p, approvalStatus: 'active', approvedBy: currentUser.id, approvedAt: new Date().toISOString() }
          : p
      )
    );
    sendNotification(userId, 'turf_owner', 'approval', 'Account Approved!', 'Your turf owner account is verified. You can now list turfs.');
  };

  const rejectOwner = (userId: string) => {
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, status: 'suspended' } : u)));
    setOwnerProfiles((prev) => prev.map((p) => (p.userId === userId ? { ...p, approvalStatus: 'rejected' } : p)));
  };

  // Owner updates their own payout method (bank account / bKash / Nagad / Rocket)
  const updateOwnerPayoutDetails = (updates: {
    payoutMethod: 'bkash' | 'nagad' | 'rocket' | 'bank_account';
    accountNumber: string;
    bankName?: string;
    branchName?: string;
    accountHolderName?: string;
  }): { success: boolean; message: string } => {
    const profile = ownerProfiles.find((p) => p.userId === currentUser.id);
    if (!profile) return { success: false, message: 'Owner profile not found.' };
    if (!updates.accountNumber.trim()) {
      return { success: false, message: 'Please enter a valid account / wallet number.' };
    }

    setOwnerProfiles((prev) =>
      prev.map((p) =>
        p.userId === currentUser.id
          ? {
              ...p,
              payoutMethod: updates.payoutMethod,
              payoutDetails: {
                accountNumber: updates.accountNumber.trim(),
                bankName: updates.payoutMethod === 'bank_account' ? updates.bankName : undefined,
                branchName: updates.payoutMethod === 'bank_account' ? updates.branchName : undefined,
                accountHolderName: updates.accountHolderName || p.payoutDetails.accountHolderName,
              },
            }
          : p
      )
    );

    return { success: true, message: 'Payout details updated successfully.' };
  };

  const toggleUserSuspension = (userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: u.status === 'suspended' ? 'active' : 'suspended' } : u))
    );
  };

  // Staff Management
  const createStaff = (name: string, email: string, phone: string, turfIds: string[], permissions: string[]) => {
    const staffId = `user-staff-${Date.now()}`;
    const newStaffUser: User = {
      id: staffId,
      name,
      email,
      phone,
      role: 'staff',
      status: 'active',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString(),
    };

    const newAssignment: StaffAssignment = {
      id: `staff-assign-${Date.now()}`,
      staffUserId: staffId,
      staffName: name,
      staffEmail: email,
      staffPhone: phone,
      ownerId: currentUser.id,
      turfIds,
      permissions,
      status: 'pending_setup',
      invitedAt: new Date().toISOString(),
      setupLink: `/staff/setup?email=${encodeURIComponent(email)}`,
      createdAt: new Date().toISOString(),
    };

    setUsers((prev) => [...prev, newStaffUser]);
    setStaffAssignments((prev) => [...prev, newAssignment]);
    sendNotification(currentUser.id, 'turf_owner', 'system', 'Staff Member Added', `${name} was assigned with ${permissions.length} permissions.`);
  };

  const updateStaffPermissions = (staffId: string, permissions: string[], turfIds: string[]) => {
    setStaffAssignments((prev) =>
      prev.map((sa) => (sa.staffUserId === staffId ? { ...sa, permissions, turfIds } : sa))
    );
  };

  // Withdrawals
  const requestWithdrawal = (amount: number, payoutMethod: string, payoutDetails: string) => {
    const wallet = wallets[currentUser.id];
    if (!wallet) return { success: false, message: 'Wallet not found' };
    if (amount < settings.minWithdrawalAmount) {
      return { success: false, message: `Minimum withdrawal amount is ৳${settings.minWithdrawalAmount}` };
    }
    if (amount > wallet.availableBalance) {
      return { success: false, message: `Requested amount exceeds available balance of ৳${wallet.availableBalance}` };
    }

    const newRequest: WithdrawalRequest = {
      id: `wd-${Date.now()}`,
      ownerId: currentUser.id,
      ownerName: currentUser.name,
      businessName: ownerProfiles.find((p) => p.userId === currentUser.id)?.businessName || 'Owner',
      amount,
      payoutMethod,
      payoutDetails,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    // Hold funds
    setWallets((prev) => ({
      ...prev,
      [currentUser.id]: {
        ...wallet,
        availableBalance: wallet.availableBalance - amount,
      },
    }));

    setWithdrawals((prev) => [newRequest, ...prev]);
    sendNotification(
      'user-admin-1',
      'admin',
      'system',
      'New Withdrawal Request',
      `${currentUser.name} requested payout of ৳${amount.toLocaleString()} via ${payoutMethod}.`
    );

    return { success: true, message: `Withdrawal request for ৳${amount.toLocaleString()} submitted for admin review.` };
  };

  const approveWithdrawal = (withdrawalId: string, reference: string) => {
    setWithdrawals((prev) =>
      prev.map((w) =>
        w.id === withdrawalId
          ? {
              ...w,
              status: 'paid',
              reference,
              reviewedBy: currentUser.id,
              reviewedAt: new Date().toISOString(),
            }
          : w
      )
    );

    const wd = withdrawals.find((w) => w.id === withdrawalId);
    if (wd) {
      setWallets((prev) => {
        const ownerW = prev[wd.ownerId];
        if (!ownerW) return prev;
        return {
          ...prev,
          [wd.ownerId]: {
            ...ownerW,
            totalWithdrawn: ownerW.totalWithdrawn + wd.amount,
          },
        };
      });
      sendNotification(wd.ownerId, 'turf_owner', 'payment', 'Withdrawal Approved & Paid', `Payout of ৳${wd.amount} sent (Ref: ${reference}).`);
    }
  };

  const rejectWithdrawal = (withdrawalId: string, reason: string) => {
    const wd = withdrawals.find((w) => w.id === withdrawalId);
    if (!wd) return;

    setWithdrawals((prev) =>
      prev.map((w) =>
        w.id === withdrawalId
          ? {
              ...w,
              status: 'rejected',
              rejectionReason: reason,
              reviewedBy: currentUser.id,
              reviewedAt: new Date().toISOString(),
            }
          : w
      )
    );

    // Return funds back to available balance
    setWallets((prev) => {
      const ownerW = prev[wd.ownerId];
      if (!ownerW) return prev;
      return {
        ...prev,
        [wd.ownerId]: {
          ...ownerW,
          availableBalance: ownerW.availableBalance + wd.amount,
        },
      };
    });

    sendNotification(wd.ownerId, 'turf_owner', 'system', 'Withdrawal Rejected', `Request for ৳${wd.amount} was rejected: ${reason}. Funds returned.`);
  };

  const updatePlatformSettings = (updates: Partial<PlatformSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  };

  // Policy Management (Section 47)
  const addCancellationPolicy = (policy: Omit<CancellationPolicy, 'id'>) => {
    const newPolicy: CancellationPolicy = {
      ...policy,
      id: `policy-${Date.now()}`,
    };
    setCancellationPolicies((prev) => [...prev, newPolicy]);
  };

  const updateCancellationPolicy = (policyId: string, updates: Partial<CancellationPolicy>) => {
    setCancellationPolicies((prev) => prev.map((p) => (p.id === policyId ? { ...p, ...updates } : p)));
  };

  // Review & Disputes
  const addReview = (bookingId: string, rating: number, comment: string) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    const newRev: Review = {
      id: `rev-${Date.now()}`,
      bookingId,
      playerId: currentUser.id,
      playerName: currentUser.name,
      turfId: booking.turfId,
      rating,
      comment,
      createdAt: new Date().toISOString(),
    };
    setReviews((prev) => [newRev, ...prev]);

    // Update turf average rating
    const turfReviews = [...reviews.filter((r) => r.turfId === booking.turfId), newRev];
    const avgRating = Number((turfReviews.reduce((acc, r) => acc + r.rating, 0) / turfReviews.length).toFixed(2));
    setTurfs((prev) =>
      prev.map((t) => (t.id === booking.turfId ? { ...t, rating: avgRating, reviewCount: turfReviews.length } : t))
    );
  };

  const raiseDispute = (bookingId: string, category: Dispute['category'], description: string) => {
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) return;

    const newDispute: Dispute = {
      id: `disp-${Date.now()}`,
      bookingId,
      bookingNumber: booking.bookingNumber,
      raisedByUserId: currentUser.id,
      raisedByName: currentUser.name,
      role: currentUser.role,
      category,
      description,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setDisputes((prev) => [newDispute, ...prev]);
    sendNotification('user-admin-1', 'admin', 'dispute', `Dispute Raised (#${booking.bookingNumber})`, `${currentUser.name} reported: ${description}`);
  };

  const resolveDispute = (disputeId: string, resolution: string) => {
    setDisputes((prev) =>
      prev.map((d) =>
        d.id === disputeId
          ? {
              ...d,
              status: 'resolved',
              resolutionNotes: resolution,
              resolvedBy: currentUser.name,
              resolvedAt: new Date().toISOString(),
            }
          : d
      )
    );
  };

  const toggleFavorite = (turfId: string) => {
    setFavorites((prev) => (prev.includes(turfId) ? prev.filter((id) => id !== turfId) : [...prev, turfId]));
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearAllNotifications = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // =========================================================================
  // SECTION 49: PLAYER SQUAD / OPEN MATCHES (PURELY SOCIAL, ZERO PAYMENTS)
  // =========================================================================
  const createOpenMatch = ({
    bookingId,
    skillLevel,
    maxPlayers,
    notes,
  }: {
    bookingId: string;
    skillLevel: OpenMatchSkillLevel;
    maxPlayers: number;
    notes?: string;
  }): { success: boolean; message: string; match?: OpenMatch } => {
    // 1. Validate booking exists and belongs to current user
    const booking = bookings.find((b) => b.id === bookingId);
    if (!booking) {
      return { success: false, message: 'Booking not found.' };
    }
    if (booking.playerId !== currentUser.id) {
      return { success: false, message: 'Only the captain who made the booking can host an Open Match.' };
    }
    if (booking.status !== 'confirmed') {
      return { success: false, message: 'Only confirmed bookings can be listed as an Open Match.' };
    }

    // 2. Check if an open match already exists for this booking
    const existing = openMatches.find((m) => m.bookingId === bookingId && m.status !== 'cancelled');
    if (existing) {
      return { success: false, message: 'An Open Match has already been created for this booking.' };
    }

    // 3. Find turf to snapshot area and sport
    const turf = turfs.find((t) => t.id === booking.turfId);
    const sportType = turf?.sportTypes[0] || 'Football';
    const area = turf?.area || 'Banani';

    const newMatch: OpenMatch = {
      id: `match-${Date.now()}`,
      bookingId,
      bookingNumber: booking.bookingNumber,
      captainId: currentUser.id,
      captainName: currentUser.name,
      captainPhone: currentUser.phone,
      turfId: booking.turfId,
      turfName: booking.turfName,
      date: booking.date,
      startTime: booking.startTime,
      endTime: booking.endTime,
      area,
      sportType,
      skillLevel,
      maxPlayers: Math.max(2, maxPlayers),
      joinedCount: 1, // captain counts as 1
      status: 'open',
      notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const captainParticipant: MatchParticipant = {
      id: `part-${Date.now()}`,
      matchId: newMatch.id,
      playerId: currentUser.id,
      playerName: `${currentUser.name} (Captain)`,
      playerPhone: currentUser.phone,
      joinedAt: new Date().toISOString(),
      status: 'joined',
    };

    setOpenMatches((prev) => [newMatch, ...prev]);
    setMatchParticipants((prev) => [captainParticipant, ...prev]);

    return { success: true, message: 'Open Match posted successfully! Teammates can now discover and join your squad.', match: newMatch };
  };

  const updateOpenMatch = (matchId: string, updates: Partial<OpenMatch>) => {
    setOpenMatches((prev) =>
      prev.map((m) => {
        if (m.id === matchId) {
          return { ...m, ...updates, updatedAt: new Date().toISOString() };
        }
        return m;
      })
    );
  };

  const cancelOpenMatch = (matchId: string): { success: boolean; message: string } => {
    const match = openMatches.find((m) => m.id === matchId);
    if (!match) return { success: false, message: 'Match not found.' };

    if (match.captainId !== currentUser.id && currentUser.role !== 'admin') {
      return { success: false, message: 'Only the captain or an admin can cancel this match.' };
    }

    setOpenMatches((prev) =>
      prev.map((m) => (m.id === matchId ? { ...m, status: 'cancelled', updatedAt: new Date().toISOString() } : m))
    );

    // Notify participants
    const participants = matchParticipants.filter((p) => p.matchId === matchId && p.status === 'joined' && p.playerId !== currentUser.id);
    participants.forEach((p) => {
      sendNotification(
        p.playerId,
        'player',
        'booking',
        'Open Match Cancelled by Captain',
        `The Open Match for ${match.turfName} on ${match.date} was cancelled. Remember payments are settled directly with the captain.`
      );
    });

    return { success: true, message: 'Open Match cancelled.' };
  };

  const joinOpenMatch = (matchId: string): { success: boolean; message: string } => {
    const match = openMatches.find((m) => m.id === matchId);
    if (!match) return { success: false, message: 'Match not found.' };

    if (match.status !== 'open') {
      return { success: false, message: `Match is currently ${match.status}. Cannot join.` };
    }

    if (match.captainId === currentUser.id) {
      return { success: false, message: 'You are the captain of this match.' };
    }

    const existingPart = matchParticipants.find((p) => p.matchId === matchId && p.playerId === currentUser.id && p.status === 'joined');
    if (existingPart) {
      return { success: false, message: 'You have already joined this squad.' };
    }

    const newJoinedCount = match.joinedCount + 1;
    const newStatus: OpenMatchStatus = newJoinedCount >= match.maxPlayers ? 'full' : 'open';

    setOpenMatches((prev) =>
      prev.map((m) => (m.id === matchId ? { ...m, joinedCount: newJoinedCount, status: newStatus, updatedAt: new Date().toISOString() } : m))
    );

    const newParticipant: MatchParticipant = {
      id: `part-${Date.now()}`,
      matchId,
      playerId: currentUser.id,
      playerName: currentUser.name,
      playerPhone: currentUser.phone,
      joinedAt: new Date().toISOString(),
      status: 'joined',
    };

    setMatchParticipants((prev) => [newParticipant, ...prev]);

    // Notify Captain
    sendNotification(
      match.captainId,
      'player',
      'booking',
      'New Player Joined Your Squad!',
      `${currentUser.name} joined your Open Match at ${match.turfName} (${match.date} ${match.startTime}). Squad count: ${newJoinedCount}/${match.maxPlayers}.`
    );

    return { success: true, message: 'You have successfully joined the squad!' };
  };

  const leaveOpenMatch = (matchId: string): { success: boolean; message: string } => {
    const match = openMatches.find((m) => m.id === matchId);
    if (!match) return { success: false, message: 'Match not found.' };

    if (match.captainId === currentUser.id) {
      return { success: false, message: 'Captains cannot leave. Cancel the match if you wish to disband.' };
    }

    const existingPart = matchParticipants.find((p) => p.matchId === matchId && p.playerId === currentUser.id && p.status === 'joined');
    if (!existingPart) {
      return { success: false, message: 'You are not in this squad.' };
    }

    setMatchParticipants((prev) =>
      prev.map((p) => (p.id === existingPart.id ? { ...p, status: 'left' } : p))
    );

    const newJoinedCount = Math.max(1, match.joinedCount - 1);
    setOpenMatches((prev) =>
      prev.map((m) =>
        m.id === matchId ? { ...m, joinedCount: newJoinedCount, status: 'open', updatedAt: new Date().toISOString() } : m
      )
    );

    // Notify Captain
    sendNotification(
      match.captainId,
      'player',
      'booking',
      'Teammate Left Squad',
      `${currentUser.name} left your Open Match at ${match.turfName}. Open slot available (${newJoinedCount}/${match.maxPlayers}).`
    );

    return { success: true, message: 'You have left the squad.' };
  };

  const removeMatchParticipant = (matchId: string, playerId: string): { success: boolean; message: string } => {
    const match = openMatches.find((m) => m.id === matchId);
    if (!match) return { success: false, message: 'Match not found.' };

    if (match.captainId !== currentUser.id && currentUser.role !== 'admin') {
      return { success: false, message: 'Only the captain can remove participants.' };
    }

    if (playerId === match.captainId) {
      return { success: false, message: 'Cannot remove the captain.' };
    }

    setMatchParticipants((prev) =>
      prev.map((p) => (p.matchId === matchId && p.playerId === playerId ? { ...p, status: 'removed' } : p))
    );

    const newJoinedCount = Math.max(1, match.joinedCount - 1);
    setOpenMatches((prev) =>
      prev.map((m) =>
        m.id === matchId ? { ...m, joinedCount: newJoinedCount, status: 'open', updatedAt: new Date().toISOString() } : m
      )
    );

    sendNotification(
      playerId,
      'player',
      'system',
      'Removed from Open Match Squad',
      `The captain removed you from the squad at ${match.turfName}. If you have questions, please reach out directly.`
    );

    return { success: true, message: 'Participant removed from squad.' };
  };

  // =========================================================================
  // SECTION 50: TOURNAMENTS (SIMPLE VERSION — DISPLAY-ONLY ENTRY/PRIZES)
  // =========================================================================
  const createTournament = (params: {
    turfId: string;
    name: string;
    sportType: string;
    format: string;
    startDate: string;
    endDate: string;
    maxTeams: number;
    entryFeeAmount?: number;
    prizePoolNote?: string;
    description: string;
  }): Tournament => {
    const turf = turfs.find((t) => t.id === params.turfId);
    const newTournament: Tournament = {
      id: `tourn-${Date.now()}`,
      turfId: params.turfId,
      turfName: turf?.name || 'Tournament Turf Venue',
      organizerId: currentUser.id,
      organizerName: currentUser.name,
      name: params.name,
      sportType: params.sportType,
      format: params.format,
      startDate: params.startDate,
      endDate: params.endDate,
      maxTeams: Math.max(2, params.maxTeams),
      entryFeeAmount: params.entryFeeAmount,
      prizePoolNote: params.prizePoolNote,
      status: 'open',
      description: params.description,
      createdAt: new Date().toISOString(),
    };

    setTournaments((prev) => [newTournament, ...prev]);

    sendNotification(
      currentUser.id,
      currentUser.role,
      'system',
      'Tournament Created Successfully',
      `"${params.name}" is now live for team registrations!`
    );

    return newTournament;
  };

  const updateTournament = (id: string, updates: Partial<Tournament>) => {
    setTournaments((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const cancelTournament = (id: string) => {
    const tourn = tournaments.find((t) => t.id === id);
    if (!tourn) return;

    // Release any slots blocked by scheduled matches in this tournament
    const matches = tournamentMatches.filter((m) => m.tournamentId === id);
    const slotIdsToRelease = matches.map((m) => m.slotId).filter(Boolean) as string[];

    if (slotIdsToRelease.length > 0) {
      setSlots((prev) =>
        prev.map((s) => (slotIdsToRelease.includes(s.id) && s.status === 'blocked' ? { ...s, status: 'available' } : s))
      );
    }

    setTournamentMatches((prev) =>
      prev.map((m) => (m.tournamentId === id ? { ...m, status: 'cancelled' } : m))
    );

    setTournaments((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'cancelled' } : t))
    );

    sendNotification(
      tourn.organizerId,
      'turf_owner',
      'system',
      'Tournament Cancelled',
      `"${tourn.name}" has been cancelled. Any blocked turf slots have been released.`
    );
  };

  const registerTournamentTeam = (
    tournamentId: string,
    teamName: string,
    rosterNotes?: string
  ): { success: boolean; message: string; team?: TournamentTeam } => {
    const tournament = tournaments.find((t) => t.id === tournamentId);
    if (!tournament) return { success: false, message: 'Tournament not found.' };

    if (tournament.status !== 'open') {
      return { success: false, message: `Tournament registration is ${tournament.status}.` };
    }

    const registeredTeams = tournamentTeams.filter((t) => t.tournamentId === tournamentId && t.status === 'registered');
    if (registeredTeams.length >= tournament.maxTeams) {
      return { success: false, message: 'Tournament has reached maximum team capacity.' };
    }

    const duplicateName = registeredTeams.some((t) => t.teamName.toLowerCase().trim() === teamName.toLowerCase().trim());
    if (duplicateName) {
      return { success: false, message: 'A team with this name is already registered in this tournament.' };
    }

    const newTeam: TournamentTeam = {
      id: `team-${Date.now()}`,
      tournamentId,
      captainId: currentUser.id,
      captainName: currentUser.name,
      captainPhone: currentUser.phone,
      teamName: teamName.trim(),
      rosterNotes: rosterNotes?.trim(),
      status: 'registered',
      registeredAt: new Date().toISOString(),
    };

    setTournamentTeams((prev) => [...prev, newTeam]);

    // Check if max reached
    if (registeredTeams.length + 1 >= tournament.maxTeams) {
      setTournaments((prev) =>
        prev.map((t) => (t.id === tournamentId ? { ...t, status: 'registration_closed' } : t))
      );
    }

    // Notify Organizer
    sendNotification(
      tournament.organizerId,
      'turf_owner',
      'booking',
      'New Team Registered for Tournament',
      `"${teamName}" (Captain: ${currentUser.name}) registered for "${tournament.name}". Teams: ${registeredTeams.length + 1}/${tournament.maxTeams}.`
    );

    return {
      success: true,
      message: `Team "${teamName}" registered successfully! Please settle any entry fee directly with the organizer offline.`,
      team: newTeam,
    };
  };

  const withdrawTournamentTeam = (tournamentId: string, teamId: string): { success: boolean; message: string } => {
    const team = tournamentTeams.find((t) => t.id === teamId && t.tournamentId === tournamentId);
    if (!team) return { success: false, message: 'Team registration not found.' };

    setTournamentTeams((prev) =>
      prev.map((t) => (t.id === teamId ? { ...t, status: 'withdrawn' } : t))
    );

    // Reopen tournament registration if it was registration_closed
    setTournaments((prev) =>
      prev.map((t) => (t.id === tournamentId && t.status === 'registration_closed' ? { ...t, status: 'open' } : t))
    );

    return { success: true, message: `Team "${team.teamName}" has been withdrawn.` };
  };

  const addOrUpdateTournamentMatch = (
    tournamentId: string,
    matchData: {
      id?: string;
      roundName: string;
      teamAId?: string;
      teamBId?: string;
      teamAName?: string;
      teamBName?: string;
      scheduledDate: string;
      scheduledStartTime: string;
      scheduledEndTime: string;
      slotId?: string;
      scoreA?: number;
      scoreB?: number;
      winnerTeamId?: string;
      status?: TournamentMatchStatus;
    }
  ): TournamentMatch => {
    // If slotId is provided and valid, block that slot from public booking
    if (matchData.slotId) {
      setSlots((prev) =>
        prev.map((s) => (s.id === matchData.slotId ? { ...s, status: 'blocked' } : s))
      );
    }

    let matchResult: TournamentMatch;

    if (matchData.id) {
      const isCompleted = matchData.scoreA !== undefined && matchData.scoreB !== undefined;
      const computedStatus: TournamentMatchStatus = matchData.status || (isCompleted ? 'completed' : 'scheduled');

      setTournamentMatches((prev) =>
        prev.map((m) => {
          if (m.id === matchData.id) {
            matchResult = {
              ...m,
              ...matchData,
              status: computedStatus,
            };
            return matchResult;
          }
          return m;
        })
      );
      matchResult = {
        ...tournamentMatches.find((m) => m.id === matchData.id)!,
        ...matchData,
        status: computedStatus,
      };
    } else {
      matchResult = {
        id: `tmatch-${Date.now()}`,
        tournamentId,
        roundName: matchData.roundName,
        teamAId: matchData.teamAId,
        teamBId: matchData.teamBId,
        teamAName: matchData.teamAName || 'TBD',
        teamBName: matchData.teamBName || 'TBD',
        scheduledDate: matchData.scheduledDate,
        scheduledStartTime: matchData.scheduledStartTime,
        scheduledEndTime: matchData.scheduledEndTime,
        slotId: matchData.slotId,
        scoreA: matchData.scoreA,
        scoreB: matchData.scoreB,
        winnerTeamId: matchData.winnerTeamId,
        status: matchData.scoreA !== undefined ? 'completed' : 'scheduled',
        createdAt: new Date().toISOString(),
      };
      setTournamentMatches((prev) => [...prev, matchResult]);
    }

    return matchResult;
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        isSignInModalOpen,
        setIsSignInModalOpen,
        isGetStartedModalOpen,
        setIsGetStartedModalOpen,
        signInRolePreset,
        openSignInModal,
        openGetStartedModal,
        loginUser,
        loginAsRole,
        loginWithCredentials,
        logoutUser,
        playerActiveTab,
        setPlayerActiveTab,
        ownerActiveTab,
        setOwnerActiveTab,
        adminActiveTab,
        setAdminActiveTab,
        openOwnerManualBookingModal,
        setOpenOwnerManualBookingModal,
        openStaffManualBookingModal,
        setOpenStaffManualBookingModal,
        registerNewUser,
        verifyActivationCode,
        resendActivationCode,
        requestPasswordReset,
        resetPasswordWithCode,
        switchUser,
        switchRoleDirectly,
        users,
        ownerProfiles,
        turfs,
        slots,
        bookings,
        staffAssignments,
        wallets,
        withdrawals,
        cancellationPolicies,
        reviews,
        disputes,
        notifications,
        settings,
        favorites,
        openMatches,
        matchParticipants,
        tournaments,
        tournamentTeams,
        tournamentMatches,
        lockSlot,
        lockSlots,
        unlockSlot,
        unlockSlots,
        createOnlineBooking,
        createManualBooking,
        cancelBooking,
        checkInBooking,
        completeBooking,
        toggleSlotBlock,
        addSlot,
        createTurf,
        updateTurf,
        deleteTurf,
        approveTurf,
        rejectTurf,
        approveOwner,
        rejectOwner,
        updateOwnerPayoutDetails,
        toggleUserSuspension,
        createStaff,
        updateStaffPermissions,
        requestWithdrawal,
        approveWithdrawal,
        rejectWithdrawal,
        updatePlatformSettings,
        addCancellationPolicy,
        updateCancellationPolicy,
        calculateRefund,
        addReview,
        raiseDispute,
        resolveDispute,
        toggleFavorite,
        markNotificationRead,
        clearAllNotifications,
        createOpenMatch,
        updateOpenMatch,
        cancelOpenMatch,
        joinOpenMatch,
        leaveOpenMatch,
        removeMatchParticipant,
        createTournament,
        updateTournament,
        cancelTournament,
        registerTournamentTeam,
        withdrawTournamentTeam,
        addOrUpdateTournamentMatch,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
