export type UserRole = 'player' | 'turf_owner' | 'staff' | 'admin';

export type UserStatus = 'active' | 'pending_approval' | 'suspended' | 'deactivated';

export type TurfStatus = 'draft' | 'pending_review' | 'active' | 'inactive' | 'suspended';

export type SlotStatus = 'available' | 'locked' | 'booked' | 'blocked';

export type BookingStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'checked_in'
  | 'completed'
  | 'cancelled'
  | 'expired'
  | 'refunded'
  | 'partially_refunded';

export type BookingSource = 'online' | 'manual_owner' | 'manual_staff' | 'admin';

export type PaymentMethod = 'sslcommerz' | 'cash' | 'bkash' | 'nagad' | 'rocket' | 'bank_transfer';

export type PaymentStatus = 'paid' | 'pending' | 'partial';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  status: UserStatus;
  avatar?: string;
  createdAt: string;
  password?: string; // custom login password set at registration (demo-only, in-memory)
  emailVerified?: boolean;
  activationCode?: string;
}

export interface TurfOwnerProfile {
  id: string;
  userId: string;
  businessName: string;
  nidOrTradeLicense: string;
  payoutMethod: 'bkash' | 'nagad' | 'rocket' | 'bank_account';
  payoutDetails: {
    accountNumber: string;
    bankName?: string;
    branchName?: string;
    accountHolderName?: string;
  };
  approvalStatus: 'pending_approval' | 'active' | 'rejected' | 'suspended';
  approvedBy?: string;
  approvedAt?: string;
  commissionOverride?: number; // percentage override e.g. 4%
}

export interface PricingRule {
  id: string;
  dayOfWeek: number; // 0 = Sunday, 6 = Saturday
  startTime: string; // "18:00"
  endTime: string;   // "23:00"
  pricePerHour: number;
}

export interface TurfAddon {
  id: string;
  turfId: string;
  name: string;
  description?: string;
  category: 'equipment' | 'service' | 'food' | 'other';
  price: number;
  stockQuantity?: number | null;
  isActive: boolean;
  displayOrder: number;
}

export interface Turf {
  id: string;
  ownerId: string;
  ownerName: string;
  name: string;
  description: string;
  address: string;
  area: string;
  city: string;
  latitude: number;
  longitude: number;
  sportTypes: string[]; // 'Football', 'Cricket', 'Futsal', 'Badminton'
  amenities: string[];  // 'Floodlights', 'Washroom', 'Dressing Room', 'Parking', 'Seating Area', 'Cafeteria'
  basePricePerHour: number;
  pricingRules?: PricingRule[];
  operatingHours: {
    openTime: string;  // "07:00"
    closeTime: string; // "00:00"
  };
  photos: string[];
  addons?: TurfAddon[];
  status: TurfStatus;
  commissionRateOverride?: number;
  rating: number;
  reviewCount: number;
  createdAt: string;
  cancellationPolicyId?: string;
  cancellationCutoffHours?: number; // owner-controlled: player cannot cancel within this many hours of slot start
}

export interface Slot {
  id: string;
  turfId: string;
  date: string; // YYYY-MM-DD
  startTime: string; // "18:00"
  endTime: string;   // "19:00"
  price: number;
  status: SlotStatus;
  lockedUntil?: string; // ISO string for 10-minute lock TTL
  lockedByUserId?: string;
}

export interface BookingAddonLineItem {
  id: string;
  addonId: string;
  name: string;
  price: number;
  quantity: number;
  totalPrice: number;
  category?: 'equipment' | 'service' | 'food' | 'other';
}

export interface Booking {
  id: string;
  bookingNumber: string;
  playerId?: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  turfId: string;
  turfName: string;
  slotId: string;
  date: string;
  startTime: string;
  endTime: string;
  slotIds?: string[];
  totalHours?: number;
  bookingSource: BookingSource;
  status: BookingStatus;
  baseAmount: number;
  addonTotal?: number;
  bookingAddons?: BookingAddonLineItem[];
  commissionAmount: number; // calculated at confirmation
  platformFeeAmount: number;
  hasGatewayFee: boolean;
  gatewayFeeAmount: number;
  totalPaid: number;
  netOwnerAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  paymentReference?: string;
  notes?: string;
  cancellationPolicyId?: string;
  cancellationReason?: string;
  cancelledBy?: string;
  cancelledAt?: string;
  refundAmount?: number;
  refundedPlatformFee?: number;
  qrCode: string;
  createdAt: string;
  updatedAt: string;
}

export interface StaffPermission {
  id: string;
  key:
    | 'bookings.view'
    | 'bookings.view_player_contact'
    | 'bookings.check_in'
    | 'bookings.complete'
    | 'bookings.cancel'
    | 'bookings.create_manual'
    | 'slots.view'
    | 'slots.block'
    | 'slots.unblock';
  label: string;
  description: string;
}

export interface StaffAssignment {
  id: string;
  staffUserId: string;
  staffName: string;
  staffEmail: string;
  staffPhone: string;
  ownerId: string;
  turfIds: string[];
  permissions: string[];
  status: 'pending_setup' | 'active';
  invitedAt?: string;
  setupLink?: string;
  createdAt: string;
}

export interface OwnerWallet {
  ownerId: string;
  availableBalance: number;
  heldBalance: number; // Held for bookings still inside cancellation window
  totalEarnings: number;
  totalWithdrawn: number;
}

export interface WithdrawalRequest {
  id: string;
  ownerId: string;
  ownerName: string;
  businessName: string;
  amount: number;
  payoutMethod: string;
  payoutDetails: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  reference?: string;
  rejectionReason?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface CancellationTier {
  id: string;
  minHoursBefore: number; // e.g. 24
  maxHoursBefore?: number; // e.g. 9999
  refundPercentage: number; // e.g. 100, 50, 0
  description: string;
}

export interface CancellationPolicy {
  id: string;
  name: string;
  isDefault: boolean;
  ownerId?: string;
  turfId?: string;
  description: string;
  tiers: CancellationTier[];
}

export interface Review {
  id: string;
  bookingId: string;
  playerId: string;
  playerName: string;
  turfId: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface Dispute {
  id: string;
  bookingId: string;
  bookingNumber: string;
  raisedByUserId: string;
  raisedByName: string;
  role: UserRole;
  category: 'refund_issue' | 'facility_unavailable' | 'double_booking' | 'payment_mismatch' | 'other';
  description: string;
  status: 'pending' | 'investigating' | 'resolved' | 'rejected';
  resolutionNotes?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  role: UserRole;
  type: 'booking' | 'payment' | 'refund' | 'approval' | 'system' | 'dispute';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface PlatformSettings {
  globalCommissionRate: number; // e.g. 5%
  platformFeeRate: number;      // e.g. 5%
  gatewayFeeRate: number;       // e.g. 2.5%
  minWithdrawalAmount: number;  // e.g. 1000 BDT
  defaultCancellationWindowHours: number; // e.g. 24
  supportedSports: string[];
  enableOpenMatches?: boolean;
  enableTournaments?: boolean;
  featureFlags?: {
    addons_enabled: boolean;
    squad_enabled: boolean;
    tournament_enabled: boolean;
    featured_turf_enabled: boolean;
    featured_addon_enabled: boolean;
    whatsapp_enabled: boolean;
    trending_enabled: boolean;
    near_you_enabled: boolean;
  };
  featuredPackages?: Array<{
    id: string;
    name: string;
    price: number;
    durationDays: number;
    priority: number;
    description: string;
  }>;
  paymentGateways?: PaymentGatewayConfig[];
  smtpConfigs?: SmtpConfig[];
}

export type PaymentGatewayProvider = 'sslcommerz' | 'surjopay' | 'bkash' | 'nagad' | 'custom';

export interface PaymentGatewayConfig {
  id: string;
  provider: PaymentGatewayProvider;
  label: string;
  isSandbox: boolean;
  isActive: boolean;
  storeId?: string;
  apiKey?: string;
  apiSecret?: string;
  merchantNumber?: string; // for bKash/Nagad merchant wallet numbers
}

export interface SmtpConfig {
  id: string;
  label: string;
  host: string;
  port: number;
  secure: boolean; // true = SSL/TLS (usually port 465), false = STARTTLS (usually 587/2525)
  username: string;
  password: string;
  fromName: string;
  fromEmail: string;
  isActive: boolean;
}


// Section 49: Player Squad / Matchmaking
export type OpenMatchSkillLevel = 'casual' | 'intermediate' | 'competitive';
export type OpenMatchStatus = 'open' | 'full' | 'closed' | 'cancelled';
export type MatchParticipantStatus = 'joined' | 'left' | 'removed';

export interface OpenMatch {
  id: string;
  bookingId: string;
  bookingNumber: string;
  captainId: string;
  captainName: string;
  captainPhone: string;
  turfId: string;
  turfName: string;
  date: string;
  startTime: string;
  endTime: string;
  area: string;
  sportType: string;
  skillLevel: OpenMatchSkillLevel;
  maxPlayers: number;
  joinedCount: number;
  status: OpenMatchStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MatchParticipant {
  id: string;
  matchId: string;
  playerId: string;
  playerName: string;
  playerPhone: string;
  joinedAt: string;
  status: MatchParticipantStatus;
}

// Section 50: Tournament (Simple Version)
export type TournamentStatus = 'open' | 'registration_closed' | 'ongoing' | 'completed' | 'cancelled';
export type TournamentTeamStatus = 'registered' | 'withdrawn' | 'disqualified';
export type TournamentMatchStatus = 'scheduled' | 'completed' | 'cancelled';

export interface Tournament {
  id: string;
  turfId: string;
  turfName: string;
  organizerId: string;
  organizerName: string;
  name: string;
  sportType: string;
  format: string; // e.g. 'Knockout', 'Round Robin'
  startDate: string;
  endDate: string;
  maxTeams: number;
  entryFeeAmount?: number; // display text only, platform moves no money
  prizePoolNote?: string;  // display text only
  status: TournamentStatus;
  description: string;
  createdAt: string;
}

export interface TournamentTeam {
  id: string;
  tournamentId: string;
  captainId: string;
  captainName: string;
  captainPhone: string;
  teamName: string;
  rosterNotes?: string;
  status: TournamentTeamStatus;
  registeredAt: string;
}

export interface TournamentMatch {
  id: string;
  tournamentId: string;
  roundName: string;
  teamAId?: string;
  teamBId?: string;
  teamAName?: string;
  teamBName?: string;
  scheduledDate: string;
  scheduledStartTime: string;
  scheduledEndTime: string;
  slotId?: string;
  scoreA?: number;
  scoreB?: number;
  winnerTeamId?: string;
  status: TournamentMatchStatus;
  createdAt: string;
}
