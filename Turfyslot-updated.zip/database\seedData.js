import dotenv from 'dotenv';
import pg from 'pg';

dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'postgres',
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || '',
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : false,
});

const owners = [
  {
    name: 'Tanvir Ahmed',
    email: 'tanvir@greenpitch.com',
    phone: '+880 1819-223344',
    role: 'turf_owner',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  },
  {
    name: 'Naimul Islam',
    email: 'naimul@kickoffturf.com',
    phone: '+880 1912-556677',
    role: 'turf_owner',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  },
];

const turfs = [
  {
    ownerEmail: 'tanvir@greenpitch.com',
    name: 'Green Arena Sports',
    description: 'Premier FIFA-standard artificial grass turf with high-grade floodlights, luxury dugout seating, changing rooms, and rooftop view.',
    address: 'Agrabad Commercial Area',
    area: 'Agrabad',
    city: 'Chattogram',
    latitude: 22.3273,
    longitude: 91.8123,
    sportTypes: ['Football', 'Futsal'],
    amenities: ['Floodlights', 'Dressing Room', 'Washroom', 'Parking', 'Seating Area', 'Cafeteria', 'Drinking Water'],
    basePricePerHour: 1500,
    operatingHours: { openTime: '07:00', closeTime: '23:59' },
    photos: [
      'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1000&q=85',
    ],
    status: 'active',
    rating: 4.9,
    reviewCount: 38,
  },
  {
    ownerEmail: 'tanvir@greenpitch.com',
    name: 'City Football Arena',
    description: 'High-density multi-sport pitch ideal for 6-a-side football, cricket nets with bowling machine, and evening tournaments.',
    address: 'South Khulshi Residential Area',
    area: 'Khulshi',
    city: 'Chattogram',
    latitude: 22.3615,
    longitude: 91.8021,
    sportTypes: ['Football', 'Cricket'],
    amenities: ['Floodlights', 'Washroom', 'Parking', 'Equipment Rental'],
    basePricePerHour: 1800,
    operatingHours: { openTime: '06:00', closeTime: '23:00' },
    photos: [
      'https://images.unsplash.com/photo-1575361204480-aadea25e6e68?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1529900748604-07564a03e7a6?auto=format&fit=crop&w=1000&q=85',
    ],
    status: 'active',
    rating: 4.8,
    reviewCount: 24,
  },
  {
    ownerEmail: 'naimul@kickoffturf.com',
    name: 'Champions Turf',
    description: 'Centrally located covered turf with professional rubber-infill turf, digital scoreboards, and chill-out player lounge.',
    address: 'O.R. Nizam Road, Panchlaish',
    area: 'Panchlaish',
    city: 'Chattogram',
    latitude: 22.3601,
    longitude: 91.8214,
    sportTypes: ['Futsal', 'Football'],
    amenities: ['Floodlights', 'Washroom', 'Dressing Room', 'Scoreboard'],
    basePricePerHour: 1300,
    operatingHours: { openTime: '08:00', closeTime: '23:00' },
    photos: [
      'https://images.unsplash.com/photo-1553778263-73a83bab9b0c?auto=format&fit=crop&w=1000&q=85',
      'https://images.unsplash.com/photo-1518091043644-c1d4457512c6?auto=format&fit=crop&w=1000&q=85',
    ],
    status: 'active',
    rating: 4.7,
    reviewCount: 19,
  },
];

try {
  for (const owner of owners) {
    await pool.query(
      `
        INSERT INTO users (name, email, phone, role, status, avatar, created_at, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
        ON CONFLICT (email) DO UPDATE
        SET name = EXCLUDED.name,
            phone = EXCLUDED.phone,
            role = EXCLUDED.role,
            status = EXCLUDED.status,
            avatar = EXCLUDED.avatar,
            updated_at = NOW()
      `,
      [owner.name, owner.email, owner.phone, owner.role, owner.status, owner.avatar]
    );
  }

  for (const turf of turfs) {
    const ownerResult = await pool.query(
      `SELECT id FROM users WHERE email = $1`,
      [turf.ownerEmail]
    );

    if (ownerResult.rows.length === 0) {
      throw new Error(`Owner not found for ${turf.ownerEmail}`);
    }

    const ownerId = ownerResult.rows[0].id;

    const existingTurfResult = await pool.query(
      `SELECT id FROM turfs WHERE owner_id = $1 AND name = $2`,
      [ownerId, turf.name]
    );

    let turfId;

    if (existingTurfResult.rows.length > 0) {
      turfId = existingTurfResult.rows[0].id;

      await pool.query(
        `
          UPDATE turfs
          SET description = $3,
              address = $4,
              area = $5,
              city = $6,
              latitude = $7,
              longitude = $8,
              sport_types = $9,
              amenities = $10,
              base_price_per_hour = $11,
              operating_hours = $12::jsonb,
              status = $13,
              rating = $14,
              review_count = $15,
              updated_at = NOW()
          WHERE id = $1
        `,
        [
          turfId,
          ownerId,
          turf.description,
          turf.address,
          turf.area,
          turf.city,
          turf.latitude,
          turf.longitude,
          turf.sportTypes,
          turf.amenities,
          turf.basePricePerHour,
          JSON.stringify(turf.operatingHours),
          turf.status,
          turf.rating,
          turf.reviewCount,
        ]
      );
    } else {
      const turfResult = await pool.query(
        `
          INSERT INTO turfs (
            owner_id, name, description, address, area, city, latitude, longitude,
            sport_types, amenities, base_price_per_hour, operating_hours, status, rating, review_count,
            created_at, updated_at
          )
          VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8,
            $9, $10, $11, $12::jsonb, $13, $14, $15,
            NOW(), NOW()
          )
          RETURNING id
        `,
        [
          ownerId,
          turf.name,
          turf.description,
          turf.address,
          turf.area,
          turf.city,
          turf.latitude,
          turf.longitude,
          turf.sportTypes,
          turf.amenities,
          turf.basePricePerHour,
          JSON.stringify(turf.operatingHours),
          turf.status,
          turf.rating,
          turf.reviewCount,
        ]
      );

      turfId = turfResult.rows[0].id;
    }

    await pool.query(`DELETE FROM turf_photos WHERE turf_id = $1`, [turfId]);

    for (let index = 0; index < turf.photos.length; index++) {
      await pool.query(
        `
          INSERT INTO turf_photos (turf_id, url, sort_order, created_at)
          VALUES ($1, $2, $3, NOW())
        `,
        [turfId, turf.photos[index], index]
      );
    }
  }

  const countResult = await pool.query('SELECT COUNT(*) AS total FROM turfs');
  console.log('Seeded turfs count:', countResult.rows[0].total);
} catch (error) {
  console.error('Seed error:', error.message);
  process.exit(1);
} finally {
  await pool.end();
}
