import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Tournament,
  TournamentTeam,
  TournamentMatch,
  TournamentStatus,
  TournamentMatchStatus,
} from '../../types';
import {
  Trophy,
  Calendar,
  Clock,
  MapPin,
  Users,
  Plus,
  AlertCircle,
  CheckCircle2,
  X,
  Shield,
  Phone,
  Award,
  DollarSign,
  Info,
  ChevronRight,
  Sparkles,
  Lock,
  LogIn,
  UserPlus,
} from 'lucide-react';

interface TournamentsViewProps {
  onBackToExplore?: () => void;
}

export const TournamentsView: React.FC<TournamentsViewProps> = ({ onBackToExplore }) => {
  const {
    currentUser,
    isAuthenticated,
    openSignInModal,
    openGetStartedModal,
    turfs,
    slots,
    tournaments,
    tournamentTeams,
    tournamentMatches,
    createTournament,
    updateTournament,
    cancelTournament,
    registerTournamentTeam,
    withdrawTournamentTeam,
    addOrUpdateTournamentMatch,
  } = useApp();

  // Auth Guard: unauthenticated users cannot view Tournaments
  if (!isAuthenticated) {
    return (
      <div className="max-w-2xl mx-auto py-16 px-4 text-center">
        <div className="bg-[#0A1E14] border border-white/10 rounded-3xl p-8 sm:p-12 shadow-2xl space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-[#C8FF5E]/15 border border-[#C8FF5E]/30 flex items-center justify-center mx-auto text-[#C8FF5E]">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Login Required to View Tournaments</h2>
            <p className="text-sm text-white/70 max-w-md mx-auto">
              টুর্নামেন্ট ফিক্সচার, ব্র্যাকেট এবং টিম রেজিস্ট্রেশন দেখতে অনুগ্রহ করে আপনার অ্যাকাউন্টে লগইন করুন।
            </p>
            <p className="text-xs text-white/50 max-w-md mx-auto">
              Please sign in to your account to view tournament fixtures, bracket results, prize pools, and register teams.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => openSignInModal('player')}
              className="w-full sm:w-auto px-6 py-3 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black text-xs sm:text-sm rounded-full cursor-pointer shadow-lg shadow-[#C8FF5E]/20 flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In to View Tournaments</span>
            </button>
            <button
              onClick={() => openGetStartedModal('player')}
              className="w-full sm:w-auto px-6 py-3 bg-white/[0.08] hover:bg-white/[0.14] text-white font-bold text-xs sm:text-sm rounded-full border border-white/20 cursor-pointer flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4 text-[#C8FF5E]" />
              <span>Create Account</span>
            </button>
            {onBackToExplore && (
              <button
                onClick={onBackToExplore}
                className="w-full sm:w-auto px-5 py-3 text-white/60 hover:text-white text-xs font-semibold cursor-pointer"
              >
                Back to Explore Turfs
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Filters
  const [selectedSport, setSelectedSport] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [activeDetailsTab, setActiveDetailsTab] = useState<'overview' | 'teams' | 'matches'>('overview');
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [showAddMatchModal, setShowAddMatchModal] = useState(false);
  const [showScoreModal, setShowScoreModal] = useState(false);
  const [matchToScore, setMatchToScore] = useState<TournamentMatch | null>(null);

  // Register Team Form State
  const [regTeamName, setRegTeamName] = useState('');
  const [regRosterNotes, setRegRosterNotes] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState('');

  // Create Tournament Form State
  const myTurfs = currentUser.role === 'admin' ? turfs : turfs.filter((t) => t.ownerId === currentUser.id);
  const canCreateTournament = currentUser.role === 'admin' || (currentUser.role === 'turf_owner' && myTurfs.length > 0);

  const [tTurfId, setTTurfId] = useState(myTurfs[0]?.id || '');
  const [tName, setTName] = useState('');
  const [tSport, setTSport] = useState('Football');
  const [tFormat, setTFormat] = useState('7-a-side Knockout');
  const [tStartDate, setTStartDate] = useState('2026-09-20');
  const [tEndDate, setTEndDate] = useState('2026-09-22');
  const [tMaxTeams, setTMaxTeams] = useState(8);
  const [tEntryFee, setTEntryFee] = useState(2500);
  const [tPrizePool, setTPrizePool] = useState('৳20,000 Champion Prize + Trophy + Medals');
  const [tDesc, setTDesc] = useState('');
  const [createError, setCreateError] = useState('');

  // Add Match Form State
  const [mRoundName, setMRoundName] = useState('Quarter Final');
  const [mTeamAId, setMTeamAId] = useState('');
  const [mTeamBId, setMTeamBId] = useState('');
  const [mDate, setMDate] = useState('2026-09-20');
  const [mStartTime, setMStartTime] = useState('16:00');
  const [mEndTime, setMEndTime] = useState('17:00');
  const [mSlotId, setMSlotId] = useState('');

  // Score Modal State
  const [scoreA, setScoreA] = useState<number>(0);
  const [scoreB, setScoreB] = useState<number>(0);

  // Filtered Tournaments
  const filteredTournaments = tournaments.filter((t) => {
    const sportMatch = selectedSport === 'All' || t.sportType.toLowerCase() === selectedSport.toLowerCase();
    const statusMatch = selectedStatus === 'All' || t.status === selectedStatus;
    return sportMatch && statusMatch;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess('');

    if (!selectedTournament) return;
    if (!regTeamName.trim()) {
      setRegError('Please enter a valid team name.');
      return;
    }

    const res = registerTournamentTeam(selectedTournament.id, regTeamName, regRosterNotes);
    if (res.success) {
      setRegSuccess(res.message);
      setTimeout(() => {
        setShowRegisterModal(false);
        setRegTeamName('');
        setRegRosterNotes('');
        setRegSuccess('');
      }, 1400);
    } else {
      setRegError(res.message);
    }
  };

  const handleCreateTournamentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');

    if (!tName.trim()) {
      setCreateError('Please enter a tournament name.');
      return;
    }
    if (!tTurfId) {
      setCreateError('Please select a hosting turf venue.');
      return;
    }

    createTournament({
      turfId: tTurfId,
      name: tName.trim(),
      sportType: tSport,
      format: tFormat,
      startDate: tStartDate,
      endDate: tEndDate,
      maxTeams: Number(tMaxTeams),
      entryFeeAmount: tEntryFee ? Number(tEntryFee) : undefined,
      prizePoolNote: tPrizePool.trim(),
      description: tDesc.trim() || `Official ${tSport} tournament hosted at Dhaka turf grounds.`,
    });

    setShowCreateModal(false);
    setTName('');
    setTDesc('');
  };

  const handleAddMatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTournament) return;

    const teamA = tournamentTeams.find((t) => t.id === mTeamAId);
    const teamB = tournamentTeams.find((t) => t.id === mTeamBId);

    addOrUpdateTournamentMatch(selectedTournament.id, {
      roundName: mRoundName,
      teamAId: mTeamAId || undefined,
      teamBId: mTeamBId || undefined,
      teamAName: teamA ? teamA.teamName : 'TBD',
      teamBName: teamB ? teamB.teamName : 'TBD',
      scheduledDate: mDate,
      scheduledStartTime: mStartTime,
      scheduledEndTime: mEndTime,
      slotId: mSlotId || undefined,
    });

    setShowAddMatchModal(false);
  };

  const handleSaveScoreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTournament || !matchToScore) return;

    let winnerId: string | undefined = undefined;
    if (scoreA > scoreB && matchToScore.teamAId) {
      winnerId = matchToScore.teamAId;
    } else if (scoreB > scoreA && matchToScore.teamBId) {
      winnerId = matchToScore.teamBId;
    }

    addOrUpdateTournamentMatch(selectedTournament.id, {
      id: matchToScore.id,
      roundName: matchToScore.roundName,
      teamAId: matchToScore.teamAId,
      teamBId: matchToScore.teamBId,
      teamAName: matchToScore.teamAName,
      teamBName: matchToScore.teamBName,
      scheduledDate: matchToScore.scheduledDate,
      scheduledStartTime: matchToScore.scheduledStartTime,
      scheduledEndTime: matchToScore.scheduledEndTime,
      slotId: matchToScore.slotId,
      scoreA,
      scoreB,
      winnerTeamId: winnerId,
      status: 'completed',
    });

    setShowScoreModal(false);
    setMatchToScore(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0A1E14] border border-white/10 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-[#C8FF5E]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8FF5E]/10 border border-[#C8FF5E]/20 text-[#C8FF5E] text-xs font-bold">
              <Trophy className="w-3.5 h-3.5" />
              <span>Section 50 • Turf Tournaments & Brackets</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Community Sports Tournaments
            </h1>
            <p className="text-xs sm:text-sm text-white/70 leading-relaxed">
              Discover official turf cups, knockout leagues, and weekend championships across Dhaka.
              Register your squad, track fixtures, and compete for trophies.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {onBackToExplore && (
              <button
                type="button"
                onClick={onBackToExplore}
                className="px-4 py-2.5 rounded-xl border border-white/15 hover:border-white/30 text-white/80 hover:text-white text-xs font-bold transition-all cursor-pointer"
              >
                Back to Turfs
              </button>
            )}
            {canCreateTournament && (
              <button
                type="button"
                onClick={() => {
                  setCreateError('');
                  setShowCreateModal(true);
                }}
                className="px-5 py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-xs font-black flex items-center gap-2 shadow-lg shadow-[#C8FF5E]/20 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Create Tournament</span>
              </button>
            )}
          </div>
        </div>

        {/* Hard Financial Boundary Notice */}
        <div className="mt-5 p-3 rounded-2xl bg-amber-950/30 border border-amber-500/30 text-amber-200/90 text-xs flex items-start gap-2.5">
          <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-bold text-amber-300">Financial Boundary: </span>
            TurfySlot is an informational tournament host & bracket scheduler. We do not collect team entry
            fees or escrow prize money. All fees and prizes are handled directly between teams and the turf
            organizer offline.
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#0e271a] p-4 rounded-2xl border border-white/10">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-white/70">Sport:</span>
          <div className="flex flex-wrap gap-1.5">
            {['All', 'Football', 'Cricket', 'Futsal', 'Badminton'].map((sport) => (
              <button
                key={sport}
                type="button"
                onClick={() => setSelectedSport(sport)}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedSport === sport
                    ? 'bg-[#C8FF5E] text-[#0A1E14]'
                    : 'text-white/60 hover:text-white bg-white/5'
                }`}
              >
                {sport}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-white/70">Status:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-[#07130c] border border-white/15 rounded-xl px-3 py-1.5 text-white text-xs focus:border-[#C8FF5E] outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="open">Registration Open</option>
            <option value="registration_closed">Registration Closed</option>
            <option value="ongoing">Ongoing</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>

      {/* Tournament Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTournaments.map((t) => {
          const teamsInTournament = tournamentTeams.filter(
            (team) => team.tournamentId === t.id && team.status === 'registered'
          );
          const isOrganizer = t.organizerId === currentUser.id || currentUser.role === 'admin';
          const myTeam = tournamentTeams.find(
            (team) => team.tournamentId === t.id && team.captainId === currentUser.id && team.status === 'registered'
          );

          return (
            <div
              key={t.id}
              className="bg-[#0A1E14] border border-white/10 hover:border-[#C8FF5E]/30 transition-all rounded-3xl p-5 flex flex-col justify-between shadow-xl space-y-4"
            >
              <div className="space-y-3">
                {/* Top Status & Sport */}
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] font-bold text-[11px] border border-[#C8FF5E]/30 flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5" /> {t.sportType}
                  </span>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded border ${
                      t.status === 'open'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : t.status === 'ongoing'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : t.status === 'completed'
                        ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                        : 'bg-white/10 text-white/60 border-white/10'
                    }`}
                  >
                    {t.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Tournament Name & Venue */}
                <div>
                  <h3 className="text-base font-bold text-white tracking-tight">{t.name}</h3>
                  <p className="text-xs text-white/60 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-[#C8FF5E]" /> {t.turfName}
                  </p>
                </div>

                {/* Details Box */}
                <div className="p-3.5 bg-[#07130c] rounded-2xl border border-white/10 text-xs space-y-2">
                  <div className="flex justify-between text-white/80">
                    <span className="text-white/50">Format:</span>
                    <span className="font-semibold text-white">{t.format}</span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span className="text-white/50">Dates:</span>
                    <span className="font-semibold text-white">
                      {t.startDate} - {t.endDate}
                    </span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span className="text-white/50">Teams Registered:</span>
                    <span className="font-bold text-[#C8FF5E]">
                      {teamsInTournament.length} / {t.maxTeams} Teams
                    </span>
                  </div>
                  {t.entryFeeAmount !== undefined && (
                    <div className="flex justify-between text-white/80 pt-1 border-t border-white/5">
                      <span className="text-white/50">Entry Fee (Offline):</span>
                      <span className="font-bold text-amber-300">৳{t.entryFeeAmount.toLocaleString()}</span>
                    </div>
                  )}
                  {t.prizePoolNote && (
                    <div className="flex justify-between text-white/80">
                      <span className="text-white/50">Prize Pool:</span>
                      <span className="font-bold text-[#C8FF5E] text-[11px] truncate max-w-[160px]">
                        {t.prizePoolNote}
                      </span>
                    </div>
                  )}
                </div>

                {t.description && (
                  <p className="text-xs text-white/70 line-clamp-2 leading-relaxed">
                    {t.description}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTournament(t);
                    setActiveDetailsTab('overview');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  View Details & Fixtures
                </button>

                {myTeam ? (
                  <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/20 px-3 py-1.5 rounded-xl border border-emerald-500/30">
                    Registered: {myTeam.teamName} ✓
                  </span>
                ) : isOrganizer ? (
                  <span className="text-[11px] font-bold text-[#C8FF5E] bg-[#C8FF5E]/15 px-3 py-1.5 rounded-xl border border-[#C8FF5E]/30">
                    Organizer
                  </span>
                ) : t.status === 'open' ? (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTournament(t);
                      setShowRegisterModal(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-xs font-black shadow-md transition-all cursor-pointer"
                  >
                    Register Team
                  </button>
                ) : (
                  <span className="text-xs text-white/40 font-semibold">Registration Closed</span>
                )}
              </div>
            </div>
          );
        })}

        {filteredTournaments.length === 0 && (
          <div className="col-span-full text-center py-16 bg-[#0A1E14] border border-white/10 rounded-3xl p-8 space-y-4">
            <Trophy className="w-12 h-12 text-[#C8FF5E]/40 mx-auto" />
            <h3 className="text-lg font-bold text-white">No Tournaments Found</h3>
            <p className="text-xs text-white/60 max-w-md mx-auto">
              No tournaments match your current filters. Check back soon or create one if you manage a turf!
            </p>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: TOURNAMENT DETAILS DRAWER (OVERVIEW, TEAMS, FIXTURES)            */}
      {/* ========================================================================= */}
      {selectedTournament && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b121e] border border-white/15 w-full max-w-2xl rounded-3xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-[#C8FF5E]" /> {selectedTournament.name}
                </h3>
                <p className="text-xs text-white/60">
                  {selectedTournament.turfName} • {selectedTournament.sportType}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTournament(null)}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sub-tabs */}
            <div className="flex border-b border-white/10 gap-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setActiveDetailsTab('overview')}
                className={`pb-2 transition-all cursor-pointer ${
                  activeDetailsTab === 'overview'
                    ? 'border-b-2 border-[#C8FF5E] text-[#C8FF5E]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Overview
              </button>
              <button
                type="button"
                onClick={() => setActiveDetailsTab('teams')}
                className={`pb-2 transition-all cursor-pointer ${
                  activeDetailsTab === 'teams'
                    ? 'border-b-2 border-[#C8FF5E] text-[#C8FF5E]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Teams ({tournamentTeams.filter((t) => t.tournamentId === selectedTournament.id && t.status === 'registered').length})
              </button>
              <button
                type="button"
                onClick={() => setActiveDetailsTab('matches')}
                className={`pb-2 transition-all cursor-pointer ${
                  activeDetailsTab === 'matches'
                    ? 'border-b-2 border-[#C8FF5E] text-[#C8FF5E]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Fixtures & Matches ({tournamentMatches.filter((m) => m.tournamentId === selectedTournament.id).length})
              </button>
            </div>

            {/* TAB 1: OVERVIEW */}
            {activeDetailsTab === 'overview' && (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-[#07130c] rounded-2xl border border-white/10 space-y-2.5">
                  <div className="flex justify-between">
                    <span className="text-white/60">Hosting Turf:</span>
                    <span className="font-bold text-white">{selectedTournament.turfName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Tournament Dates:</span>
                    <span className="font-semibold text-white">
                      {selectedTournament.startDate} to {selectedTournament.endDate}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Format:</span>
                    <span className="font-semibold text-white">{selectedTournament.format}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/60">Organizer:</span>
                    <span className="font-semibold text-white">{selectedTournament.organizerName}</span>
                  </div>
                  {selectedTournament.entryFeeAmount !== undefined && (
                    <div className="flex justify-between pt-1 border-t border-white/5">
                      <span className="text-white/60">Entry Fee (Per Team):</span>
                      <span className="font-bold text-amber-300">
                        ৳{selectedTournament.entryFeeAmount.toLocaleString()} (Paid directly to organizer)
                      </span>
                    </div>
                  )}
                  {selectedTournament.prizePoolNote && (
                    <div className="flex justify-between">
                      <span className="text-white/60">Prize Pool / Awards:</span>
                      <span className="font-bold text-[#C8FF5E]">{selectedTournament.prizePoolNote}</span>
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Rules & Information</h4>
                  <p className="text-white/70 leading-relaxed bg-white/[0.03] p-3 rounded-2xl border border-white/5">
                    {selectedTournament.description}
                  </p>
                </div>

                {/* Organizer Controls */}
                {(selectedTournament.organizerId === currentUser.id || currentUser.role === 'admin') && (
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                    <span className="text-[11px] text-white/50">Organizer Actions:</span>
                    <button
                      type="button"
                      onClick={() => {
                        cancelTournament(selectedTournament.id);
                        setSelectedTournament(null);
                      }}
                      className="px-3 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Cancel Tournament
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: REGISTERED TEAMS */}
            {activeDetailsTab === 'teams' && (
              <div className="space-y-4 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-white/60">
                    Confirmed Teams ({tournamentTeams.filter((t) => t.tournamentId === selectedTournament.id && t.status === 'registered').length} / {selectedTournament.maxTeams})
                  </span>
                  {selectedTournament.status === 'open' && (
                    <button
                      type="button"
                      onClick={() => setShowRegisterModal(true)}
                      className="px-3 py-1.5 bg-[#C8FF5E] text-[#0A1E14] font-bold rounded-lg text-xs cursor-pointer"
                    >
                      + Register a Team
                    </button>
                  )}
                </div>

                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {tournamentTeams
                    .filter((team) => team.tournamentId === selectedTournament.id)
                    .map((team, idx) => {
                      const isCaptain = team.captainId === currentUser.id;
                      return (
                        <div
                          key={team.id}
                          className="p-3 rounded-2xl bg-white/[0.04] border border-white/5 flex items-center justify-between"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-[#C8FF5E]/20 text-[#C8FF5E] flex items-center justify-center font-bold text-[10px]">
                                {idx + 1}
                              </span>
                              <span className="font-bold text-white text-sm">{team.teamName}</span>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                                  team.status === 'registered'
                                    ? 'bg-emerald-500/20 text-emerald-400'
                                    : 'bg-rose-500/20 text-rose-400'
                                }`}
                              >
                                {team.status}
                              </span>
                            </div>
                            <div className="text-[11px] text-white/60 mt-1 flex items-center gap-3">
                              <span>Captain: {team.captainName}</span>
                              <span>📞 {team.captainPhone}</span>
                            </div>
                            {team.rosterNotes && (
                              <div className="text-[10px] text-white/50 mt-1 italic">
                                Roster: {team.rosterNotes}
                              </div>
                            )}
                          </div>

                          {isCaptain && team.status === 'registered' && (
                            <button
                              type="button"
                              onClick={() => withdrawTournamentTeam(selectedTournament.id, team.id)}
                              className="text-xs text-rose-400 hover:text-rose-300 underline cursor-pointer"
                            >
                              Withdraw
                            </button>
                          )}
                        </div>
                      );
                    })}

                  {tournamentTeams.filter((t) => t.tournamentId === selectedTournament.id).length === 0 && (
                    <div className="text-center py-8 text-white/50">
                      No teams registered yet. Be the first team on the roster!
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 3: FIXTURES & MATCHES */}
            {activeDetailsTab === 'matches' && (
              <div className="space-y-4 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-white/60">Scheduled Match Fixtures</span>
                  {(selectedTournament.organizerId === currentUser.id || currentUser.role === 'admin') && (
                    <button
                      type="button"
                      onClick={() => setShowAddMatchModal(true)}
                      className="px-3 py-1.5 bg-[#C8FF5E] text-[#0A1E14] font-bold rounded-lg text-xs cursor-pointer"
                    >
                      + Add Match Fixture
                    </button>
                  )}
                </div>

                <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                  {tournamentMatches
                    .filter((m) => m.tournamentId === selectedTournament.id)
                    .map((m) => {
                      const isOrganizer =
                        selectedTournament.organizerId === currentUser.id || currentUser.role === 'admin';
                      const isCompleted = m.status === 'completed';

                      return (
                        <div
                          key={m.id}
                          className="p-3 rounded-2xl bg-[#07130c] border border-white/10 space-y-2"
                        >
                          <div className="flex justify-between text-[11px] text-white/50">
                            <span className="font-bold text-[#C8FF5E]">{m.roundName}</span>
                            <span>
                              {m.scheduledDate} ({m.scheduledStartTime} - {m.scheduledEndTime})
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-sm font-bold text-white px-2">
                            <span className={m.winnerTeamId === m.teamAId ? 'text-[#C8FF5E]' : ''}>
                              {m.teamAName} {m.winnerTeamId === m.teamAId ? '🏆' : ''}
                            </span>
                            <div className="px-3 py-1 bg-white/10 rounded-lg text-xs font-mono text-center">
                              {isCompleted ? `${m.scoreA} - ${m.scoreB}` : 'VS'}
                            </div>
                            <span className={m.winnerTeamId === m.teamBId ? 'text-[#C8FF5E]' : ''}>
                              {m.teamBName} {m.winnerTeamId === m.teamBId ? '🏆' : ''}
                            </span>
                          </div>

                          {isOrganizer && (
                            <div className="pt-2 border-t border-white/5 flex justify-end">
                              <button
                                type="button"
                                onClick={() => {
                                  setMatchToScore(m);
                                  setScoreA(m.scoreA || 0);
                                  setScoreB(m.scoreB || 0);
                                  setShowScoreModal(true);
                                }}
                                className="text-[11px] font-semibold text-[#C8FF5E] hover:underline cursor-pointer"
                              >
                                {isCompleted ? 'Edit Score / Winner' : 'Record Score & Winner'}
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}

                  {tournamentMatches.filter((m) => m.tournamentId === selectedTournament.id).length === 0 && (
                    <div className="text-center py-8 text-white/50">
                      No match fixtures scheduled yet. The organizer will post brackets once registration closes.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: REGISTER TEAM                                                    */}
      {/* ========================================================================= */}
      {showRegisterModal && selectedTournament && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-white/15 w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-white/10">
              <h3 className="font-bold text-white text-base">Register Team for {selectedTournament.name}</h3>
              <button
                type="button"
                onClick={() => setShowRegisterModal(false)}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Team Name:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dhaka Vipers FC"
                  value={regTeamName}
                  onChange={(e) => setRegTeamName(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Captain Info:</label>
                <div className="p-3 bg-[#07130c] rounded-xl border border-white/10 text-white/70 space-y-1">
                  <div>Name: {currentUser.name}</div>
                  <div>Phone: {currentUser.phone}</div>
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Roster / Player Names (Optional):</label>
                <textarea
                  placeholder="e.g. Tanvir (GK), Rafiq (Def), Shakil (Mid), Nabil (Fwd)"
                  value={regRosterNotes}
                  onChange={(e) => setRegRosterNotes(e.target.value)}
                  rows={3}
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white placeholder-white/40 focus:border-[#C8FF5E] outline-none"
                />
              </div>

              <div className="p-3 bg-amber-950/40 border border-amber-500/30 rounded-xl text-[11px] text-amber-200">
                <span className="font-bold">Offline Payment Note:</span> If this tournament has an entry fee,
                settle it directly with the organizer ({selectedTournament.organizerName}) offline.
              </div>

              {regError && (
                <div className="p-3 bg-rose-950/40 border border-rose-500/40 text-rose-300 font-semibold rounded-xl">
                  {regError}
                </div>
              )}

              {regSuccess && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 font-semibold rounded-xl">
                  {regSuccess}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRegisterModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black cursor-pointer shadow-lg"
                >
                  Confirm Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CREATE TOURNAMENT                                                */}
      {/* ========================================================================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b121e] border border-white/15 w-full max-w-lg rounded-3xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex justify-between items-center pb-2 border-b border-white/10">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Trophy className="w-4 h-4 text-[#C8FF5E]" /> Host a Tournament
              </h3>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTournamentSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Hosting Turf Venue:</label>
                <select
                  value={tTurfId}
                  onChange={(e) => setTTurfId(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                >
                  {myTurfs.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.area})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Tournament Name:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dhaka Champions Cup 2026"
                  value={tName}
                  onChange={(e) => setTName(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Sport:</label>
                  <select
                    value={tSport}
                    onChange={(e) => setTSport(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="Football">Football</option>
                    <option value="Cricket">Cricket</option>
                    <option value="Futsal">Futsal</option>
                    <option value="Badminton">Badminton</option>
                  </select>
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Format:</label>
                  <input
                    type="text"
                    value={tFormat}
                    onChange={(e) => setTFormat(e.target.value)}
                    placeholder="e.g. 7-a-side Knockout"
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Start Date:</label>
                  <input
                    type="date"
                    value={tStartDate}
                    onChange={(e) => setTStartDate(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">End Date:</label>
                  <input
                    type="date"
                    value={tEndDate}
                    onChange={(e) => setTEndDate(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Max Teams:</label>
                  <input
                    type="number"
                    min={2}
                    max={32}
                    value={tMaxTeams}
                    onChange={(e) => setTMaxTeams(Number(e.target.value))}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white font-bold focus:border-[#C8FF5E] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Entry Fee (BDT, Display Only):</label>
                  <input
                    type="number"
                    value={tEntryFee}
                    onChange={(e) => setTEntryFee(Number(e.target.value))}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-[#C8FF5E] font-bold focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Prize Pool / Note:</label>
                  <input
                    type="text"
                    value={tPrizePool}
                    onChange={(e) => setTPrizePool(e.target.value)}
                    placeholder="e.g. ৳20,000 + Trophy"
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Tournament Description & Rules:</label>
                <textarea
                  rows={3}
                  value={tDesc}
                  onChange={(e) => setTDesc(e.target.value)}
                  placeholder="Specify match timings, cleats policy, age brackets, or awards..."
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white placeholder-white/40 focus:border-[#C8FF5E] outline-none"
                />
              </div>

              {createError && (
                <div className="p-3 bg-rose-950/40 border border-rose-500/40 text-rose-300 font-semibold rounded-xl">
                  {createError}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black cursor-pointer shadow-lg"
                >
                  Publish Tournament
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ADD MATCH FIXTURE                                                */}
      {/* ========================================================================= */}
      {showAddMatchModal && selectedTournament && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-white/15 w-full max-w-md rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-white/10">
              <h3 className="font-bold text-white text-base">Schedule Match Fixture</h3>
              <button
                type="button"
                onClick={() => setShowAddMatchModal(false)}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMatchSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Round Name:</label>
                <input
                  type="text"
                  required
                  value={mRoundName}
                  onChange={(e) => setMRoundName(e.target.value)}
                  placeholder="e.g. Group A Match 1 or Quarter Final"
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-3 text-white focus:border-[#C8FF5E] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Team A:</label>
                  <select
                    value={mTeamAId}
                    onChange={(e) => setMTeamAId(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="">Select Team A</option>
                    {tournamentTeams
                      .filter((t) => t.tournamentId === selectedTournament.id && t.status === 'registered')
                      .map((team) => (
                        <option key={team.id} value={team.id}>
                          {team.teamName}
                        </option>
                      ))}
                  </select>
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Team B:</label>
                  <select
                    value={mTeamBId}
                    onChange={(e) => setMTeamBId(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="">Select Team B</option>
                    {tournamentTeams
                      .filter((t) => t.tournamentId === selectedTournament.id && t.status === 'registered')
                      .map((team) => (
                        <option key={team.id} value={team.id}>
                          {team.teamName}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Date:</label>
                  <input
                    type="date"
                    value={mDate}
                    onChange={(e) => setMDate(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Start Time:</label>
                  <input
                    type="time"
                    value={mStartTime}
                    onChange={(e) => setMStartTime(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">End Time:</label>
                  <input
                    type="time"
                    value={mEndTime}
                    onChange={(e) => setMEndTime(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">
                  Reserve Turf Slot (Optional - Auto Blocks from Public):
                </label>
                <select
                  value={mSlotId}
                  onChange={(e) => setMSlotId(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                >
                  <option value="">No automatic slot block</option>
                  {slots
                    .filter((s) => s.turfId === selectedTournament.turfId && s.status === 'available')
                    .map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.date} ({s.startTime} - {s.endTime}) - Slot #{s.id}
                      </option>
                    ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddMatchModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black cursor-pointer shadow-lg"
                >
                  Save Fixture
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: RECORD SCORE & WINNER                                            */}
      {/* ========================================================================= */}
      {showScoreModal && matchToScore && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-white/15 w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-white/10">
              <h3 className="font-bold text-white text-base">Record Match Score</h3>
              <button
                type="button"
                onClick={() => setShowScoreModal(false)}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveScoreSubmit} className="space-y-4 text-xs">
              <div className="text-center font-bold text-sm text-white">{matchToScore.roundName}</div>

              <div className="grid grid-cols-2 gap-4 items-center">
                <div className="space-y-1 text-center">
                  <span className="font-bold text-white truncate block">{matchToScore.teamAName}</span>
                  <input
                    type="number"
                    min={0}
                    value={scoreA}
                    onChange={(e) => setScoreA(Number(e.target.value))}
                    className="w-20 mx-auto text-center bg-[#07130c] border border-white/15 rounded-xl p-3 text-2xl font-black text-[#C8FF5E] focus:border-[#C8FF5E] outline-none"
                  />
                </div>
                <div className="space-y-1 text-center">
                  <span className="font-bold text-white truncate block">{matchToScore.teamBName}</span>
                  <input
                    type="number"
                    min={0}
                    value={scoreB}
                    onChange={(e) => setScoreB(Number(e.target.value))}
                    className="w-20 mx-auto text-center bg-[#07130c] border border-white/15 rounded-xl p-3 text-2xl font-black text-[#C8FF5E] focus:border-[#C8FF5E] outline-none"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowScoreModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 text-white font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black cursor-pointer shadow-lg"
                >
                  Save Score
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
