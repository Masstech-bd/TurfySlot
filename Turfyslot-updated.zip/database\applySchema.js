import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import pg from 'pg';

dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'postgres',
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || '',
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : false,
});

const schemaPath = path.resolve(process.cwd(), 'database/schema.sql');
const sql = fs.readFileSync(schemaPath, 'utf8');

const statements = sql
  .split(';')
  .map((statement) => statement.trim())
  .filter(Boolean);

try {
  for (const statement of statements) {
    await pool.query(statement);
  }

  console.log('Schema applied successfully.');
  const tablesResult = await pool.query(
    "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
  );

  console.log('Tables created:', tablesResult.rows.map((row) => row.table_name).join(', '));
} catch (error) {
  console.error('Failed to apply schema:', error.message);
  process.exit(1);
} finally {
  await pool.end();
}
