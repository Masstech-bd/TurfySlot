import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Turf, Slot, Booking } from '../../types';
import { getBDDateString, getBDNow } from '../../utils/datetime';
import {
  Search,
  MapPin,
  Star,
  Clock,
  Shield,
  CreditCard,
  QrCode,
  Calendar,
  AlertCircle,
  CheckCircle2,
  X,
  Heart,
  HelpCircle,
  Sparkles,
  Users,
  ArrowRight,
  ArrowLeft,
  Trophy,
  Smartphone,
  ChevronRight,
  Share2,
  Award,
  Zap,
  Flame,
  UserPlus,
  Building2,
  TrendingUp,
  DollarSign,
  Check,
  Lock,
  ShieldCheck,
  SlidersHorizontal,
  RefreshCw,
  Headset,
  PlayCircle,
  Ticket,
  CircleCheck,
  LogIn,
} from 'lucide-react';
import { TurfySlotHome } from './TurfySlotHome';
import { SquadsView } from '../squads/SquadsView';
import { TournamentsView } from '../tournaments/TournamentsView';

import heroPlayerCleanImg from '../../assets/images/hero_player_clean_1788976334634.jpg';
import cityTurfMapImg from '../../assets/images/city_turf_map_1788975628489.jpg';
import completeTeamActionImg from '../../assets/images/complete_team_action_1788975639446.jpg';
import mobileAppMockupImg from '../../assets/images/mobile_app_mockup_1788975653380.jpg';
import turfStadiumNightImg from '../../assets/images/turf_stadium_night_1788976698343.jpg';

interface SquadMatch {
  id: string;
  turfName: string;
  area: string;
  sport: string;
  date: string;
  time: string;
  hostName: string;
  playersNeeded: number;
  totalPlayers: number;
  skillLevel: string;
}

export const PlayerPortal: React.FC = () => {
  const {
    turfs,
    slots,
    bookings,
    currentUser,
    isAuthenticated,
    openSignInModal,
    openGetStartedModal,
    switchRoleDirectly,
    lockSlot,
    lockSlots,
    unlockSlot,
    unlockSlots,
    createOnlineBooking,
    cancelBooking,
    addReview,
    raiseDispute,
    favorites,
    toggleFavorite,
    calculateRefund,
    playerActiveTab,
    setPlayerActiveTab,
    settings,
  } = useApp();

  const activeTab = playerActiveTab;
  const setActiveTab = setPlayerActiveTab;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSport, setSelectedSport] = useState<string>('All');
  const [selectedArea, setSelectedArea] = useState<string>('All');
  const [selectedTimeOfDay, setSelectedTimeOfDay] = useState<string>('all');

  // Hero Slider Images from User Design
  const heroSlides = [
    'https://images.unsplash.com/photo-1526232761682-d26e03ac148e?auto=format&fit=crop&w=2000&q=85',
    'https://images.unsplash.com/photo-1553778263-73a83bab9b0c?auto=format&fit=crop&w=2000&q=85',
    'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=2000&q=85',
    'https://images.unsplash.com/photo-1518600506278-4e8fe0e9e4b1?auto=format&fit=crop&w=2000&q=85',
  ];
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  // Turf Owner Calculator State
  const [calcRate, setCalcRate] = useState<number>(1600);
  const [calcHours, setCalcHours] = useState<number>(4);

  // Booking Flow State
  const [selectedTurf, setSelectedTurf] = useState<Turf | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(getBDDateString());
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [selectedBookingSlots, setSelectedBookingSlots] = useState<Slot[]>([]);
  const [bookingDurationHours, setBookingDurationHours] = useState<number>(1);
  const [lockExpiryAt, setLockExpiryAt] = useState<string | null>(null);
  const [lockTimerSeconds, setLockTimerSeconds] = useState<number>(600);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showSSLGateway, setShowSSLGateway] = useState(false);
  const [selectedGatewayId, setSelectedGatewayId] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [gatewaySessionUrl, setGatewaySessionUrl] = useState<string | null>(null);
  const [gatewayError, setGatewayError] = useState('');
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [selectedAddonQuantities, setSelectedAddonQuantities] = useState<Record<string, number>>({});

  const activeGateways = (settings.paymentGateways || []).filter((g) => g.isActive);
  const selectedGateway = activeGateways.find((g) => g.id === selectedGatewayId) || activeGateways[0];


  // Cancellation & Review Modal State
  const [bookingToCancel, setBookingToCancel] = useState<Booking | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelError, setCancelError] = useState('');
  const [bookingForReview, setBookingForReview] = useState<Booking | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [selectedBookingForQR, setSelectedBookingForQR] = useState<Booking | null>(null);
  const [disputeBooking, setDisputeBooking] = useState<Booking | null>(null);
  const [disputeDesc, setDisputeDesc] = useState('');
  const [disputeCategory, setDisputeCategory] = useState<'facility_unavailable' | 'refund_issue' | 'payment_mismatch' | 'other'>('facility_unavailable');

  // Squad Finder Modal State
  const [showSquadModal, setShowSquadModal] = useState(false);
  const [joinedSquadIds, setJoinedSquadIds] = useState<string[]>([]);
  const [squadMatches] = useState<SquadMatch[]>([
    {
      id: 'sq-1',
      turfName: 'Banani Turf Arena',
      area: 'Banani',
      sport: 'Football (7v7)',
      date: 'Tonight',
      time: '08:00 PM - 09:30 PM',
      hostName: 'Captain Tanvir',
      playersNeeded: 2,
      totalPlayers: 14,
      skillLevel: 'Intermediate / Friendly',
    },
    {
      id: 'sq-2',
      turfName: 'Dhanmondi Astro Arena',
      area: 'Dhanmondi',
      sport: 'Box Cricket (6v6)',
      date: 'Tomorrow Friday',
      time: '04:00 PM - 06:00 PM',
      hostName: 'Shakib R.',
      playersNeeded: 3,
      totalPlayers: 12,
      skillLevel: 'Casual & Fun',
    },
    {
      id: 'sq-3',
      turfName: 'Gulshan Futsal Hub',
      area: 'Gulshan',
      sport: 'Futsal (5v5)',
      date: 'Saturday',
      time: '09:00 PM - 10:30 PM',
      hostName: 'Miraz Hossain',
      playersNeeded: 1,
      totalPlayers: 10,
      skillLevel: 'Competitive Fast-Paced',
    },
  ]);

  // Filter Active Public Turfs
  const publicTurfs = turfs.filter((t) => t.status === 'active');
  const sportsList = ['All', 'Football', 'Cricket', 'Futsal', 'Badminton'];
  const uniqueAreas = Array.from(new Set(publicTurfs.map((t) => t.area)));
  const areasList = ['All', ...uniqueAreas];

  const filteredTurfs = publicTurfs.filter((turf) => {
    const matchesSearch =
      turf.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      turf.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
      turf.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSport = selectedSport === 'All' || turf.sportTypes.includes(selectedSport);
    const matchesArea =
      selectedArea === 'All' ||
      turf.area.toLowerCase() === selectedArea.toLowerCase() ||
      turf.city.toLowerCase() === selectedArea.toLowerCase();
    return matchesSearch && matchesSport && matchesArea;
  });

  const myBookings = bookings.filter((b) => b.playerId === currentUser.id || b.customerPhone === currentUser.phone);

  // Available dates for selector (today, tomorrow, +2d, +3d) — anchored to GMT+6
  const dateOptions = [0, 1, 2, 3].map((offset) => {
    const d = getBDNow();
    d.setDate(d.getDate() + offset);
    const dateStr = getBDDateString(offset);
    const label =
      offset === 0 ? 'Today' : offset === 1 ? 'Tomorrow' : d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    return { dateStr, label };
  });

  const turfSlotsForSelectedDate = selectedTurf
    ? slots.filter((s) => s.turfId === selectedTurf.id && s.date === selectedDate)
    : [];

  const slotsByTurf = React.useMemo(() => {
    const acc: Record<string, Slot[]> = {};
    for (const turf of turfs) {
      acc[turf.id] = slots.filter((s) => s.turfId === turf.id && s.date === selectedDate);
    }
    return acc;
  }, [turfs, slots, selectedDate]);

  const parseTimeToMinutes = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const formatLockTimer = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
  };

  const resetLockedSelection = () => {
    if (selectedBookingSlots.length > 0) {
      unlockSlots(selectedBookingSlots.map((item) => item.id));
    }
    setSelectedSlot(null);
    setSelectedBookingSlots([]);
    setBookingDurationHours(1);
    setLockExpiryAt(null);
    setLockTimerSeconds(600);
  };

  const handleSelectSlot = (slot: Slot) => {
    const isOwnedLockedSlot = slot.status === 'locked' && slot.lockedByUserId === currentUser.id;

    if (slot.status !== 'available' && !isOwnedLockedSlot) return;

    const currentSelection = [...selectedBookingSlots];
    const isCurrentlySelected = currentSelection.some((item) => item.id === slot.id);

    if (isCurrentlySelected) {
      const nextSelection = currentSelection.filter((item) => item.id !== slot.id);
      unlockSlot(slot.id);

      if (nextSelection.length === 0) {
        setSelectedSlot(null);
        setSelectedBookingSlots([]);
        setBookingDurationHours(1);
        setLockExpiryAt(null);
        setLockTimerSeconds(600);
        return;
      }

      setSelectedBookingSlots(nextSelection);
      setSelectedSlot(nextSelection[0]);
      setBookingDurationHours(nextSelection.length);
      return;
    }

    if (currentSelection.length === 0) {
      const nextSelection = [slot];
      setSelectedSlot(slot);
      setSelectedBookingSlots(nextSelection);
      setBookingDurationHours(1);
      setLockExpiryAt(new Date(Date.now() + 10 * 60 * 1000).toISOString());
      setLockTimerSeconds(600);
      lockSlot(slot.id);
      return;
    }

    const currentFirst = currentSelection[0];
    const currentLast = currentSelection[currentSelection.length - 1];
    const slotStartMinutes = parseTimeToMinutes(slot.startTime);
    const slotEndMinutes = parseTimeToMinutes(slot.endTime);
    const firstStartMinutes = parseTimeToMinutes(currentFirst.startTime);
    const lastEndMinutes = parseTimeToMinutes(currentLast.endTime);

    const isAdjacentBefore = slotEndMinutes === firstStartMinutes;
    const isAdjacentAfter = slotStartMinutes === lastEndMinutes;

    if (!isAdjacentBefore && !isAdjacentAfter) {
      const shouldReplace = window.confirm('This slot is not adjacent to your current selection. Clear the current selection and choose this slot instead?');
      if (!shouldReplace) return;

      unlockSlots(currentSelection.map((item) => item.id));
      const nextSelection = [slot];
      setSelectedSlot(slot);
      setSelectedBookingSlots(nextSelection);
      setBookingDurationHours(1);
      setLockExpiryAt(new Date(Date.now() + 10 * 60 * 1000).toISOString());
      setLockTimerSeconds(600);
      lockSlot(slot.id);
      return;
    }

    const nextSelection = isAdjacentBefore ? [slot, ...currentSelection] : [...currentSelection, slot];
    setSelectedBookingSlots(nextSelection);
    setSelectedSlot(nextSelection[0]);
    setBookingDurationHours(nextSelection.length);
    lockSlot(slot.id);
  };

  const handleContinueBooking = () => {
    const effectiveBookingSlots =
      selectedBookingSlots.length > 0
        ? selectedBookingSlots
        : slots.filter(
            (slot) => slot.status === 'locked' && slot.lockedByUserId === currentUser.id && (!selectedTurf || slot.turfId === selectedTurf.id)
          );

    if (effectiveBookingSlots.length === 0) return;

    const firstSelectedSlot = effectiveBookingSlots[0];
    const matchedTurf = turfs.find((turf) => turf.id === firstSelectedSlot.turfId) || selectedTurf;

    if (matchedTurf) {
      setSelectedTurf(matchedTurf);
    }

    setSelectedBookingSlots(effectiveBookingSlots);
    setSelectedSlot(firstSelectedSlot);
    setShowCheckoutModal(true);
  };

  const handleProceedToPayment = () => {
    setShowCheckoutModal(false);
    setGatewayError('');
    setGatewaySessionUrl(null);
    if (!selectedGatewayId && activeGateways[0]) {
      setSelectedGatewayId(activeGateways[0].id);
    }
    setShowSSLGateway(true);
  };

  const turfAddons = selectedTurf?.addons?.filter((addon) => addon.isActive) || [];
  const selectedBookingWindow = selectedBookingSlots;
  const bookingBaseAmount = selectedBookingWindow.reduce((sum, slot) => sum + slot.price, 0);
  const addonSubtotal = turfAddons.reduce((sum, addon) => {
    const quantity = selectedAddonQuantities[addon.id] || 0;
    return sum + addon.price * quantity;
  }, 0);

  const totalPayable =
    bookingBaseAmount +
    addonSubtotal +
    Math.round((bookingBaseAmount + addonSubtotal) * 0.05) +
    Math.round((bookingBaseAmount + addonSubtotal + Math.round((bookingBaseAmount + addonSubtotal) * 0.05)) * 0.025);

  const finalizeBooking = () => {
    const booking = createOnlineBooking(
      selectedBookingWindow.map((slot) => slot.id),
      'sslcommerz',
      Object.entries(selectedAddonQuantities)
        .filter(([, quantity]) => quantity > 0)
        .map(([addonId, quantity]) => ({ addonId, quantity }))
    );
    setIsProcessingPayment(false);
    setShowSSLGateway(false);
    setGatewaySessionUrl(null);
    if (booking) {
      setConfirmedBooking(booking);
      setSelectedSlot(null);
      setSelectedBookingSlots([]);
      setBookingDurationHours(1);
      setSelectedAddonQuantities({});
    }
  };

  // Real SSLCommerz sandbox/live session — opens the actual gateway checkout page in a new tab.
  const handleStartSslcommerzCheckout = async () => {
    if (!selectedGateway || selectedBookingWindow.length === 0) return;
    setGatewayError('');
    setIsProcessingPayment(true);
    try {
      const response = await fetch('http://localhost:5000/api/payments/sslcommerz/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeId: selectedGateway.storeId,
          storePassword: selectedGateway.apiSecret,
          isSandbox: selectedGateway.isSandbox,
          amount: totalPayable,
          bookingNumber: `${Date.now()}`,
          customerName: currentUser.name,
          customerEmail: currentUser.email,
          customerPhone: currentUser.phone,
        }),
      });
      const data = await response.json();
      if (!data.success) {
        setGatewayError(data.message || 'Unable to start SSLCommerz session.');
        setIsProcessingPayment(false);
        return;
      }
      setGatewaySessionUrl(data.gatewayPageURL);
      window.open(data.gatewayPageURL, '_blank', 'noopener,noreferrer');
    } catch (error) {
      setGatewayError('Could not reach the payment server. Is the backend (server.js) running on port 5000?');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleSimulatePaymentSuccess = () => {
    if (!selectedSlot || selectedBookingWindow.length === 0) return;
    setIsProcessingPayment(true);
    setTimeout(() => {
      finalizeBooking();
    }, 1200);
  };

  useEffect(() => {
    if (!lockExpiryAt) {
      setLockTimerSeconds(600);
      return;
    }

    const tick = () => {
      const remainingSeconds = Math.max(0, Math.ceil((new Date(lockExpiryAt).getTime() - Date.now()) / 1000));
      setLockTimerSeconds(remainingSeconds);

      if (remainingSeconds <= 0) {
        unlockSlots(selectedBookingSlots.map((item) => item.id));
        setSelectedSlot(null);
        setSelectedBookingSlots([]);
        setBookingDurationHours(1);
        setLockExpiryAt(null);
      }
    };

    tick();
    const interval = window.setInterval(tick, 1000);

    return () => window.clearInterval(interval);
  }, [lockExpiryAt, selectedBookingSlots, unlockSlots]);

  const scrollToTurfs = () => {
    const el = document.getElementById('turf-explorer-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleJoinSquad = (squadId: string) => {
    if (!joinedSquadIds.includes(squadId)) {
      setJoinedSquadIds((prev) => [...prev, squadId]);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-100 selection:bg-[#C8FF5E] selection:text-[#0A1E14] font-sans">
      {/* ========================================================================= */}
      {/* 1. EXPLORE & HOME PAGE: BESPOKE MODERN SPORTS MARKETPLACE DESIGN          */}
      {/* ========================================================================= */}
      {/* 1. EXPLORE & HOME PAGE: HIGH-CONVERSION MODERN ARCHITECTURAL DESIGN      */}
      {/* ========================================================================= */}
      {activeTab === 'explore' && (
        <TurfySlotHome
          filteredTurfs={filteredTurfs}
          slotsByTurf={slotsByTurf}
          selectedTurf={selectedTurf}
          setSelectedTurf={setSelectedTurf}
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
          selectedSport={selectedSport}
          setSelectedSport={setSelectedSport}
          selectedArea={selectedArea}
          setSelectedArea={setSelectedArea}
          favorites={favorites}
          toggleFavorite={toggleFavorite}
          handleSelectSlot={(turf, slot) => {
            setSelectedTurf(turf);
            handleSelectSlot(slot);
          }}
          selectedBookingSlots={selectedBookingSlots}
          onContinueBooking={handleContinueBooking}
          switchRoleDirectly={switchRoleDirectly}
          squadMatches={squadMatches}
          joinedSquadIds={joinedSquadIds}
          handleJoinSquad={handleJoinSquad}
          setShowSquadModal={setShowSquadModal}
          setActiveTab={setActiveTab}
        />
      )}

      {/* ========================================================================= */}
      {/* 2. MY BOOKINGS TAB (HISTORIC TICKETS, CANCELLATION, QR PASS, REVIEWS)     */}
      {/* ========================================================================= */}
      {activeTab === 'my_bookings' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {/* Sub Navigation Bar for Player */}
          <div className="flex items-center gap-2 bg-[#0A1E14] border border-white/10 p-1.5 rounded-2xl w-fit flex-wrap">
            <button
              onClick={() => setActiveTab('explore')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Explore All Turfs</span>
            </button>
            <button
              onClick={() => setActiveTab('my_bookings')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer flex items-center gap-2"
            >
              <Ticket className="w-3.5 h-3.5" />
              <span>My Bookings & Passes ({myBookings.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('squads')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Squad Finder (Sec 49)</span>
            </button>
            <button
              onClick={() => setActiveTab('tournaments')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Tournaments (Sec 50)</span>
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Heart className="w-3.5 h-3.5" />
              <span>Saved Grounds ({favorites.length})</span>
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-[10px] font-bold tracking-wider uppercase rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] border border-[#C8FF5E]/30">
                  Player Dashboard
                </span>
                <span className="text-xs text-white/60">Welcome, {currentUser.name}</span>
              </div>
              <h2 className="text-2xl font-black text-white mt-1">My Booking History & Match Passes</h2>
              <p className="text-xs text-white/60">View upcoming slots, access counter check-in QR codes, or manage cancellations.</p>
            </div>
            <span className="text-xs px-3.5 py-1.5 rounded-full bg-[#0A1E14] text-[#C8FF5E] font-bold border border-[#C8FF5E]/30 w-fit">
              {myBookings.length} total reservations
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myBookings.map((b) => {
              const isCompleted = b.status === 'completed';
              const isConfirmed = b.status === 'confirmed' || b.status === 'checked_in';
              const isCancelled = b.status === 'cancelled' || b.status === 'refunded';

              return (
                <div
                  key={b.id}
                  className="bg-[#0e271a] border border-white/10 hover:border-[#C8FF5E]/30 transition-all rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden shadow-xl"
                >
                  {/* Status Ribbon */}
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div>
                      <span className="text-[11px] font-mono text-[#C8FF5E] font-bold">{b.bookingNumber}</span>
                      <div className="text-xs text-white/60 font-medium capitalize">Channel: {b.bookingSource.replace('_', ' ')}</div>
                    </div>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                        isConfirmed
                          ? 'bg-[#C8FF5E]/15 text-[#C8FF5E] border-[#C8FF5E]/30'
                          : isCompleted
                          ? 'bg-blue-500/20 text-blue-400 border-blue-500/30'
                          : 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                      }`}
                    >
                      {b.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="my-4 space-y-2">
                    <h4 className="font-bold text-white text-base">{b.turfName}</h4>
                    <div className="flex items-center gap-4 text-xs text-white/80">
                      <span className="flex items-center gap-1 text-white/60">
                        <Calendar className="w-3.5 h-3.5 text-[#C8FF5E]" /> {b.date}
                      </span>
                      <span className="flex items-center gap-1 text-white/60">
                        <Clock className="w-3.5 h-3.5 text-[#C8FF5E]" /> {b.startTime} - {b.endTime}
                      </span>
                    </div>
                    <div className="text-xs text-white/60 flex items-center justify-between pt-1">
                      <span>Total Paid:</span>
                      <span className="font-bold text-[#C8FF5E] text-base">৳{b.totalPaid.toLocaleString()}</span>
                    </div>
                    {b.refundAmount && b.refundAmount > 0 && (
                      <div className="text-xs text-emerald-400 font-semibold flex items-center justify-between">
                        <span>Refund Credited:</span>
                        <span>৳{b.refundAmount.toLocaleString()}</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedBookingForQR(b)}
                        className="px-3.5 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Show QR Pass</span>
                      </button>

                      {isConfirmed && (
                        <button
                          onClick={() => setActiveTab('squads')}
                          className="px-3 py-2 bg-white/[0.08] hover:bg-white/[0.14] text-[#C8FF5E] border border-[#C8FF5E]/30 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                          title="Recruit players for this match via Section 49 Squads"
                        >
                          <Users className="w-3.5 h-3.5" />
                          <span>Host Open Match</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {isConfirmed && (
                        <button
                          onClick={() => {
                            setBookingToCancel(b);
                            setCancelError('');
                          }}
                          className="px-3 py-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}

                      {isCompleted && (
                        <button
                          onClick={() => setBookingForReview(b)}
                          className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Star className="w-3.5 h-3.5 fill-amber-400" />
                          <span>Review</span>
                        </button>
                      )}

                      <button
                        onClick={() => setDisputeBooking(b)}
                        className="p-1.5 text-white/50 hover:text-white rounded-lg"
                        title="Need help or file dispute"
                      >
                        <HelpCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}

            {myBookings.length === 0 && (
              <div className="col-span-full text-center py-16 bg-[#0b121e] border border-slate-800 rounded-2xl">
                <Calendar className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white">No Bookings Yet</h3>
                <p className="text-xs text-slate-400 mt-1">Explore turfs and book your first slot today!</p>
                <button
                  onClick={() => setActiveTab('explore')}
                  className="mt-4 px-5 py-2 bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl"
                >
                  Explore Turfs Now
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. FAVORITES TAB                                                         */}
      {/* ========================================================================= */}
      {activeTab === 'favorites' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          {/* Sub Navigation Bar for Player */}
          <div className="flex items-center gap-2 bg-[#0A1E14] border border-white/10 p-1.5 rounded-2xl w-fit flex-wrap">
            <button
              onClick={() => setActiveTab('explore')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Explore All Turfs</span>
            </button>
            <button
              onClick={() => setActiveTab('my_bookings')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Ticket className="w-3.5 h-3.5" />
              <span>My Bookings & Passes ({myBookings.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('squads')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Squad Finder (Sec 49)</span>
            </button>
            <button
              onClick={() => setActiveTab('tournaments')}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Tournaments (Sec 50)</span>
            </button>
            <button
              onClick={() => setActiveTab('favorites')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer flex items-center gap-2"
            >
              <Heart className="w-3.5 h-3.5" />
              <span>Saved Grounds ({favorites.length})</span>
            </button>
          </div>

          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h2 className="text-2xl font-black text-white">Saved Favorite Grounds</h2>
              <p className="text-xs text-white/60">Quick access to your preferred sports venues.</p>
            </div>
            <span className="text-xs px-3.5 py-1.5 rounded-full bg-[#0A1E14] text-[#C8FF5E] font-bold border border-[#C8FF5E]/30">
              {favorites.length} saved
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {turfs
              .filter((t) => favorites.includes(t.id))
              .map((turf) => (
                <div key={turf.id} className="bg-[#0e271a] border border-white/10 hover:border-[#C8FF5E]/30 transition-all rounded-2xl p-5 flex flex-col justify-between shadow-xl">
                  <div>
                    <h3 className="font-bold text-white text-base">{turf.name}</h3>
                    <p className="text-xs text-white/60 mt-1">{turf.address}</p>
                    <div className="text-xs font-bold text-[#C8FF5E] mt-3">
                      ৳{turf.basePricePerHour.toLocaleString()} / hr
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-white/10 flex justify-between items-center">
                    <button
                      onClick={() => toggleFavorite(turf.id)}
                      className="text-xs text-rose-400 hover:underline cursor-pointer"
                    >
                      Remove Favorite
                    </button>
                    <button
                      onClick={() => {
                        setSelectedTurf(turf);
                        setActiveTab('explore');
                      }}
                      className="px-4 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl cursor-pointer"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              ))}

            {favorites.length === 0 && (
              <div className="col-span-full text-center py-16 bg-[#0A1E14] border border-white/10 rounded-3xl p-8">
                <Heart className="w-12 h-12 text-[#C8FF5E]/40 mx-auto mb-3" />
                <h3 className="text-lg font-bold text-white">No Saved Favorites</h3>
                <p className="text-xs text-white/60 mt-1">Tap the heart icon on any turf card to save it for later.</p>
                <button
                  onClick={() => setActiveTab('explore')}
                  className="mt-4 px-6 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-full cursor-pointer"
                >
                  Explore Turfs
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. SQUAD FINDER (SECTION 49: OPEN MATCHES & TEAM MATCHMAKING)             */}
      {/* ========================================================================= */}
      {activeTab === 'squads' && (
        !isAuthenticated ? (
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="bg-[#0A1E14] border border-white/10 rounded-3xl p-8 sm:p-12 text-center shadow-2xl space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-72 h-72 bg-[#C8FF5E]/5 rounded-full blur-3xl pointer-events-none" />

              <div className="w-16 h-16 rounded-2xl bg-[#C8FF5E]/15 border border-[#C8FF5E]/30 flex items-center justify-center mx-auto text-[#C8FF5E] shadow-lg shadow-[#C8FF5E]/10">
                <Lock className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] text-xs font-bold border border-[#C8FF5E]/30">
                  <Users className="w-3.5 h-3.5" />
                  <span>Section 49 • Squad Matchmaking</span>
                </div>
                <h2 className="font-playfair text-2xl sm:text-3xl font-extrabold text-white">
                  Login Required to View Squads
                </h2>
                <p className="text-sm text-white/70 max-w-lg mx-auto leading-relaxed">
                  স্কোয়াড ফাইন্ডার এবং ওপেন ম্যাচ দেখতে অনুগ্রহ করে আপনার প্লেয়ার অ্যাকাউন্টে লগইন করুন। লগইন করার পর আপনি সরাসরি ওপেন ম্যাচে অংশ নিতে পারবেন এবং দলের সাথে যোগাযোগ করতে পারবেন।
                </p>
                <p className="text-xs text-white/50 max-w-md mx-auto">
                  Only registered and logged-in players can access open match rosters, view match details, and join team matchmaking.
                </p>
              </div>

              {/* Benefits list */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-left max-w-xl mx-auto">
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Join Open Matches</span>
                  </div>
                  <p className="text-[11px] text-white/60">Hop into unfilled casual or competitive slots anytime.</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Host Your Squad</span>
                  </div>
                  <p className="text-[11px] text-white/60">Recruit extra players for your confirmed turf bookings.</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Connect &amp; Play</span>
                  </div>
                  <p className="text-[11px] text-white/60">Direct phone contact with captains. Split costs in person.</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => openSignInModal('player')}
                  className="w-full sm:w-auto px-6 py-3 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black text-xs sm:text-sm rounded-full transition-all shadow-lg shadow-[#C8FF5E]/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Login / Sign In to Continue</span>
                </button>
                <button
                  type="button"
                  onClick={() => openGetStartedModal('player')}
                  className="w-full sm:w-auto px-6 py-3 bg-white/[0.08] hover:bg-white/[0.14] text-white font-bold text-xs sm:text-sm rounded-full transition-all border border-white/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-4 h-4 text-[#C8FF5E]" />
                  <span>Create Free Player Account</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('explore')}
                  className="w-full sm:w-auto px-5 py-3 text-white/60 hover:text-white text-xs font-semibold rounded-full transition-all cursor-pointer"
                >
                  Back to Explore Turfs
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            {/* Sub Navigation Bar for Player */}
            <div className="flex items-center gap-2 bg-[#0A1E14] border border-white/10 p-1.5 rounded-2xl w-fit flex-wrap">
              <button
                onClick={() => setActiveTab('explore')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Explore All Turfs</span>
              </button>
              <button
                onClick={() => setActiveTab('my_bookings')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Ticket className="w-3.5 h-3.5" />
                <span>My Bookings & Passes ({myBookings.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('squads')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer flex items-center gap-2"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Squad Finder (Sec 49)</span>
              </button>
              <button
                onClick={() => setActiveTab('tournaments')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Tournaments (Sec 50)</span>
              </button>
              <button
                onClick={() => setActiveTab('favorites')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Heart className="w-3.5 h-3.5" />
                <span>Saved Grounds ({favorites.length})</span>
              </button>
            </div>

            <SquadsView onBackToExplore={() => setActiveTab('explore')} />
          </div>
        )
      )}

      {/* ========================================================================= */}
      {/* 5. TOURNAMENTS & BRACKETS (SECTION 50: CUPS & LEAGUE PLAY)               */}
      {/* ========================================================================= */}
      {activeTab === 'tournaments' && (
        !isAuthenticated ? (
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="bg-[#0A1E14] border border-white/10 rounded-3xl p-8 sm:p-12 text-center shadow-2xl space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-72 h-72 bg-[#C8FF5E]/5 rounded-full blur-3xl pointer-events-none" />

              <div className="w-16 h-16 rounded-2xl bg-[#C8FF5E]/15 border border-[#C8FF5E]/30 flex items-center justify-center mx-auto text-[#C8FF5E] shadow-lg shadow-[#C8FF5E]/10">
                <Lock className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] text-xs font-bold border border-[#C8FF5E]/30">
                  <Trophy className="w-3.5 h-3.5" />
                  <span>Section 50 • Tournaments &amp; Brackets</span>
                </div>
                <h2 className="font-playfair text-2xl sm:text-3xl font-extrabold text-white">
                  Login Required to View Tournaments
                </h2>
                <p className="text-sm text-white/70 max-w-lg mx-auto leading-relaxed">
                  টুর্নামেন্ট ফিক্সচার, ব্র্যাকেট এবং টিম রেজিস্ট্রেশন দেখতে অনুগ্রহ করে আপনার প্লেয়ার অ্যাকাউন্টে লগইন করুন। লগইন করার পর আপনি টুর্নামেন্টের সমস্ত তথ্য দেখতে পারবেন এবং টিম এন্ট্রি করতে পারবেন।
                </p>
                <p className="text-xs text-white/50 max-w-md mx-auto">
                  Only registered and logged-in players can explore tournament prize pools, inspect knockout brackets, and register competitive teams.
                </p>
              </div>

              {/* Benefits list */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-left max-w-xl mx-auto">
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Track Live Brackets</span>
                  </div>
                  <p className="text-[11px] text-white/60">Follow knockout rounds, quarters, semis &amp; finals in real time.</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Register Your Squad</span>
                  </div>
                  <p className="text-[11px] text-white/60">Enter your team into official weekend cups and leagues.</p>
                </div>
                <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                  <div className="text-[#C8FF5E] font-bold text-xs flex items-center gap-1.5 mb-1">
                    <CircleCheck className="w-3.5 h-3.5" />
                    <span>Verified Grounds</span>
                  </div>
                  <p className="text-[11px] text-white/60">Organized exclusively at verified, premium partner grounds.</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => openSignInModal('player')}
                  className="w-full sm:w-auto px-6 py-3 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-black text-xs sm:text-sm rounded-full transition-all shadow-lg shadow-[#C8FF5E]/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>Login / Sign In to Continue</span>
                </button>
                <button
                  type="button"
                  onClick={() => openGetStartedModal('player')}
                  className="w-full sm:w-auto px-6 py-3 bg-white/[0.08] hover:bg-white/[0.14] text-white font-bold text-xs sm:text-sm rounded-full transition-all border border-white/20 cursor-pointer flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-4 h-4 text-[#C8FF5E]" />
                  <span>Create Free Player Account</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('explore')}
                  className="w-full sm:w-auto px-5 py-3 text-white/60 hover:text-white text-xs font-semibold rounded-full transition-all cursor-pointer"
                >
                  Back to Explore Turfs
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            {/* Sub Navigation Bar for Player */}
            <div className="flex items-center gap-2 bg-[#0A1E14] border border-white/10 p-1.5 rounded-2xl w-fit flex-wrap">
              <button
                onClick={() => setActiveTab('explore')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Explore All Turfs</span>
              </button>
              <button
                onClick={() => setActiveTab('my_bookings')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Ticket className="w-3.5 h-3.5" />
                <span>My Bookings & Passes ({myBookings.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('squads')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Squad Finder (Sec 49)</span>
              </button>
              <button
                onClick={() => setActiveTab('tournaments')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer flex items-center gap-2"
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Tournaments (Sec 50)</span>
              </button>
              <button
                onClick={() => setActiveTab('favorites')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white/70 hover:text-white hover:bg-white/[0.06] transition-all cursor-pointer flex items-center gap-2"
              >
                <Heart className="w-3.5 h-3.5" />
                <span>Saved Grounds ({favorites.length})</span>
              </button>
            </div>

            <TournamentsView onBackToExplore={() => setActiveTab('explore')} />
          </div>
        )
      )}

      {/* ========================================================================= */}
      {/* SQUAD FINDER / COMMUNITY MATCHMAKER MODAL                                 */}
      {/* ========================================================================= */}
      {showSquadModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0b121e] border border-emerald-500/40 w-full max-w-2xl rounded-2xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Complete Your Team • Open Matches</h3>
                  <p className="text-xs text-slate-400">Join players needing squad members for matches in Dhaka</p>
                </div>
              </div>
              <button onClick={() => setShowSquadModal(false)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 max-h-96 overflow-y-auto pr-1">
              {squadMatches.map((m) => {
                const isJoined = joinedSquadIds.includes(m.id);
                return (
                  <div
                    key={m.id}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-700 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-emerald-400">{m.sport}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold">
                          {m.area}
                        </span>
                        <span className="text-[10px] text-slate-400">{m.skillLevel}</span>
                      </div>
                      <h4 className="font-bold text-white text-sm">{m.turfName}</h4>
                      <div className="text-xs text-slate-400 flex items-center gap-3">
                        <span>📅 {m.date}</span>
                        <span>⏰ {m.time}</span>
                        <span>👤 Captain: {m.hostName}</span>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2">
                      <span className="text-[11px] font-bold text-amber-400">
                        Needs {m.playersNeeded} player{m.playersNeeded > 1 ? 's' : ''}
                      </span>
                      <button
                        onClick={() => handleJoinSquad(m.id)}
                        disabled={isJoined}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                          isJoined
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 cursor-default'
                            : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md'
                        }`}
                      >
                        {isJoined ? 'Joined Squad ✓' : 'Join Match'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Looking to host your own match? Book any turf slot and post an open challenge for free!</span>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: TURF DETAIL & SLOT PICKER                                        */}
      {/* ========================================================================= */}
      {selectedTurf && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-hidden">
          <div className="bg-[#0b121e] border border-slate-800 w-full max-w-3xl rounded-2xl overflow-hidden shadow-2xl my-8 max-h-[calc(100vh-2rem)] flex flex-col min-h-0">
            {/* Header with image */}
            <div className="relative h-56 bg-slate-900">
              <img
                src={selectedTurf.photos[0] || 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=1000&q=85'}
                alt={selectedTurf.name}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=1000&q=85';
                }}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => {
                  resetLockedSelection();
                  setSelectedTurf(null);
                }}
                className="absolute top-3 right-3 p-2 rounded-full bg-slate-950/70 text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-3 left-4 bg-slate-950/85 backdrop-blur-md px-3.5 py-1.5 rounded-lg border border-slate-800">
                <h3 className="text-lg font-black text-white">{selectedTurf.name}</h3>
                <p className="text-xs text-slate-300 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" /> {selectedTurf.address}
                </p>
              </div>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto p-6 space-y-6">
              {/* Description & Amenities */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">About Turf</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedTurf.description}</p>
                <div className="flex flex-wrap gap-2 mt-3">
                  {selectedTurf.amenities.map((a) => (
                    <span
                      key={a}
                      className="px-2.5 py-1 rounded-md bg-slate-900 text-[11px] text-slate-300 border border-slate-800 flex items-center gap-1"
                    >
                      <Sparkles className="w-3 h-3 text-emerald-400" /> {a}
                    </span>
                  ))}
                </div>
              </div>

              {/* Date Selector */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-400" /> Select Date
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {dateOptions.map(({ dateStr, label }) => (
                    <button
                      key={dateStr}
                      onClick={() => setSelectedDate(dateStr)}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedDate === dateStr
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-xs">{label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{dateStr}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Slots Grid */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-emerald-400" /> Available Time Slots
                  </h4>
                  <div className="flex items-center gap-3 text-[10px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Available
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-600"></span> Booked
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Blocked
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {turfSlotsForSelectedDate.map((slot) => {
                    const isAvailable = slot.status === 'available';
                    const isLocked = slot.status === 'locked';
                    const isOwnedLockedSlot = isLocked && slot.lockedByUserId === currentUser.id;
                    const isBooked = slot.status === 'booked';
                    const isBlocked = slot.status === 'blocked';
                    const isClickable = isAvailable || isOwnedLockedSlot;

                    return (
                      <button
                        key={slot.id}
                        disabled={!isClickable}
                        onClick={() => handleSelectSlot(slot)}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isAvailable
                            ? 'bg-slate-900 border-slate-700 hover:border-emerald-500 hover:bg-emerald-950/20 text-white cursor-pointer'
                            : isOwnedLockedSlot
                            ? 'bg-amber-950/20 border-amber-800/40 text-amber-300 opacity-90 cursor-pointer'
                            : isLocked
                            ? 'bg-amber-950/20 border-amber-800/40 text-amber-300 opacity-80 cursor-not-allowed'
                            : isBlocked
                            ? 'bg-rose-950/20 border-rose-900/40 text-rose-400 opacity-60 cursor-not-allowed'
                            : 'bg-slate-900/30 border-slate-900 text-slate-500 cursor-not-allowed line-through'
                        }`}
                      >
                        <div className="text-xs font-bold">
                          {slot.startTime} - {slot.endTime}
                        </div>
                        <div className="text-[11px] text-emerald-400 font-semibold mt-1">
                          ৳{slot.price.toLocaleString()}
                        </div>
                        <div className="text-[9px] uppercase tracking-wider font-bold mt-1">
                          {isAvailable ? 'Click to Hold' : isOwnedLockedSlot ? 'Click to Unlock' : slot.status}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {turfSlotsForSelectedDate.length === 0 && (
                  <p className="text-xs text-slate-400 py-6 text-center bg-slate-900 rounded-xl">
                    No slots configured for this date yet. Check back or select another day.
                  </p>
                )}
              </div>

              {selectedBookingSlots.length > 0 && (
                <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 shadow-[0_12px_30px_rgba(16,185,129,0.12)]">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:gap-4">
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-emerald-300/80">Selected Booking</div>
                        <div className="mt-1 text-sm font-bold text-white">
                          {selectedBookingSlots[0].startTime} - {selectedBookingSlots[selectedBookingSlots.length - 1].endTime}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                        <span className="rounded-full bg-emerald-500/20 px-2 py-1 text-emerald-300">
                          {selectedBookingSlots.length} hour{selectedBookingSlots.length > 1 ? 's' : ''}
                        </span>
                        <span className="rounded-full bg-slate-900 px-2 py-1 text-white">
                          ৳{selectedBookingSlots.reduce((sum, slot) => sum + slot.price, 0).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleContinueBooking}
                      className="inline-flex items-center justify-center rounded-full bg-emerald-500 px-5 py-2.5 text-xs font-extrabold uppercase tracking-[0.08em] text-slate-950 shadow-[0_4px_16px_rgba(16,185,129,0.35)] transition hover:bg-emerald-400"
                    >
                      Continue
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: 10-MINUTE HOLD & TRANSPARENT PRICING CHECKOUT                     */}
      {/* ========================================================================= */}
      {showCheckoutModal && selectedSlot && selectedTurf && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-[560px] max-h-[90vh] rounded-[24px] border border-white/10 bg-[#0d1512] shadow-[0_25px_80px_rgba(0,0,0,0.6)] overflow-hidden">
            <div className="relative z-10 flex items-start justify-between gap-3 border-b border-white/10 bg-[#0d1512]/95 p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
                  <Clock className="h-4 w-4" />
                </div>

                <div>
                  <h3 className="text-[18px] font-bold tracking-[-0.3px] text-white">Slot Held for You (10 Min)</h3>
                  <p className="mt-1 text-[12px] text-slate-300">
                    Lock expires in <span className="font-semibold text-emerald-400">{formatLockTimer(lockTimerSeconds)}</span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  unlockSlots(selectedBookingSlots.map((slot) => slot.id));
                  setSelectedBookingSlots([]);
                  setShowCheckoutModal(false);
                }}
                className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 transition hover:border-rose-500/30 hover:bg-rose-500/10 hover:text-rose-400"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="modal-scroll relative z-0 flex max-h-[calc(90vh-156px)] min-h-0 flex-col gap-4 overflow-y-auto overflow-x-hidden p-5">
              <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3.5">
                <div className="flex items-center gap-2 text-[15px] font-bold text-white">
                  <span className="text-emerald-400">
                    <Building2 className="h-4 w-4" />
                  </span>
                  {selectedTurf.name}
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-4 text-[12px] text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Date:</span>
                    <span className="font-semibold text-emerald-400">{selectedSlot.date}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-emerald-400" />
                    <span>Time:</span>
                    <span className="font-semibold text-emerald-400">
                      {selectedBookingWindow[0]?.startTime ?? selectedSlot.startTime} - {selectedBookingWindow[selectedBookingWindow.length - 1]?.endTime ?? selectedSlot.endTime}
                    </span>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl border border-white/10 bg-[#101b18] p-3.5">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-[1.2px] text-slate-400">Booking Duration</div>
                    <div className="mt-1 text-[12px] text-slate-300">
                      {selectedBookingWindow.length} hour{selectedBookingWindow.length > 1 ? 's' : ''} selected
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#0b1412] p-1">
                    {Array.from({ length: Math.max(1, selectedBookingSlots.length) }, (_, index) => index + 1).map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setBookingDurationHours(option)}
                        className={`flex h-8 min-w-[52px] items-center justify-center rounded-lg px-2 text-[11px] font-extrabold tracking-[0.2px] transition-all ${
                          bookingDurationHours === option
                            ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-[0_4px_16px_rgba(200,255,94,0.32)]'
                            : 'bg-transparent text-slate-300 hover:bg-white/[0.04] hover:text-white'
                        }`}
                      >
                        {option}h
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {turfAddons.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold uppercase tracking-[1.2px] text-slate-400">Optional Add-ons</div>

                  <div className="space-y-2">
                    {turfAddons.map((addon) => {
                      const quantity = selectedAddonQuantities[addon.id] || 0;
                      const isOutOfStock = addon.stockQuantity !== null && addon.stockQuantity !== undefined && addon.stockQuantity <= 0;
                      const maxQuantity = addon.stockQuantity ?? 99;

                      return (
                        <div
                          key={addon.id}
                          className={`rounded-xl border p-3 transition-all ${
                            quantity > 0
                              ? 'border-emerald-500/30 bg-emerald-500/5'
                              : 'border-white/10 bg-white/[0.02]'
                          }`}
                        >
                          <div className="grid grid-cols-[1fr_auto] items-center gap-3">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-[13px] font-semibold text-white">{addon.name}</span>
                                <span className="text-[12px] font-bold text-emerald-400">৳{addon.price.toLocaleString()}</span>
                              </div>

                              {addon.description && (
                                <div className="mt-1 text-[11px] text-slate-400">{addon.description}</div>
                              )}

                              <div className="mt-1 text-[10px] font-medium uppercase tracking-[0.8px] text-slate-400">
                                {addon.stockQuantity !== null && addon.stockQuantity !== undefined
                                  ? `${addon.stockQuantity} LEFT`
                                  : 'UNLIMITED'}
                              </div>
                            </div>

                            <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-black/30 p-1">
                              <button
                                type="button"
                                onClick={() =>
                                  setSelectedAddonQuantities((prev) => ({
                                    ...prev,
                                    [addon.id]: Math.max(0, (prev[addon.id] || 0) - 1),
                                  }))
                                }
                                disabled={quantity === 0 || isOutOfStock}
                                className={`flex h-7 w-7 items-center justify-center rounded-lg text-[11px] font-bold ${
                                  quantity === 0 || isOutOfStock
                                    ? 'bg-white/5 text-slate-500 cursor-not-allowed'
                                    : 'bg-white/5 text-slate-300 hover:bg-white/10'
                                }`}
                              >
                                −
                              </button>

                              <div className="min-w-[22px] text-center text-[13px] font-bold text-white">{quantity}</div>

                              <button
                                type="button"
                                onClick={() =>
                                  setSelectedAddonQuantities((prev) => ({
                                    ...prev,
                                    [addon.id]: isOutOfStock ? 0 : Math.min((prev[addon.id] || 0) + 1, maxQuantity),
                                  }))
                                }
                                disabled={isOutOfStock || quantity >= maxQuantity}
                                className={`flex h-7 w-7 items-center justify-center rounded-lg text-[11px] font-bold ${
                                  isOutOfStock || quantity >= maxQuantity
                                    ? 'bg-white/5 text-slate-500 cursor-not-allowed'
                                    : 'bg-emerald-500 text-slate-950 hover:bg-emerald-400'
                                }`}
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <div className="text-[10px] font-bold uppercase tracking-[1.2px] text-slate-400">
                  Transparent Fee Breakdown (Section 10.2)
                </div>

                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3.5">
                  <div className="space-y-2 text-[12px] text-slate-300">
                    <div className="flex items-center justify-between">
                      <span>Turf Rental (Set by Owner)</span>
                      <span className="font-semibold text-white">৳{bookingBaseAmount.toLocaleString()}</span>
                    </div>

                    {addonSubtotal > 0 && (
                      <div className="flex items-center justify-between">
                        <span>Add-ons</span>
                        <span className="font-semibold text-white">৳{addonSubtotal.toLocaleString()}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        Platform Fee
                        <span className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-400">5%</span>
                      </span>
                      <span className="font-semibold text-white">
                        ৳{Math.round((bookingBaseAmount + addonSubtotal) * 0.05)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        Payment Gateway Fee
                        <span className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-400">2.5%</span>
                      </span>
                      <span className="font-semibold text-white">
                        ৳{Math.round(((bookingBaseAmount + addonSubtotal) + Math.round((bookingBaseAmount + addonSubtotal) * 0.05)) * 0.025)}
                      </span>
                    </div>

                    <div className="mt-2 border-t border-dashed border-white/10 pt-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[13px] font-bold uppercase tracking-[0.5px] text-emerald-400">
                          Total Payable Amount
                        </span>
                        <span className="text-[20px] font-extrabold tracking-[-0.5px] text-emerald-400">
                          ৳
                          {(
                            bookingBaseAmount +
                            addonSubtotal +
                            Math.round((bookingBaseAmount + addonSubtotal) * 0.05) +
                            Math.round(((bookingBaseAmount + addonSubtotal) + Math.round((bookingBaseAmount + addonSubtotal) * 0.05)) * 0.025)
                          ).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2 rounded-xl border border-emerald-500/15 bg-emerald-500/5 p-3 text-[11px] text-slate-300">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                <p>
                  Payment gateway fees are collected by SSLCommerz and are non-refundable upon cancellation. Turf refunds follow
                  the platform cancellation policy.
                </p>
              </div>
            </div>

            <div className="shrink-0 border-t border-white/10 bg-[#0a0f0d] px-5 pb-[14px] pt-3">
              <div className="grid grid-cols-[1fr_1.5fr] gap-2.5">
                <button
                  onClick={() => {
                    unlockSlots(selectedBookingSlots.map((slot) => slot.id));
                    setSelectedBookingSlots([]);
                    setShowCheckoutModal(false);
                  }}
                  className="h-[40px] rounded-[20px] border border-white/10 bg-white/[0.04] px-3 text-[11px] font-bold leading-none text-slate-300 transition hover:bg-white/[0.08] hover:text-white"
                >
                  Cancel Hold
                </button>

                <button
                  onClick={handleProceedToPayment}
                  className="flex h-[40px] items-center justify-center gap-1.5 rounded-[20px] bg-gradient-to-r from-emerald-500 to-[#00b368] px-3 text-[11px] font-extrabold leading-none text-slate-950 shadow-[0_4px_16px_rgba(0,217,126,0.3)] transition hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(0,217,126,0.45)]"
                >
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Pay via SSLCommerz</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: PAYMENT GATEWAY CHECKOUT (admin-configured, real SSLCommerz)      */}
      {/* ========================================================================= */}
      {showSSLGateway && selectedSlot && selectedTurf && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border-2 border-emerald-500/40 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-black text-lg tracking-tight text-white">
                  {selectedGateway ? selectedGateway.label : 'Checkout'}
                </span>
                {selectedGateway && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      selectedGateway.isSandbox ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {selectedGateway.isSandbox ? 'Sandbox' : 'Live'}
                  </span>
                )}
              </div>
              <button
                onClick={() => {
                  setShowSSLGateway(false);
                  setGatewaySessionUrl(null);
                  setGatewayError('');
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <div className="text-xs text-slate-400">Merchant: Turfyslot Platform</div>
              <div className="text-xl font-black text-emerald-400 mt-1">৳{totalPayable.toLocaleString()} BDT</div>
            </div>

            {activeGateways.length === 0 ? (
              <div className="p-3 rounded-xl border border-amber-500/40 bg-amber-950/30 text-xs text-amber-300">
                No payment gateway is currently enabled. Please contact the platform admin to activate one from the Admin
                Settings → Payment Gateways panel.
              </div>
            ) : (
              <>
                {/* Payment Gateway Selector (sourced from admin-configured gateways) */}
                <div>
                  <label className="text-xs font-bold text-slate-300 mb-2 block">Select Payment Gateway:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {activeGateways.map((gateway) => (
                      <button
                        key={gateway.id}
                        type="button"
                        onClick={() => {
                          setSelectedGatewayId(gateway.id);
                          setGatewaySessionUrl(null);
                          setGatewayError('');
                        }}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                          selectedGateway?.id === gateway.id
                            ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="font-black text-sm">{gateway.label}</div>
                        <div className="text-[9px] opacity-80">{gateway.isSandbox ? 'Sandbox' : 'Live'}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-900 p-3 rounded-xl text-[11px] text-slate-400 space-y-1 border border-slate-800">
                  <div>Payer: {currentUser.name}</div>
                  <div>Phone: {currentUser.phone}</div>
                  {selectedGateway?.provider === 'sslcommerz' ? (
                    <div className="text-emerald-400 font-medium">Real SSLCommerz {selectedGateway.isSandbox ? 'sandbox' : 'live'} checkout session</div>
                  ) : (
                    <div className="text-amber-400 font-medium">
                      {selectedGateway?.label} checkout is simulated in this build — only SSLCommerz is fully wired.
                    </div>
                  )}
                </div>

                {gatewayError && (
                  <div className="p-3 rounded-xl border border-rose-500/40 bg-rose-950/30 text-xs text-rose-300">{gatewayError}</div>
                )}

                {selectedGateway?.provider === 'sslcommerz' && gatewaySessionUrl ? (
                  <div className="space-y-3">
                    <div className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-950/20 text-xs text-emerald-300">
                      A real SSLCommerz checkout tab has opened. Complete the payment there, then confirm below.
                    </div>
                    <button
                      onClick={finalizeBooking}
                      className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>I've Completed Payment — Confirm Booking</span>
                    </button>
                    <button
                      onClick={() => window.open(gatewaySessionUrl, '_blank', 'noopener,noreferrer')}
                      className="w-full py-2 text-emerald-400 hover:text-emerald-300 text-xs font-semibold cursor-pointer"
                    >
                      Reopen checkout tab
                    </button>
                  </div>
                ) : (
                  <button
                    disabled={isProcessingPayment || !selectedGateway}
                    onClick={selectedGateway?.provider === 'sslcommerz' ? handleStartSslcommerzCheckout : handleSimulatePaymentSuccess}
                    className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isProcessingPayment ? (
                      <>
                        <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                        <span>Connecting to Gateway...</span>
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4" />
                        <span>
                          {selectedGateway?.provider === 'sslcommerz' ? 'Continue to SSLCommerz' : 'Pay & Confirm Reservation'}
                        </span>
                      </>
                    )}
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: BOOKING CONFIRMED SUCCESS & QR CODE                              */}
      {/* ========================================================================= */}
      {confirmedBooking && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-emerald-500/50 w-full max-w-md rounded-2xl p-6 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-lg font-black text-white">Booking Confirmed!</h3>
            <p className="text-xs text-slate-300">
              Your slot at <span className="text-emerald-400 font-bold">{confirmedBooking.turfName}</span> has been confirmed.
            </p>

            <div className="bg-slate-900 p-4 rounded-xl text-left text-xs space-y-1.5 border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">Booking Ref:</span>
                <span className="font-mono font-bold text-white">{confirmedBooking.bookingNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Date & Time:</span>
                <span className="font-semibold text-white">
                  {confirmedBooking.date} ({confirmedBooking.startTime} - {confirmedBooking.endTime})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Paid Amount:</span>
                <span className="font-bold text-emerald-400">৳{confirmedBooking.totalPaid.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SSL Reference:</span>
                <span className="font-mono text-slate-300">{confirmedBooking.paymentReference}</span>
              </div>
            </div>

            {/* Digital QR Pass simulation */}
            <div className="p-4 bg-white rounded-xl max-w-[180px] mx-auto flex flex-col items-center shadow-lg">
              <QrCode className="w-28 h-28 text-slate-950" />
              <span className="text-[10px] font-mono text-slate-800 font-bold mt-1">
                {confirmedBooking.bookingNumber}
              </span>
            </div>

            <button
              onClick={() => {
                setConfirmedBooking(null);
                setSelectedTurf(null);
                setActiveTab('my_bookings');
              }}
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl cursor-pointer"
            >
              View in My Bookings
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: CANCEL BOOKING WITH POLICY PREVIEW                                */}
      {/* ========================================================================= */}
      {bookingToCancel && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-400" /> Cancel Booking
            </h3>

            {(() => {
              const refundCalc = calculateRefund(bookingToCancel, false);
              return (
                <div className="space-y-3">
                  <div className="bg-slate-900 p-3.5 rounded-xl text-xs space-y-1.5 border border-slate-800">
                    <div className="flex justify-between text-slate-300">
                      <span>Booking:</span>
                      <span className="font-mono font-bold text-white">{bookingToCancel.bookingNumber}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Turf Base Price:</span>
                      <span>৳{bookingToCancel.baseAmount}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Matched Policy Tier:</span>
                      <span className="font-bold text-emerald-400">{refundCalc.refundPercentage}% Refund</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Non-refundable Gateway Fee:</span>
                      <span className="text-slate-400">৳{refundCalc.gatewayFeeDeducted}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-700 flex justify-between font-bold text-sm">
                      <span className="text-white">Estimated Player Refund:</span>
                      <span className="text-emerald-400">৳{refundCalc.playerRefund}</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 mb-1 block">Reason for Cancellation:</label>
                    <textarea
                      value={cancelReason}
                      onChange={(e) => setCancelReason(e.target.value)}
                      placeholder="e.g. Sudden personal conflict, injury, bad weather..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                      rows={3}
                    />
                  </div>

                  {cancelError && (
                    <div className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-2 text-[11px] text-rose-300">
                      {cancelError}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setBookingToCancel(null);
                        setCancelError('');
                      }}
                      className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs rounded-xl cursor-pointer"
                    >
                      Keep Booking
                    </button>
                    <button
                      onClick={() => {
                        const result = cancelBooking(bookingToCancel.id, cancelReason || 'Player cancelled online');
                        if (!result.success) {
                          setCancelError(result.message);
                          return;
                        }
                        setBookingToCancel(null);
                        setCancelReason('');
                        setCancelError('');
                      }}
                      className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer"
                    >
                      Confirm Cancellation
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: QR CODE DIGITAL PASS                                             */}
      {/* ========================================================================= */}
      {selectedBookingForQR && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-slate-800 w-full max-w-sm rounded-2xl p-6 shadow-2xl text-center space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Ground Check-In Pass</span>
              <button onClick={() => setSelectedBookingForQR(null)} className="text-slate-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-white p-5 rounded-2xl max-w-[200px] mx-auto shadow-inner">
              <QrCode className="w-36 h-36 text-slate-950 mx-auto" />
              <div className="text-[11px] font-mono text-slate-900 font-black mt-2">
                {selectedBookingForQR.bookingNumber}
              </div>
            </div>

            <div className="text-left bg-slate-900 p-3.5 rounded-xl text-xs space-y-1 border border-slate-800">
              <div className="font-bold text-white text-sm">{selectedBookingForQR.turfName}</div>
              <div className="text-slate-300">
                Date: {selectedBookingForQR.date} ({selectedBookingForQR.startTime} - {selectedBookingForQR.endTime})
              </div>
              <div className="text-slate-400">Player: {selectedBookingForQR.customerName}</div>
              <div className="text-slate-400">Phone: {selectedBookingForQR.customerPhone}</div>
            </div>

            <p className="text-[11px] text-slate-400">
              Present this code at the turf counter on arrival. Staff will scan it to check you in.
            </p>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: LEAVE REVIEW                                                     */}
      {/* ========================================================================= */}
      {bookingForReview && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-400 fill-amber-400" /> Rate & Review Turf
            </h3>
            <p className="text-xs text-slate-300">
              How was your match at <span className="font-semibold text-white">{bookingForReview.turfName}</span>?
            </p>

            <div className="flex items-center justify-center gap-2 py-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setReviewRating(star)}
                  className="p-1 text-slate-500 hover:text-amber-400 transition-colors cursor-pointer"
                >
                  <Star
                    className={`w-8 h-8 ${
                      reviewRating >= star ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                    }`}
                  />
                </button>
              ))}
            </div>

            <textarea
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              placeholder="Write your feedback about turf grass condition, floodlights, amenities..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              rows={3}
            />

            <div className="flex gap-2">
              <button
                onClick={() => setBookingForReview(null)}
                className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold text-xs rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  addReview(bookingForReview.id, reviewRating, reviewComment);
                  setBookingForReview(null);
                  setReviewComment('');
                }}
                className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg cursor-pointer"
              >
                Submit Review
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 8: DISPUTE                                                          */}
      {/* ========================================================================= */}
      {disputeBooking && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b121e] border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-indigo-400" /> Dispute or Assistance
            </h3>
            <p className="text-xs text-slate-300">
              Booking: <span className="font-mono text-emerald-400">{disputeBooking.bookingNumber}</span>
            </p>

            <div>
              <label className="text-xs text-slate-400 mb-1 block">Category:</label>
              <select
                value={disputeCategory}
                onChange={(e) => setDisputeCategory(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white cursor-pointer"
              >
                <option value="facility_unavailable">Facility / Turf Unavailable</option>
                <option value="refund_issue">Refund Calculation Dispute</option>
                <option value="payment_mismatch">Payment Discrepancy</option>
                <option value="other">Other Incident</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1 block">Details:</label>
              <textarea
                value={disputeDesc}
                onChange={(e) => setDisputeDesc(e.target.value)}
                placeholder="Explain the issue clearly for admin arbitration..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setDisputeBooking(null)}
                className="flex-1 py-2 bg-slate-900 text-slate-300 text-xs rounded-xl cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  raiseDispute(disputeBooking.id, disputeCategory, disputeDesc);
                  setDisputeBooking(null);
                  setDisputeDesc('');
                }}
                className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                Submit Dispute
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
