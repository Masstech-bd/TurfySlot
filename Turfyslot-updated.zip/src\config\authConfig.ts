// ─────────────────────────────────────────────────────────────────────────
// TurfySlot Auth Config
// Change ADMIN_LOGIN_EMAIL / ADMIN_LOGIN_PASSWORD here to control the fixed
// Admin login for this app. This is the ONLY place the admin credentials
// live — update these two values and rebuild to change the admin login.
// ─────────────────────────────────────────────────────────────────────────

export const ADMIN_LOGIN_EMAIL = 'admin@turfyslot.com';
export const ADMIN_LOGIN_PASSWORD = 'TurfyAdmin@2026!';

// Fallback password for demo/mock player, turf_owner and staff accounts that
// were not registered with a custom password (e.g. seeded mock data users).
export const DEMO_USER_PASSWORD = 'turfyslot123';
