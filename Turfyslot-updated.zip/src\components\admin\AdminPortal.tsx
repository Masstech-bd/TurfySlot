import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CancellationPolicy, CancellationTier, BookingSource, PaymentGatewayConfig, PaymentGatewayProvider, SmtpConfig } from '../../types';
import { getBDDateString, formatBDDate } from '../../utils/datetime';
import {
  ShieldCheck,
  Building2,
  Users,
  Calendar,
  Wallet,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Sliders,
  Scale,
  Sparkles,
  Phone,
  HelpCircle,
  Check,
  X,
  Clock,
  ArrowRight,
  Search,
  UserCheck,
  UserX,
  Filter,
  Trophy,
} from 'lucide-react';
import { TournamentsView } from '../tournaments/TournamentsView';

export const AdminPortal: React.FC = () => {
  const {
    users,
    ownerProfiles,
    turfs,
    bookings,
    withdrawals,
    cancellationPolicies,
    disputes,
    settings,
    approveTurf,
    rejectTurf,
    approveOwner,
    rejectOwner,
    toggleUserSuspension,
    approveWithdrawal,
    rejectWithdrawal,
    updatePlatformSettings,
    cancelBooking,
    resolveDispute,
    addCancellationPolicy,
    updateCancellationPolicy,
    switchUser,
    adminActiveTab,
    setAdminActiveTab,
  } = useApp();

  const activeTab = adminActiveTab;
  const setActiveTab = setAdminActiveTab;

  // User Management State (Section 9.1)
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'player' | 'turf_owner' | 'staff' | 'admin'>('all');
  const [userStatusFilter, setUserStatusFilter] = useState<'all' | 'active' | 'pending_approval' | 'suspended'>('all');

  const filteredUsers = users.filter((u) => {
    const query = userSearchQuery.toLowerCase();
    const matchesSearch =
      u.name.toLowerCase().includes(query) ||
      u.email.toLowerCase().includes(query) ||
      (u.phone && u.phone.toLowerCase().includes(query));
    const matchesRole = userRoleFilter === 'all' || u.role === userRoleFilter;
    const matchesStatus = userStatusFilter === 'all' || u.status === userStatusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  // Approvals State
  const pendingTurfs = turfs.filter((t) => t.status === 'pending_review');
  const pendingOwners = ownerProfiles.filter((p) => p.approvalStatus === 'pending_approval');
  const pendingWithdrawals = withdrawals.filter((w) => w.status === 'pending');

  // Withdrawal Approval Modal
  const [selectedWdForApproval, setSelectedWdForApproval] = useState<string | null>(null);
  const [payoutRef, setPayoutRef] = useState('');
  const [selectedWdForReject, setSelectedWdForReject] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  // Settings state
  const [globalComm, setGlobalComm] = useState(settings.globalCommissionRate);
  const [platformFee, setPlatformFee] = useState(settings.platformFeeRate);
  const [minWd, setMinWd] = useState(settings.minWithdrawalAmount);
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [settingsSubTab, setSettingsSubTab] = useState<'commission' | 'features' | 'packages' | 'gateways' | 'email'>('commission');
  const featureFlags = settings.featureFlags ?? {
    addons_enabled: false,
    squad_enabled: false,
    tournament_enabled: false,
    featured_turf_enabled: false,
    featured_addon_enabled: false,
    whatsapp_enabled: false,
    trending_enabled: false,
    near_you_enabled: false,
  };

  const featureFlagDefinitions = [
    { key: 'addons_enabled', label: 'Booking Add-ons', description: 'Section 51 — optional add-on selection' },
    { key: 'squad_enabled', label: 'Squad / Matchmaking', description: 'Section 49 — open matches & squads' },
    { key: 'tournament_enabled', label: 'Tournament Module', description: 'Section 50 — tournament features' },
    { key: 'featured_turf_enabled', label: 'Featured Turf Listing', description: 'Section 52.5 — paid promotional placement' },
    { key: 'featured_addon_enabled', label: 'Featured Add-on Listing', description: 'Reserved for Phase 3' },
    { key: 'whatsapp_enabled', label: 'WhatsApp Integration', description: 'Reserved for future' },
    { key: 'trending_enabled', label: 'Trending Now', description: 'Section 53.4 — home discovery module' },
    { key: 'near_you_enabled', label: 'Near You', description: 'Section 53.5 — location discovery' },
  ] as const;

  const toggleFeatureFlag = (key: keyof typeof featureFlags) => {
    updatePlatformSettings({
      featureFlags: {
        ...featureFlags,
        [key]: !featureFlags[key],
      },
    });
  };

  // Payment Gateway Management (admin-configurable, sandbox-friendly)
  const paymentGateways = settings.paymentGateways || [];
  const gatewayProviderLabels: Record<PaymentGatewayProvider, string> = {
    sslcommerz: 'SSLCommerz',
    surjopay: 'SurjoPay',
    bkash: 'bKash Merchant',
    nagad: 'Nagad Merchant',
    custom: 'Custom Gateway',
  };

  const updateGateway = (id: string, updates: Partial<PaymentGatewayConfig>) => {
    updatePlatformSettings({
      paymentGateways: paymentGateways.map((g) => (g.id === id ? { ...g, ...updates } : g)),
    });
  };

  const addGateway = (provider: PaymentGatewayProvider) => {
    const newGateway: PaymentGatewayConfig = {
      id: `gateway-${Date.now()}`,
      provider,
      label: gatewayProviderLabels[provider],
      isSandbox: true,
      isActive: false,
      storeId: '',
      apiKey: '',
      apiSecret: '',
      merchantNumber: '',
    };
    updatePlatformSettings({ paymentGateways: [...paymentGateways, newGateway] });
  };

  const removeGateway = (id: string) => {
    updatePlatformSettings({ paymentGateways: paymentGateways.filter((g) => g.id !== id) });
  };

  // SMTP / Email Configuration — supports multiple servers, admin can add/edit/delete/activate any of them
  const smtpConfigs = settings.smtpConfigs || [];
  const [smtpTestEmailByConfig, setSmtpTestEmailByConfig] = useState<Record<string, string>>({});
  const [smtpTestStatusByConfig, setSmtpTestStatusByConfig] = useState<Record<string, string>>({});
  const [sendingTestConfigId, setSendingTestConfigId] = useState<string | null>(null);

  const updateSmtpConfig = (id: string, updates: Partial<SmtpConfig>) => {
    updatePlatformSettings({ smtpConfigs: smtpConfigs.map((c) => (c.id === id ? { ...c, ...updates } : c)) });
  };

  const addSmtpConfig = () => {
    const newConfig: SmtpConfig = {
      id: `smtp-${Date.now()}`,
      label: 'New SMTP Server',
      host: '',
      port: 587,
      secure: false,
      username: '',
      password: '',
      fromName: 'TurfySlot',
      fromEmail: '',
      isActive: smtpConfigs.length === 0,
    };
    updatePlatformSettings({ smtpConfigs: [...smtpConfigs, newConfig] });
  };

  const removeSmtpConfig = (id: string) => {
    updatePlatformSettings({ smtpConfigs: smtpConfigs.filter((c) => c.id !== id) });
  };

  const setActiveSmtpConfig = (id: string) => {
    updatePlatformSettings({ smtpConfigs: smtpConfigs.map((c) => ({ ...c, isActive: c.id === id })) });
  };

  const handleSendSmtpTest = async (config: SmtpConfig) => {
    const toEmail = (smtpTestEmailByConfig[config.id] || '').trim();
    if (!toEmail) {
      setSmtpTestStatusByConfig((prev) => ({ ...prev, [config.id]: 'Enter a recipient email to send the test to.' }));
      return;
    }
    setSendingTestConfigId(config.id);
    setSmtpTestStatusByConfig((prev) => ({ ...prev, [config.id]: '' }));
    try {
      const response = await fetch('http://localhost:5000/api/email/send-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...config, toEmail }),
      });
      const data = await response.json();
      setSmtpTestStatusByConfig((prev) => ({
        ...prev,
        [config.id]: data.message || (data.success ? 'Test email sent.' : 'Failed to send test email.'),
      }));
    } catch (error) {
      setSmtpTestStatusByConfig((prev) => ({
        ...prev,
        [config.id]: 'Could not reach the backend (server.js). Is it running on port 5000?',
      }));
    } finally {
      setSendingTestConfigId(null);
    }
  };

  // Policy Simulator State (Section 47)
  const [simTurfId, setSimTurfId] = useState(turfs[0]?.id || 'turf-1');
  const [simPrice, setSimPrice] = useState(1000);
  const [simHoursBefore, setSimHoursBefore] = useState(18); // e.g. 18 hours
  const [simBookingSource, setSimBookingSource] = useState<BookingSource>('online');

  // Calculate Policy Simulation (Section 10.3 & 47)
  const calculateSimulation = () => {
    const turf = turfs.find((t) => t.id === simTurfId);
    const policy = cancellationPolicies.find((p) => p.id === turf?.cancellationPolicyId) || cancellationPolicies[0];

    // Find tier
    let tier = policy.tiers.find(
      (t) => simHoursBefore >= t.minHoursBefore && simHoursBefore < (t.maxHoursBefore ?? 99999)
    );
    if (!tier && simHoursBefore >= 24) tier = policy.tiers.find((t) => t.refundPercentage === 100);
    if (!tier) tier = policy.tiers[policy.tiers.length - 1];

    const refundPercent = tier?.refundPercentage ?? 0;
    const baseAmount = simPrice;
    const platformFeeAmt = Math.round(baseAmount * (settings.platformFeeRate / 100));
    const gatewayFeeAmt = simBookingSource === 'online' ? Math.round((baseAmount + platformFeeAmt) * (settings.gatewayFeeRate / 100)) : 0;
    const totalPaid = baseAmount + platformFeeAmt + gatewayFeeAmt;

    let playerRefund = 0;
    let adminKeep = platformFeeAmt;

    if (simBookingSource === 'online') {
      playerRefund = Math.round((baseAmount * refundPercent) / 100);
    } else {
      playerRefund = Math.max(0, Math.round((baseAmount * refundPercent) / 100) - platformFeeAmt);
    }

    return {
      policyName: policy.name,
      matchedTier: tier?.description || `${refundPercent}% Refund Tier`,
      refundPercent,
      baseAmount,
      platformFeeAmt,
      gatewayFeeAmt,
      totalPaid,
      playerRefund,
      adminKeep,
      gatewayFeeKeptBySSL: gatewayFeeAmt,
    };
  };

  const simResult = calculateSimulation();

  // Metrics Calculation
  const totalGrossBookingValue = bookings.reduce((acc, b) => acc + b.totalPaid, 0);
  const totalCommissionEarned = bookings.reduce((acc, b) => acc + b.commissionAmount, 0);
  const totalPlatformFees = bookings.reduce((acc, b) => acc + b.platformFeeAmount, 0);
  const totalBookings = bookings.length;
  const completedBookings = bookings.filter((b) => ['confirmed', 'checked_in', 'completed'].includes(b.status)).length;
  const cancelledBookings = bookings.filter((b) => ['cancelled', 'refunded'].includes(b.status)).length;
  const cancellationRate = totalBookings > 0 ? (cancelledBookings / totalBookings) * 100 : 0;
  const avgBookingValue = totalBookings > 0 ? totalGrossBookingValue / totalBookings : 0;
  const netOwnerEarnings = bookings.reduce((acc, b) => acc + b.netOwnerAmount, 0);

  const sourceBreakdown = Object.entries(
    bookings.reduce((acc, b) => {
      acc[b.bookingSource] = (acc[b.bookingSource] || 0) + b.totalPaid;
      return acc;
    }, {} as Record<string, number>)
  )
    .map(([source, total]) => ({ source, total }))
    .sort((a, b) => b.total - a.total);

  const turfRevenueMap = bookings.reduce((acc, b) => {
    acc[b.turfName] = (acc[b.turfName] || 0) + b.netOwnerAmount;
    return acc;
  }, {} as Record<string, number>);

  const topTurfs = Object.entries(turfRevenueMap)
    .map(([name, total]) => ({
      name,
      total,
      bookings: bookings.filter((b) => b.turfName === name).length,
    }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  const maxTopTurfValue = topTurfs.length > 0 ? Math.max(...topTurfs.map((t) => t.total)) : 1;

  const recentDays = Array.from({ length: 7 }, (_, index) => {
    const key = getBDDateString(-(6 - index));
    const date = new Date(`${key}T00:00:00`);

    return {
      key,
      label: date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }),
      value: bookings
        .filter((b) => b.date === key)
        .reduce((sum, b) => sum + b.totalPaid, 0),
    };
  });

  const maxDailyRevenue = Math.max(...recentDays.map((day) => day.value), 1);
  const recentBookings = bookings.slice(0, 6);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updatePlatformSettings({
      globalCommissionRate: Number(globalComm),
      platformFeeRate: Number(platformFee),
      minWithdrawalAmount: Number(minWd),
    });
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#07130c] text-slate-100 pb-16">
      {/* Header */}
      <div className="bg-[#0A1E14] border-b border-white/10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-[10px] font-bold tracking-wider uppercase rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] border border-[#C8FF5E]/30">
                  Platform Operations Console
                </span>
                <span className="text-xs text-white/60">Master Governance</span>
              </div>
              <h1 className="text-2xl font-black text-white mt-1">System Administration & Oversight</h1>
            </div>
          </div>

          {/* Navigation Tabs - Seamless full width with flex-wrap and zero scrollbars */}
          <div className="mt-5 flex items-center gap-1.5 bg-white/[0.04] p-1.5 rounded-2xl border border-white/10 flex-wrap no-scrollbar">
            <button
              onClick={() => setActiveTab('approvals')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'approvals' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Approvals</span>
              {pendingTurfs.length + pendingOwners.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-[#0A1E14] text-[#C8FF5E] text-[10px] font-bold flex items-center justify-center">
                  {pendingTurfs.length + pendingOwners.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'users' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Users ({users.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('withdrawals')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'withdrawals' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Withdrawals</span>
              {pendingWithdrawals.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-[#0A1E14] text-emerald-400 text-[10px] font-bold flex items-center justify-center">
                  {pendingWithdrawals.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('policy_engine')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'policy_engine' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              <span>Policy Engine (Sec 47)</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'settings' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Settings & Commission</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'reports' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Reports & Analytics</span>
            </button>

            <button
              onClick={() => setActiveTab('bookings')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'bookings' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>All Bookings ({bookings.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('disputes')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'disputes' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Disputes</span>
              {disputes.filter((d) => d.status === 'pending').length > 0 && (
                <span className="w-4 h-4 rounded-full bg-[#0A1E14] text-amber-300 text-[10px] font-bold flex items-center justify-center">
                  {disputes.filter((d) => d.status === 'pending').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('tournaments')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'tournaments' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Tournaments (Sec 50)</span>
            </button>
          </div>

          {/* Platform Revenue KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Gross Booking Value</div>
              <div className="text-xl font-black text-white mt-1">৳{totalGrossBookingValue.toLocaleString()}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Commission Earned</div>
              <div className="text-xl font-black text-[#C8FF5E] mt-1">৳{totalCommissionEarned.toLocaleString()}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Platform Service Fees</div>
              <div className="text-xl font-black text-emerald-400 mt-1">৳{totalPlatformFees.toLocaleString()}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Active Turfs</div>
              <div className="text-xl font-black text-white mt-1">{turfs.filter((t) => t.status === 'active').length}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Registered Users</div>
              <div className="text-xl font-black text-white mt-1">{users.length}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Pending Approvals</div>
              <div className="text-xl font-black text-amber-400 mt-1">
                {pendingTurfs.length + pendingOwners.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* TAB 1: APPROVALS QUEUE */}
        {activeTab === 'approvals' && (
          <div className="space-y-8">
            {/* Section A: Turf Owner Account Approvals */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#C8FF5E]" /> Turf Owner Account Review Queue ({pendingOwners.length})
                </h3>
              </div>
              <p className="text-xs text-white/60">
                Owners cannot list turfs or receive player funds until approved by platform admin (Section 5.1).
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingOwners.map((p) => {
                  const ownerUser = users.find((u) => u.id === p.userId);
                  return (
                    <div key={p.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-white text-base">{p.businessName}</h4>
                          <p className="text-xs text-white/60">
                            Owner: {ownerUser?.name} ({ownerUser?.email})
                          </p>
                        </div>
                        <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase bg-amber-950/60 text-amber-300 border border-amber-500/40">
                          {p.approvalStatus.replace('_', ' ')}
                        </span>
                      </div>

                      <div className="bg-[#07130c] border border-white/10 p-3 rounded-xl text-xs space-y-1">
                        <div>
                          <span className="text-white/60">Trade License / NID:</span>{' '}
                          <span className="font-mono text-[#C8FF5E]">{p.nidOrTradeLicense}</span>
                        </div>
                        <div>
                          <span className="text-white/60">Payout Method:</span>{' '}
                          <span className="capitalize text-white">{p.payoutMethod.replace('_', ' ')}</span> (
                          {p.payoutDetails.accountNumber})
                        </div>
                        {p.payoutDetails.bankName && (
                          <div>
                            <span className="text-white/60">Bank:</span>{' '}
                            <span className="text-white">
                              {p.payoutDetails.bankName} - {p.payoutDetails.branchName}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={() => rejectOwner(p.userId)}
                          className="flex-1 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-semibold rounded-xl cursor-pointer transition-colors"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => approveOwner(p.userId)}
                          className="flex-1 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                        >
                          <Check className="w-3.5 h-3.5" /> Approve & Activate
                        </button>
                      </div>
                    </div>
                  );
                })}

                {pendingOwners.length === 0 && (
                  <div className="col-span-full py-8 text-center bg-[#0A1E14] border border-white/10 rounded-2xl text-white/50 text-xs">
                    No pending turf owner accounts. All accounts are up to date.
                  </div>
                )}
              </div>
            </div>

            {/* Section B: Turf Listing Approvals */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-[#C8FF5E]" /> Turf Ground Listing Approvals ({pendingTurfs.length})
                </h3>
              </div>
              <p className="text-xs text-white/60">
                Verify turf facilities, lighting, pricing, and photos before listing publicly (Section 7.2).
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {pendingTurfs.map((turf) => (
                  <div key={turf.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
                    <div className="relative h-44 bg-[#07130c]">
                      <img src={turf.photos[0]} alt={turf.name} className="w-full h-full object-cover" />
                      <span className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40 uppercase tracking-wider">
                        Pending Review
                      </span>
                    </div>

                    <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <h4 className="font-bold text-white text-base">{turf.name}</h4>
                        <p className="text-xs text-white/60 mt-0.5">By {turf.ownerName}</p>
                        <p className="text-xs text-white/70 mt-2 line-clamp-2">{turf.description}</p>
                        <div className="text-xs font-semibold text-[#C8FF5E] mt-2">
                          ৳{turf.basePricePerHour}/hr • {turf.area}, {turf.city}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2 border-t border-white/10">
                        <button
                          onClick={() => rejectTurf(turf.id)}
                          className="flex-1 py-2 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-semibold rounded-xl cursor-pointer transition-colors"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => approveTurf(turf.id)}
                          className="flex-1 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                        >
                          Approve Turf
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {pendingTurfs.length === 0 && (
                  <div className="col-span-full py-8 text-center bg-[#0A1E14] border border-white/10 rounded-2xl text-white/50 text-xs">
                    No turfs in the pending approval queue.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 1.5: USER DIRECTORY & ROLE MANAGEMENT (SECTION 9.1) */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div>
                <h2 className="text-xl font-black text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-[#C8FF5E]" /> Platform User Accounts & Access Control (Section 9.1)
                </h2>
                <p className="text-xs text-white/60 mt-1">
                  Manage all players, turf owners, operational staff, and system admins. View status, suspend, or reactivate accounts.
                </p>
              </div>

              {/* Summary Badges */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0A1E14] text-[#C8FF5E] border border-[#C8FF5E]/30">
                  Total: {users.length}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0A1E14] text-emerald-400 border border-emerald-500/30">
                  Active: {users.filter((u) => u.status === 'active').length}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#0A1E14] text-amber-300 border border-amber-500/30">
                  Pending: {users.filter((u) => u.status === 'pending_approval').length}
                </span>
                {users.filter((u) => u.status === 'suspended').length > 0 && (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-950/40 text-rose-300 border border-rose-500/30">
                    Suspended: {users.filter((u) => u.status === 'suspended').length}
                  </span>
                )}
              </div>
            </div>

            {/* Filter Toolbar */}
            <div className="bg-[#0A1E14] border border-white/10 p-4 rounded-2xl flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  placeholder="Search user by name, email, or phone..."
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#C8FF5E]"
                />
              </div>

              {/* Role Filter Pills */}
              <div className="flex items-center gap-1.5 flex-wrap no-scrollbar pb-1 md:pb-0">
                {(['all', 'player', 'turf_owner', 'staff', 'admin'] as const).map((r) => (
                  <button
                    key={r}
                    onClick={() => setUserRoleFilter(r)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                      userRoleFilter === r
                        ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20'
                        : 'bg-[#07130c] text-white/70 hover:text-white border border-white/10'
                    }`}
                  >
                    {r === 'all' ? 'All Roles' : r.replace('_', ' ').toUpperCase()}
                  </button>
                ))}
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5">
                {(['all', 'active', 'pending_approval', 'suspended'] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setUserStatusFilter(s)}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                      userStatusFilter === s
                        ? 'bg-white/20 text-white border border-white/30'
                        : 'bg-[#07130c] text-white/50 hover:text-white/80 border border-white/10'
                    }`}
                  >
                    {s === 'all' ? 'All Status' : s.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Users List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredUsers.map((u) => {
                const ownerP = ownerProfiles.find((op) => op.userId === u.id);
                const userBookings = bookings.filter((b) => b.playerId === u.id);
                const ownerTurfs = turfs.filter((t) => t.ownerId === u.id);

                return (
                  <div
                    key={u.id}
                    className="bg-[#0A1E14] border border-white/10 hover:border-[#C8FF5E]/30 transition-all rounded-2xl p-5 flex flex-col justify-between space-y-4 shadow-xl"
                  >
                    <div className="space-y-3">
                      {/* Top row: Avatar + Name + Status */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                            alt={u.name}
                            className="w-10 h-10 rounded-full object-cover ring-2 ring-white/10"
                          />
                          <div>
                            <h4 className="font-bold text-white text-sm leading-tight">{u.name}</h4>
                            <p className="text-xs text-white/50 truncate max-w-[180px]">{u.email}</p>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            u.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : u.status === 'suspended'
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {u.status.replace('_', ' ')}
                        </span>
                      </div>

                      {/* Role & Context Info */}
                      <div className="bg-[#07130c] p-3 rounded-xl text-xs space-y-1.5 border border-white/5">
                        <div className="flex items-center justify-between">
                          <span className="text-white/50">Platform Role:</span>
                          <span className="font-bold text-[#C8FF5E] uppercase tracking-wider text-[10px]">
                            {u.role.replace('_', ' ')}
                          </span>
                        </div>
                        {u.phone && (
                          <div className="flex items-center justify-between">
                            <span className="text-white/50">Phone:</span>
                            <span className="font-mono text-white/80">{u.phone}</span>
                          </div>
                        )}
                        {u.role === 'turf_owner' && (
                          <div className="flex items-center justify-between">
                            <span className="text-white/50">Business:</span>
                            <span className="font-semibold text-white truncate max-w-[150px]">
                              {ownerP?.businessName || 'Unregistered'} ({ownerTurfs.length} Turfs)
                            </span>
                          </div>
                        )}
                        {u.role === 'player' && (
                          <div className="flex items-center justify-between">
                            <span className="text-white/50">Bookings Made:</span>
                            <span className="font-bold text-white">{userBookings.length} bookings</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="pt-2 border-t border-white/10 flex items-center gap-2">
                      <button
                        onClick={() => toggleUserSuspension(u.id)}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          u.status === 'suspended'
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-slate-950 shadow'
                            : 'bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40'
                        }`}
                      >
                        {u.status === 'suspended' ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>Reactivate</span>
                          </>
                        ) : (
                          <>
                            <UserX className="w-3.5 h-3.5" />
                            <span>Suspend</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={() => switchUser(u.id)}
                        className="py-2 px-3 rounded-xl text-xs font-bold bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer flex items-center justify-center gap-1"
                        title="Log in as this user to preview their workspace"
                      >
                        <span>View As</span>
                      </button>
                    </div>
                  </div>
                );
              })}

              {filteredUsers.length === 0 && (
                <div className="col-span-full py-12 text-center bg-[#0A1E14] border border-white/10 rounded-2xl p-6 text-white/50 text-xs">
                  No users match the search and filter criteria.
                </div>
              )}
            </div>
          </div>
        )}
        {activeTab === 'withdrawals' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Turf Owner Payout Approvals (Section 9.5)</h2>
                <p className="text-xs text-white/60">
                  Review and manually disburse funds to turf owners via bKash, Nagad, or Bank Transfer.
                </p>
              </div>
            </div>

            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-left text-xs text-white/80">
                  <thead className="bg-[#0e271a] text-white/60 uppercase font-bold text-[10px] border-b border-white/10">
                    <tr>
                      <th className="py-3.5 px-4">Request ID</th>
                      <th className="py-3.5 px-4">Owner & Business</th>
                      <th className="py-3.5 px-4">Amount</th>
                      <th className="py-3.5 px-4">Payout Method & Account</th>
                      <th className="py-3.5 px-4">Date</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {withdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-white/[0.03] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{w.id}</td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-white">{w.ownerName}</div>
                          <div className="text-[11px] text-white/60">{w.businessName}</div>
                        </td>
                        <td className="py-3 px-4 font-black text-[#C8FF5E] text-sm">৳{w.amount.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <div className="text-white font-medium">{w.payoutMethod}</div>
                          <div className="text-[11px] text-white/60 font-mono">{w.payoutDetails}</div>
                        </td>
                        <td className="py-3 px-4 text-white/60">{formatBDDate(w.createdAt)}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                              w.status === 'paid'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : w.status === 'pending'
                                ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {w.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          {w.status === 'pending' ? (
                            <>
                              <button
                                onClick={() => setSelectedWdForReject(w.id)}
                                className="px-2.5 py-1 bg-rose-950/40 text-rose-300 hover:bg-rose-900/60 text-xs font-semibold rounded-xl border border-rose-800/40 cursor-pointer transition-colors"
                              >
                                Reject
                              </button>
                              <button
                                onClick={() => setSelectedWdForApproval(w.id)}
                                className="px-3 py-1 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-xs font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                              >
                                Approve & Pay
                              </button>
                            </>
                          ) : (
                            <span className="font-mono text-[11px] text-white/50">{w.reference || w.rejectionReason}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: FLEXIBLE CANCELLATION POLICY ENGINE (SECTION 47) */}
        {activeTab === 'policy_engine' && (
          <div className="space-y-6">
            <div className="pb-3 border-b border-white/10">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Scale className="w-5 h-5 text-[#C8FF5E]" /> Flexible Cancellation Policy Engine & Simulator (Section 47)
              </h2>
              <p className="text-xs text-white/60">
                Resolution Hierarchy: <span className="text-[#C8FF5E] font-semibold">Turf Policy</span> →{' '}
                <span className="text-emerald-400 font-semibold">Owner Policy</span> →{' '}
                <span className="text-amber-400 font-semibold">Standard Platform Default</span>
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left: Active Policies & Tiers Matrix */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Active Policy Tier Definitions</h3>

                {cancellationPolicies.map((cp) => (
                  <div key={cp.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{cp.name}</span>
                        {cp.isDefault && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40">
                            Global Default
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="text-xs text-white/60">{cp.description}</p>

                    {/* Tiers list */}
                    <div className="space-y-2 mt-3">
                      {cp.tiers.map((tier) => (
                        <div
                          key={tier.id}
                          className="flex items-center justify-between p-2.5 bg-[#07130c] rounded-xl text-xs border border-white/10"
                        >
                          <div>
                            <span className="font-semibold text-white">
                              {tier.minHoursBefore === 0
                                ? `< ${tier.maxHoursBefore} Hours Before`
                                : tier.maxHoursBefore === 9999 || !tier.maxHoursBefore
                                ? `> ${tier.minHoursBefore} Hours Before`
                                : `${tier.minHoursBefore} - ${tier.maxHoursBefore} Hours Before`}
                            </span>
                            <div className="text-[10px] text-white/50">{tier.description}</div>
                          </div>
                          <span
                            className={`font-black text-xs px-2.5 py-1 rounded-full border ${
                              tier.refundPercentage === 100
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : tier.refundPercentage === 50
                                ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {tier.refundPercentage}% Refund
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Right: Interactive Policy Simulator */}
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#C8FF5E]" /> Interactive Policy Simulator
                </h3>
                <p className="text-xs text-white/60">
                  Simulate any cancellation scenario and verify refund math against Section 10.3 and 47.13.
                </p>

                {/* Simulator Controls */}
                <div className="space-y-3 text-xs bg-[#07130c] p-4 rounded-xl border border-white/10">
                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Test Turf:</label>
                    <select
                      value={simTurfId}
                      onChange={(e) => setSimTurfId(e.target.value)}
                      className="w-full bg-[#0A1E14] border border-white/15 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                    >
                      {turfs.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} (Base ৳{t.basePricePerHour})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-white/80 font-semibold mb-1 block">Base Turf Price (BDT):</label>
                      <input
                        type="number"
                        value={simPrice}
                        onChange={(e) => setSimPrice(Number(e.target.value))}
                        className="w-full bg-[#0A1E14] border border-white/15 rounded-xl p-2.5 text-[#C8FF5E] font-bold focus:border-[#C8FF5E] outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-white/80 font-semibold mb-1 block">Hours Remaining Before Start:</label>
                      <input
                        type="number"
                        value={simHoursBefore}
                        onChange={(e) => setSimHoursBefore(Number(e.target.value))}
                        className="w-full bg-[#0A1E14] border border-white/15 rounded-xl p-2.5 text-white font-bold focus:border-[#C8FF5E] outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Booking Channel / Source:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setSimBookingSource('online')}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          simBookingSource === 'online'
                            ? 'bg-[#C8FF5E] text-[#0A1E14] font-bold border-[#C8FF5E] shadow-md shadow-[#C8FF5E]/20'
                            : 'bg-[#0A1E14] text-white/60 border-white/10 hover:text-white'
                        }`}
                      >
                        Online (SSLCommerz)
                      </button>
                      <button
                        type="button"
                        onClick={() => setSimBookingSource('manual_owner')}
                        className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                          simBookingSource === 'manual_owner'
                            ? 'bg-[#C8FF5E] text-[#0A1E14] font-bold border-[#C8FF5E] shadow-md shadow-[#C8FF5E]/20'
                            : 'bg-[#0A1E14] text-white/60 border-white/10 hover:text-white'
                        }`}
                      >
                        Manual / Counter (0 TK Gateway)
                      </button>
                    </div>
                  </div>
                </div>

                {/* Simulation Output Breakdown */}
                <div className="p-4 bg-[#07130c] rounded-xl border border-white/10 text-xs space-y-2">
                  <div className="flex justify-between items-center pb-2 border-b border-white/10">
                    <span className="text-white/60">Resolved Policy:</span>
                    <span className="font-bold text-white">{simResult.policyName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Triggered Tier:</span>
                    <span className="font-bold text-amber-300">{simResult.matchedTier}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Initial Amount Collected:</span>
                    <span className="font-semibold text-white">৳{simResult.totalPaid}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Platform Fee Kept by Admin:</span>
                    <span className="font-semibold text-[#C8FF5E]">৳{simResult.adminKeep}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white/60">Gateway Fee (Kept by SSLCommerz):</span>
                    <span className="font-semibold text-white/50">৳{simResult.gatewayFeeKeptBySSL}</span>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex justify-between items-center">
                    <span className="text-sm font-bold text-white">Calculated Player Refund:</span>
                    <span className="text-2xl font-black text-[#C8FF5E]">৳{simResult.playerRefund}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SETTINGS & COMMISSIONS */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="flex items-center gap-1.5 bg-white/[0.04] p-1.5 rounded-2xl border border-white/10 flex-wrap no-scrollbar">
              {[
                { key: 'commission', label: 'Commission Setup' },
                { key: 'features', label: 'Features Setting' },
                { key: 'packages', label: 'Packages' },
                { key: 'gateways', label: 'Payment Gateways' },
                { key: 'email', label: 'Email / SMTP' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setSettingsSubTab(tab.key as 'commission' | 'features' | 'packages' | 'gateways' | 'email')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    settingsSubTab === tab.key
                      ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20'
                      : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {settingsSubTab === 'commission' && (
              <form onSubmit={handleSaveSettings} className="bg-[#0A1E14] border border-white/10 rounded-2xl p-6 space-y-4 text-xs shadow-lg max-w-2xl">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">
                    Global Platform Commission Rate (% deducted from Turf Owner):
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="0.5"
                      value={globalComm}
                      onChange={(e) => setGlobalComm(Number(e.target.value))}
                      className="w-32 bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-[#C8FF5E] font-bold text-sm focus:border-[#C8FF5E] outline-none"
                    />
                    <span className="text-white/50">Current default: 5%</span>
                  </div>
                </div>

                <div>
                  <label className="text-white/80 font-semibold mb-1 block">
                    Player Platform Service Fee (% added on top of turf price):
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="0.5"
                      value={platformFee}
                      onChange={(e) => setPlatformFee(Number(e.target.value))}
                      className="w-32 bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-[#C8FF5E] font-bold text-sm focus:border-[#C8FF5E] outline-none"
                    />
                    <span className="text-white/50">Current default: 5%</span>
                  </div>
                </div>

                <div>
                  <label className="text-white/80 font-semibold mb-1 block">
                    Minimum Turf Owner Withdrawal Amount (BDT):
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      value={minWd}
                      onChange={(e) => setMinWd(Number(e.target.value))}
                      className="w-32 bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-white font-bold text-sm focus:border-[#C8FF5E] outline-none"
                    />
                    <span className="text-white/50">Current minimum: ৳1,000</span>
                  </div>
                </div>

                {settingsSaved && (
                  <div className="p-3 bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40 rounded-xl text-xs font-semibold">
                    Platform parameters updated successfully!
                  </div>
                )}

                <button
                  type="submit"
                  className="py-2.5 px-6 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer"
                >
                  Save Platform Settings
                </button>
              </form>
            )}

            {settingsSubTab === 'features' && (
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-6 shadow-lg space-y-4 max-w-3xl">
                <div className="pb-3 border-b border-white/10">
                  <h3 className="text-base font-bold text-white">Feature Flags & Paid Features Listing (Section 52)</h3>
                  <p className="text-[11px] text-white/60 mt-1">
                    All optional features default to OFF. Toggle a module to enable or disable it platform-wide.
                  </p>
                </div>

                <div className="space-y-3">
                  {featureFlagDefinitions.map(({ key, label, description }) => (
                    <div key={key} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-[#07130c] p-3">
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white">{label}</div>
                        <div className="text-[11px] text-white/60 mt-0.5">{description}</div>
                      </div>

                      <button
                        type="button"
                        onClick={() => toggleFeatureFlag(key)}
                        className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider border transition-colors cursor-pointer ${
                          featureFlags[key]
                            ? 'bg-[#C8FF5E]/15 text-[#C8FF5E] border-[#C8FF5E]/40'
                            : 'bg-white/[0.04] text-white/70 border-white/10'
                        }`}
                      >
                        {featureFlags[key] ? 'Enabled' : 'Disabled'}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {settingsSubTab === 'packages' && (
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-6 shadow-lg space-y-4 max-w-4xl">
                <div className="pb-3 border-b border-white/10">
                  <h3 className="text-base font-bold text-white">Featured Package Preview</h3>
                  <p className="text-[11px] text-white/60 mt-1">
                    Demo package pricing for the paid featured listing flow described in Section 52.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {(settings.featuredPackages || []).map((pkg) => (
                    <div key={pkg.id} className="rounded-xl border border-white/10 bg-[#07130c] p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold text-white">{pkg.name}</span>
                        <span className="text-[10px] font-bold text-[#C8FF5E]">Priority {pkg.priority}</span>
                      </div>

                      <div className="mt-2 text-lg font-black text-[#C8FF5E]">৳{pkg.price.toLocaleString()}</div>
                      <div className="mt-1 text-[11px] text-white/60">{pkg.durationDays} days • {pkg.description}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {settingsSubTab === 'gateways' && (
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-6 shadow-lg space-y-4 max-w-4xl">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <div>
                    <h3 className="text-base font-bold text-white">Payment Gateway Configuration</h3>
                    <p className="text-[11px] text-white/60 mt-1">
                      All bookings are collected here first; the platform commission is deducted, and the remainder is paid out to turf owners via their configured payout method. Sandbox credentials are safe to test with.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {(['sslcommerz', 'surjopay', 'bkash', 'nagad', 'custom'] as PaymentGatewayProvider[]).map((provider) => (
                      <button
                        key={provider}
                        type="button"
                        onClick={() => addGateway(provider)}
                        className="px-2.5 py-1.5 rounded-xl border border-[#C8FF5E]/40 text-[#C8FF5E] text-[10px] font-bold hover:bg-[#C8FF5E]/10 transition-colors cursor-pointer"
                      >
                        + {gatewayProviderLabels[provider]}
                      </button>
                    ))}
                  </div>
                </div>

                {paymentGateways.length === 0 ? (
                  <p className="text-xs text-white/50">No payment gateways configured yet. Add one above to get started.</p>
                ) : (
                  <div className="space-y-3">
                    {paymentGateways.map((gateway) => (
                      <div key={gateway.id} className="rounded-xl border border-white/10 bg-[#07130c] p-4 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40">
                              {gatewayProviderLabels[gateway.provider]}
                            </span>
                            {gateway.isSandbox && (
                              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-950/60 text-amber-300 border border-amber-500/40">
                                Sandbox
                              </span>
                            )}
                            {gateway.isActive && (
                              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                                Active
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => updateGateway(gateway.id, { isSandbox: !gateway.isSandbox })}
                              className="text-[10px] font-semibold px-2.5 py-1 rounded-xl border border-white/15 text-white/70 hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
                            >
                              {gateway.isSandbox ? 'Mark as Live' : 'Mark as Sandbox'}
                            </button>
                            <button
                              type="button"
                              onClick={() => updateGateway(gateway.id, { isActive: !gateway.isActive })}
                              className={`text-[10px] font-semibold px-2.5 py-1 rounded-xl border transition-colors cursor-pointer ${
                                gateway.isActive
                                  ? 'border-white/15 text-white/60 hover:text-white hover:bg-white/[0.05]'
                                  : 'border-[#C8FF5E] text-[#C8FF5E] hover:bg-[#C8FF5E]/10'
                              }`}
                            >
                              {gateway.isActive ? 'Disable' : 'Enable'}
                            </button>
                            <button
                              type="button"
                              onClick={() => removeGateway(gateway.id)}
                              className="text-[10px] font-semibold px-2.5 py-1 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-500/10 transition-colors cursor-pointer"
                            >
                              Remove
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-[11px] text-white/60 font-semibold mb-1 block">Display Label:</label>
                          <input
                            type="text"
                            value={gateway.label}
                            onChange={(e) => updateGateway(gateway.id, { label: e.target.value })}
                            className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {gateway.provider === 'bkash' || gateway.provider === 'nagad' ? (
                            <div>
                              <label className="text-[11px] text-white/60 font-semibold mb-1 block">Merchant Number:</label>
                              <input
                                type="text"
                                value={gateway.merchantNumber || ''}
                                onChange={(e) => updateGateway(gateway.id, { merchantNumber: e.target.value })}
                                placeholder="e.g. 01819-223344"
                                className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                              />
                            </div>
                          ) : (
                            <div>
                              <label className="text-[11px] text-white/60 font-semibold mb-1 block">Store ID:</label>
                              <input
                                type="text"
                                value={gateway.storeId || ''}
                                onChange={(e) => updateGateway(gateway.id, { storeId: e.target.value })}
                                placeholder="Sandbox / live store ID"
                                className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                              />
                            </div>
                          )}

                          <div>
                            <label className="text-[11px] text-white/60 font-semibold mb-1 block">API Key:</label>
                            <input
                              type="text"
                              value={gateway.apiKey || ''}
                              onChange={(e) => updateGateway(gateway.id, { apiKey: e.target.value })}
                              placeholder="API key / username"
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30 font-mono"
                            />
                          </div>

                          <div>
                            <label className="text-[11px] text-white/60 font-semibold mb-1 block">API Secret:</label>
                            <input
                              type="password"
                              value={gateway.apiSecret || ''}
                              onChange={(e) => updateGateway(gateway.id, { apiSecret: e.target.value })}
                              placeholder="API secret / password"
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30 font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {settingsSubTab === 'email' && (
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-6 shadow-lg space-y-4 max-w-4xl">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <div>
                    <h3 className="text-base font-bold text-white">SMTP / Outgoing Email Servers</h3>
                    <p className="text-[11px] text-white/60 mt-1">
                      Add, edit, or remove SMTP servers used for activation codes, password resets, and booking emails. Only the
                      server marked <strong>Active</strong> is used to send mail.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={addSmtpConfig}
                    className="px-3 py-2 rounded-xl border border-[#C8FF5E]/40 text-[#C8FF5E] text-xs font-bold hover:bg-[#C8FF5E]/10 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    + Add SMTP Server
                  </button>
                </div>

                {smtpConfigs.length === 0 ? (
                  <p className="text-xs text-white/50">No SMTP servers configured yet. Add one above to enable activation & reset emails.</p>
                ) : (
                  <div className="space-y-3">
                    {smtpConfigs.map((config) => (
                      <div key={config.id} className="rounded-xl border border-white/10 bg-[#07130c] p-4 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div className="flex items-center gap-2 flex-wrap flex-1 min-w-[180px]">
                            <input
                              type="text"
                              value={config.label}
                              onChange={(e) => updateSmtpConfig(config.id, { label: e.target.value })}
                              className="bg-[#0A1E14] border border-white/10 rounded-lg px-2 py-1 text-xs font-bold text-white focus:border-[#C8FF5E] outline-none"
                            />
                            {config.isActive && (
                              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-500/40">
                                Active
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            {!config.isActive && (
                              <button
                                type="button"
                                onClick={() => setActiveSmtpConfig(config.id)}
                                className="text-[10px] font-semibold px-2.5 py-1 rounded-xl border border-[#C8FF5E] text-[#C8FF5E] hover:bg-[#C8FF5E]/10 transition-colors cursor-pointer"
                              >
                                Set Active
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => removeSmtpConfig(config.id)}
                              className="text-[10px] font-semibold px-2.5 py-1 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-500/10 transition-colors cursor-pointer"
                            >
                              Remove
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                          <div className="sm:col-span-2">
                            <label className="text-white/60 font-semibold mb-1 block">SMTP Server Address:</label>
                            <input
                              type="text"
                              value={config.host}
                              onChange={(e) => updateSmtpConfig(config.id, { host: e.target.value })}
                              placeholder="e.g. postal.trytopdigitize.com"
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                            />
                          </div>
                          <div>
                            <label className="text-white/60 font-semibold mb-1 block">Port:</label>
                            <input
                              type="number"
                              value={config.port}
                              onChange={(e) => updateSmtpConfig(config.id, { port: Number(e.target.value) })}
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none font-bold"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="text-white/60 font-semibold mb-1 block">Username:</label>
                            <input
                              type="text"
                              value={config.username}
                              onChange={(e) => updateSmtpConfig(config.id, { username: e.target.value })}
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none font-mono"
                            />
                          </div>
                          <div>
                            <label className="text-white/60 font-semibold mb-1 block">Password:</label>
                            <input
                              type="password"
                              value={config.password}
                              onChange={(e) => updateSmtpConfig(config.id, { password: e.target.value })}
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none font-mono"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="text-white/60 font-semibold mb-1 block">From Name:</label>
                            <input
                              type="text"
                              value={config.fromName}
                              onChange={(e) => updateSmtpConfig(config.id, { fromName: e.target.value })}
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none"
                            />
                          </div>
                          <div>
                            <label className="text-white/60 font-semibold mb-1 block">From Email:</label>
                            <input
                              type="email"
                              value={config.fromEmail}
                              onChange={(e) => updateSmtpConfig(config.id, { fromEmail: e.target.value })}
                              placeholder="noreply@yourdomain.com"
                              className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                            />
                          </div>
                        </div>

                        <label className="flex items-center gap-2 cursor-pointer text-xs">
                          <input
                            type="checkbox"
                            checked={config.secure}
                            onChange={(e) => updateSmtpConfig(config.id, { secure: e.target.checked })}
                            className="accent-[#C8FF5E] w-4 h-4"
                          />
                          <span className="text-white/70 font-semibold">Use SSL/TLS (typically port 465)</span>
                        </label>

                        <div className="pt-2 border-t border-white/10 flex flex-col sm:flex-row gap-2">
                          <input
                            type="email"
                            value={smtpTestEmailByConfig[config.id] || ''}
                            onChange={(e) => setSmtpTestEmailByConfig((prev) => ({ ...prev, [config.id]: e.target.value }))}
                            placeholder="Send test email to…"
                            className="flex-1 bg-[#0A1E14] border border-white/10 rounded-xl p-2 text-xs text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                          />
                          <button
                            type="button"
                            disabled={sendingTestConfigId === config.id}
                            onClick={() => handleSendSmtpTest(config)}
                            className="px-3 py-2 bg-white/10 hover:bg-white/15 disabled:opacity-50 text-white font-bold text-xs rounded-xl cursor-pointer transition-colors whitespace-nowrap"
                          >
                            {sendingTestConfigId === config.id ? 'Sending…' : 'Send Test Email'}
                          </button>
                        </div>
                        {smtpTestStatusByConfig[config.id] && (
                          <div className="p-2.5 rounded-xl border border-white/10 bg-white/[0.03] text-[11px] text-white/70">
                            {smtpTestStatusByConfig[config.id]}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: REPORTS & ANALYTICS (SECTION 25) */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-[#C8FF5E]" /> Reports & Analytics Dashboard (Section 25)
                </h2>
                <p className="text-xs text-white/60 mt-1">
                  Gross booking value, platform commission, utilization, owner earnings, and booking lifecycle trends in one consolidated view.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl border border-white/10 bg-[#0A1E14] text-white/70 text-[10px] font-bold uppercase tracking-wider cursor-pointer"
                >
                  Last 7 Days
                </button>
                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl bg-[#C8FF5E] text-[#0A1E14] text-[10px] font-bold uppercase tracking-wider shadow-md shadow-[#C8FF5E]/20 cursor-pointer"
                >
                  CSV Export (UI)
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Gross Booking Value</div>
                <div className="mt-2 text-xl font-black text-white">৳{totalGrossBookingValue.toLocaleString()}</div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Platform Commission</div>
                <div className="mt-2 text-xl font-black text-[#C8FF5E]">৳{totalCommissionEarned.toLocaleString()}</div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Net Owner Earnings</div>
                <div className="mt-2 text-xl font-black text-emerald-400">৳{netOwnerEarnings.toLocaleString()}</div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Bookings</div>
                <div className="mt-2 text-xl font-black text-white">{totalBookings}</div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Cancellation Rate</div>
                <div className="mt-2 text-xl font-black text-amber-300">{cancellationRate.toFixed(1)}%</div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-4">
                <div className="text-[10px] uppercase tracking-wider text-white/50">Avg Booking Value</div>
                <div className="mt-2 text-xl font-black text-white">৳{avgBookingValue.toFixed(0)}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-[1.7fr_1fr] gap-6">
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white">Revenue Trend</h3>
                    <p className="text-[11px] text-white/60">Last 7 days gross booking value</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40 text-[10px] font-bold uppercase tracking-wider">
                    Daily</span>
                </div>

                <div className="mt-6 flex items-end justify-between gap-3 h-44">
                  {recentDays.map((day) => {
                    const height = Math.max(14, (day.value / maxDailyRevenue) * 100);

                    return (
                      <div key={day.key} className="flex-1 flex flex-col items-center gap-2">
                        <div className="w-full h-32 flex items-end justify-center rounded-xl border border-white/10 bg-[#07130c] p-1.5">
                          <div
                            className="w-full rounded-lg bg-gradient-to-t from-[#C8FF5E] via-emerald-400 to-emerald-300"
                            style={{ height: `${height}%` }}
                          />
                        </div>
                        <div className="text-[10px] text-white/60">{day.label}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-sm font-bold text-white">Booking Source Mix</h3>
                  <span className="text-[10px] uppercase tracking-wider text-white/50">Revenue</span>
                </div>

                <div className="mt-5 space-y-4">
                  {sourceBreakdown.map(({ source, total }) => {
                    const width = (total / Math.max(sourceBreakdown[0]?.total || 1, 1)) * 100;

                    return (
                      <div key={source}>
                        <div className="flex items-center justify-between text-[11px] text-white/70">
                          <span className="font-semibold capitalize">{source.replace('_', ' ')}</span>
                          <span className="font-bold text-[#C8FF5E]">৳{total.toLocaleString()}</span>
                        </div>
                        <div className="mt-2 h-2 rounded-full bg-white/5 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-[#C8FF5E] to-emerald-400"
                            style={{ width: `${width}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <h3 className="text-sm font-bold text-white">Top Turf Revenue</h3>
                  <span className="text-[10px] uppercase tracking-wider text-white/50">Net owner earnings</span>
                </div>

                <div className="mt-4 space-y-4">
                  {topTurfs.map((turf) => {
                    const width = (turf.total / maxTopTurfValue) * 100;

                    return (
                      <div key={turf.name}>
                        <div className="flex items-center justify-between gap-3 text-[11px]">
                          <div>
                            <div className="font-bold text-white">{turf.name}</div>
                            <div className="text-white/60">{turf.bookings} bookings</div>
                          </div>
                          <div className="font-black text-[#C8FF5E]">৳{turf.total.toLocaleString()}</div>
                        </div>
                        <div className="mt-2 h-2 rounded-full bg-white/5 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-[#C8FF5E]"
                            style={{ width: `${width}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <h3 className="text-sm font-bold text-white">Operational Snapshot</h3>
                  <span className="text-[10px] uppercase tracking-wider text-white/50">Live metrics</span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-white/10 bg-[#07130c] p-3">
                    <div className="text-[10px] uppercase tracking-wider text-white/50">Completed</div>
                    <div className="mt-2 text-lg font-black text-white">{completedBookings}</div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#07130c] p-3">
                    <div className="text-[10px] uppercase tracking-wider text-white/50">Cancelled</div>
                    <div className="mt-2 text-lg font-black text-amber-300">{cancelledBookings}</div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#07130c] p-3">
                    <div className="text-[10px] uppercase tracking-wider text-white/50">Pending Approvals</div>
                    <div className="mt-2 text-lg font-black text-white">{pendingTurfs.length + pendingOwners.length}</div>
                  </div>

                  <div className="rounded-xl border border-white/10 bg-[#07130c] p-3">
                    <div className="text-[10px] uppercase tracking-wider text-white/50">Open Disputes</div>
                    <div className="mt-2 text-lg font-black text-rose-300">{disputes.filter((d) => d.status === 'pending').length}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
              <div className="flex items-center justify-between gap-3 p-4 border-b border-white/10">
                <div>
                  <h3 className="text-sm font-bold text-white">Recent Booking Snapshot</h3>
                  <p className="text-[11px] text-white/60">Latest bookings across the platform</p>
                </div>
                <button
                  type="button"
                  className="px-3 py-1.5 rounded-xl bg-[#C8FF5E] text-[#0A1E14] text-[10px] font-bold uppercase tracking-wider shadow-md shadow-[#C8FF5E]/20 cursor-pointer"
                >
                  View All
                </button>
              </div>

              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-left text-xs text-white/80">
                  <thead className="bg-[#0e271a] text-white/60 uppercase font-bold text-[10px] border-b border-white/10">
                    <tr>
                      <th className="py-3 px-4">Booking #</th>
                      <th className="py-3 px-4">Turf</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Source</th>
                      <th className="py-3 px-4">Paid Total</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {recentBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-white/[0.03] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{b.bookingNumber}</td>
                        <td className="py-3 px-4 text-white">{b.turfName}</td>
                        <td className="py-3 px-4 text-white/60">{b.date}</td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/30">
                            {b.bookingSource}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-black text-white">৳{b.totalPaid.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                              b.status === 'confirmed'
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                                : b.status === 'completed'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {b.status.replace('_', ' ')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: ALL PLATFORM BOOKINGS */}
        {activeTab === 'bookings' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Platform-Wide Booking Oversight</h2>
                <p className="text-xs text-white/60">All reservations across vendors, sources, and payment states.</p>
              </div>
            </div>

            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-left text-xs text-white/80">
                  <thead className="bg-[#0e271a] text-white/60 uppercase font-bold text-[10px] border-b border-white/10">
                    <tr>
                      <th className="py-3 px-4">Booking #</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Turf & Date</th>
                      <th className="py-3 px-4">Source</th>
                      <th className="py-3 px-4">Paid Total</th>
                      <th className="py-3 px-4">Platform Fee</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Intervention</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {bookings.map((b) => (
                      <tr key={b.id} className="hover:bg-white/[0.03] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{b.bookingNumber}</td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-white">{b.customerName}</div>
                          <div className="text-[11px] text-white/60">{b.customerPhone}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-white font-medium">{b.turfName}</div>
                          <div className="text-[11px] text-white/60">
                            {b.date} ({b.startTime} - {b.endTime})
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/30">
                            {b.bookingSource}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-black text-white">৳{b.totalPaid}</td>
                        <td className="py-3 px-4 text-[#C8FF5E] font-bold">৳{b.platformFeeAmount}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                              b.status === 'confirmed'
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                                : b.status === 'completed'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {b.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          {b.status !== 'cancelled' && b.status !== 'refunded' && (
                            <button
                              onClick={() => {
                                if (confirm('Admin force cancellation will issue full refund to player. Proceed?')) {
                                  cancelBooking(b.id, 'Admin force cancelled dispute', true);
                                }
                              }}
                              className="px-2.5 py-1 bg-rose-950/40 text-rose-300 hover:bg-rose-900/60 text-[11px] font-semibold rounded-xl border border-rose-800/40 cursor-pointer transition-colors"
                            >
                              Force Refund
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: DISPUTES RESOLUTION */}
        {activeTab === 'disputes' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Dispute Center & Arbitration (Section 9.6)</h2>
                <p className="text-xs text-white/60">Investigate and arbitrate complaints between players and turf owners.</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {disputes.map((d) => (
                <div key={d.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-xs text-[#C8FF5E]">Ref #{d.bookingNumber}</span>
                      <h4 className="font-bold text-white text-sm mt-0.5">Raised by: {d.raisedByName}</h4>
                    </div>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                        d.status === 'resolved'
                          ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                          : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                      }`}
                    >
                      {d.status}
                    </span>
                  </div>

                  <div className="bg-[#07130c] border border-white/10 p-3 rounded-xl text-xs space-y-1">
                    <div className="text-white/60 uppercase text-[10px] font-bold">Category: {d.category}</div>
                    <p className="text-white/80">{d.description}</p>
                  </div>

                  {d.status === 'resolved' ? (
                    <div className="text-xs text-[#C8FF5E] font-medium">
                      Resolution: {d.resolutionNotes} (By: {d.resolvedBy})
                    </div>
                  ) : (
                    <div className="flex gap-2 pt-1">
                      <button
                        onClick={() => resolveDispute(d.id, 'Admin audited communication and verified issue resolved')}
                        className="w-full py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                      >
                        Mark Dispute Resolved
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 8: TOURNAMENTS (SECTION 50)                                           */}
        {/* ========================================================================= */}
        {activeTab === 'tournaments' && (
          <div className="mt-6">
            <TournamentsView />
          </div>
        )}
      </div>

      {/* MODAL: APPROVE WITHDRAWAL */}
      {selectedWdForApproval && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/15 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Approve & Disburse Payout</h3>
            <p className="text-xs text-white/70">
              Enter the bank/bKash disbursement transaction reference for audit tracking:
            </p>

            <input
              type="text"
              value={payoutRef}
              onChange={(e) => setPayoutRef(e.target.value)}
              placeholder="e.g. BKASH-TXN-882910 or BRAC-FT-99120"
              className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-xs text-white focus:border-[#C8FF5E] outline-none"
            />

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedWdForApproval(null)}
                className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  approveWithdrawal(selectedWdForApproval, payoutRef || 'ADMIN-DISBURSED');
                  setSelectedWdForApproval(null);
                  setPayoutRef('');
                }}
                className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
              >
                Confirm Payout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: REJECT WITHDRAWAL */}
      {selectedWdForReject && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/15 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">Reject Withdrawal Request</h3>
            <p className="text-xs text-white/70">
              Funds will be automatically returned to the owner's available wallet balance. State reason:
            </p>

            <input
              type="text"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. Bank account name mismatch / KYC verification required"
              className="w-full bg-[#07130c] border border-white/15 rounded-xl p-2.5 text-xs text-white focus:border-[#C8FF5E] outline-none"
            />

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedWdForReject(null)}
                className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  rejectWithdrawal(selectedWdForReject, rejectReason || 'Account mismatch');
                  setSelectedWdForReject(null);
                  setRejectReason('');
                }}
                className="flex-1 py-2.5 bg-rose-950/60 hover:bg-rose-900/80 text-rose-200 border border-rose-800/60 font-bold text-xs rounded-xl cursor-pointer transition-colors"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
