import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Turf, Slot, Booking, PaymentMethod, PaymentStatus, StaffAssignment, TurfAddon } from '../../types';
import {
  Building2,
  Calendar,
  DollarSign,
  Users,
  Plus,
  Clock,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  X,
  CreditCard,
  Phone,
  ShieldCheck,
  Lock,
  Unlock,
  QrCode,
  Sparkles,
  Trophy,
} from 'lucide-react';
import { TournamentsView } from '../tournaments/TournamentsView';
import { formatBDDate } from '../../utils/datetime';

export const OwnerPortal: React.FC = () => {
  const {
    currentUser,
    ownerProfiles,
    turfs,
    slots,
    bookings,
    staffAssignments,
    wallets,
    withdrawals,
    settings,
    createTurf,
    updateTurf,
    deleteTurf,
    toggleSlotBlock,
    addSlot,
    createManualBooking,
    cancelBooking,
    checkInBooking,
    completeBooking,
    createStaff,
    requestWithdrawal,
    updateOwnerPayoutDetails,
    ownerActiveTab,
    setOwnerActiveTab,
    openOwnerManualBookingModal,
    setOpenOwnerManualBookingModal,
  } = useApp();

  const activeTab = ownerActiveTab;
  const setActiveTab = setOwnerActiveTab;

  // Owner profile & scoping
  const profile = ownerProfiles.find((p) => p.userId === currentUser.id);
  const isApproved = profile?.approvalStatus === 'active' && currentUser.status === 'active';
  const myTurfs = turfs.filter((t) => t.ownerId === currentUser.id);
  const myTurfIds = myTurfs.map((t) => t.id);
  const myBookings = bookings.filter((b) => myTurfIds.includes(b.turfId));
  const myWallet = wallets[currentUser.id] || {
    ownerId: currentUser.id,
    availableBalance: 0,
    heldBalance: 0,
    totalEarnings: 0,
    totalWithdrawn: 0,
  };
  const myWithdrawals = withdrawals.filter((w) => w.ownerId === currentUser.id);
  const myStaff = staffAssignments.filter((sa) => sa.ownerId === currentUser.id);
  const featuredPackages = settings.featuredPackages || [];
  const [selectedFeaturedPackageId, setSelectedFeaturedPackageId] = useState<string>(featuredPackages[0]?.id || '');
  const selectedFeaturedPackage = featuredPackages.find((pkg) => pkg.id === selectedFeaturedPackageId) || featuredPackages[0];
  const demoPlatformCredits = 1500;

  // Filter state for bookings
  const [bookingFilterTurf, setBookingFilterTurf] = useState<string>('All');
  const [bookingFilterStatus, setBookingFilterStatus] = useState<string>('All');

  // Modals
  const [showManualBookingModal, setShowManualBookingModal] = useState(false);
  const isManualModalOpen = showManualBookingModal || openOwnerManualBookingModal;
  const closeManualModal = () => {
    setShowManualBookingModal(false);
    setOpenOwnerManualBookingModal(false);
  };
  const [showAddTurfModal, setShowAddTurfModal] = useState(false);
  const [showAddonsModal, setShowAddonsModal] = useState(false);
  const [selectedTurfForAddonsId, setSelectedTurfForAddonsId] = useState<string | null>(null);
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [showStaffSetupPreview, setShowStaffSetupPreview] = useState<StaffAssignment | null>(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [selectedSlotForBlock, setSelectedSlotForBlock] = useState<Slot | null>(null);

  // Manual Booking Form State (Section 7.4)
  const [mbTurfId, setMbTurfId] = useState<string>(myTurfs[0]?.id || '');
  const [mbSlotId, setMbSlotId] = useState<string>('');
  const [mbCustomerName, setMbCustomerName] = useState('');
  const [mbCustomerPhone, setMbCustomerPhone] = useState('');
  const [mbPaymentMethod, setMbPaymentMethod] = useState<PaymentMethod>('cash');
  const [mbPaymentStatus, setMbPaymentStatus] = useState<PaymentStatus>('paid');
  const [mbReference, setMbReference] = useState('');
  const [mbNotes, setMbNotes] = useState('');

  // Add Turf Form State
  const [editingTurfId, setEditingTurfId] = useState<string | null>(null);
  const [newTurfName, setNewTurfName] = useState('');
  const [newTurfDesc, setNewTurfDesc] = useState('');
  const [newTurfAddress, setNewTurfAddress] = useState('');
  const [newTurfArea, setNewTurfArea] = useState('Banani');
  const [newTurfPrice, setNewTurfPrice] = useState(1200);
  const [newTurfSports, setNewTurfSports] = useState<string[]>(['Football']);
  const [newTurfAmenities, setNewTurfAmenities] = useState<string[]>(['Floodlights', 'Washroom']);
  const [newTurfCancellationHours, setNewTurfCancellationHours] = useState<number>(3);
  const [turfPendingDelete, setTurfPendingDelete] = useState<Turf | null>(null);
  const [deleteTurfError, setDeleteTurfError] = useState('');

  const [addonName, setAddonName] = useState('');
  const [addonDescription, setAddonDescription] = useState('');
  const [addonCategory, setAddonCategory] = useState<'equipment' | 'service' | 'food' | 'other'>('equipment');
  const [addonPrice, setAddonPrice] = useState<number>(120);
  const [addonStock, setAddonStock] = useState<number | null>(null);

  const turfSportOptions = ['Football', 'Cricket', 'Basketball', 'Badminton', 'Volleyball', 'Tennis'];
  const turfAmenityOptions = ['Floodlights', 'Washroom', 'Parking', 'Locker Room', 'Cafeteria', 'Drinking Water', 'Changing Room', 'Gallery'];

  // Add Staff Form State
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPhone, setStaffPhone] = useState('');
  const [staffTurfIds, setStaffTurfIds] = useState<string[]>(myTurfIds.slice(0, 1));
  const [staffPerms, setStaffPerms] = useState<string[]>([
    'bookings.view',
    'bookings.check_in',
    'bookings.complete',
    'bookings.create_manual',
    'slots.view',
    'slots.block',
  ]);

  // Withdrawal Form State
  const [withdrawAmount, setWithdrawAmount] = useState<number>(1000);
  const [withdrawMethod, setWithdrawMethod] = useState('bKash');
  const [withdrawDetails, setWithdrawDetails] = useState('');
  const [withdrawMsg, setWithdrawMsg] = useState('');

  // Payout Details Editing (bank / bKash / Nagad)
  const [isEditingPayout, setIsEditingPayout] = useState(false);
  const [payoutFormMethod, setPayoutFormMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'bank_account'>('bkash');
  const [payoutFormAccountNumber, setPayoutFormAccountNumber] = useState('');
  const [payoutFormBankName, setPayoutFormBankName] = useState('');
  const [payoutFormBranchName, setPayoutFormBranchName] = useState('');
  const [payoutFormAccountHolder, setPayoutFormAccountHolder] = useState('');
  const [payoutFormMessage, setPayoutFormMessage] = useState('');

  const openEditPayoutForm = () => {
    setPayoutFormMethod(profile?.payoutMethod || 'bkash');
    setPayoutFormAccountNumber(profile?.payoutDetails.accountNumber || '');
    setPayoutFormBankName(profile?.payoutDetails.bankName || '');
    setPayoutFormBranchName(profile?.payoutDetails.branchName || '');
    setPayoutFormAccountHolder(profile?.payoutDetails.accountHolderName || '');
    setPayoutFormMessage('');
    setIsEditingPayout(true);
  };

  const handleSavePayoutDetails = (e: React.FormEvent) => {
    e.preventDefault();
    const result = updateOwnerPayoutDetails({
      payoutMethod: payoutFormMethod,
      accountNumber: payoutFormAccountNumber,
      bankName: payoutFormBankName,
      branchName: payoutFormBranchName,
      accountHolderName: payoutFormAccountHolder,
    });
    setPayoutFormMessage(result.message);
    if (result.success) {
      setIsEditingPayout(false);
    }
  };

  // Slot Manager State
  const [slotDate, setSlotDate] = useState(new Date().toISOString().split('T')[0]);
  const [slotTurfId, setSlotTurfId] = useState(myTurfs[0]?.id || '');

  // Filtered Bookings
  const pendingSetupStaffCount = myStaff.filter((staff) => staff.status === 'pending_setup').length;

  const filteredBookings = myBookings.filter((b) => {
    const matchesTurf = bookingFilterTurf === 'All' || b.turfId === bookingFilterTurf;
    const matchesStatus = bookingFilterStatus === 'All' || b.status === bookingFilterStatus;
    return matchesTurf && matchesStatus;
  });

  const availableSlotsForManual = slots.filter(
    (s) => s.turfId === mbTurfId && s.status === 'available'
  );

  const handleManualBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mbTurfId || !mbSlotId || !mbCustomerName || !mbCustomerPhone) return;

    createManualBooking({
      turfId: mbTurfId,
      slotId: mbSlotId,
      customerName: mbCustomerName,
      customerPhone: mbCustomerPhone,
      paymentMethod: mbPaymentMethod,
      paymentStatus: mbPaymentStatus,
      paymentReference: mbReference,
      notes: mbNotes,
    });

    closeManualModal();
    setMbCustomerName('');
    setMbCustomerPhone('');
    setMbReference('');
    setMbNotes('');
  };

  const handleAddTurfSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTurfName || !newTurfAddress) return;

    if (editingTurfId) {
      updateTurf(editingTurfId, {
        name: newTurfName,
        description: newTurfDesc,
        address: newTurfAddress,
        area: newTurfArea,
        sportTypes: newTurfSports,
        amenities: newTurfAmenities,
        basePricePerHour: Number(newTurfPrice),
        cancellationCutoffHours: Number(newTurfCancellationHours),
      });
    } else {
      createTurf({
        ownerId: currentUser.id,
        ownerName: currentUser.name,
        name: newTurfName,
        description: newTurfDesc || 'Professional sports pitch with tournament grade lighting.',
        address: newTurfAddress,
        area: newTurfArea,
        city: 'Dhaka',
        latitude: 23.79,
        longitude: 90.41,
        sportTypes: newTurfSports,
        amenities: newTurfAmenities,
        basePricePerHour: Number(newTurfPrice),
        operatingHours: { openTime: '07:00', closeTime: '23:59' },
        photos: ['https://images.unsplash.com/photo-1529900748604-07564a03e7a6?w=800'],
        status: 'pending_review',
        cancellationCutoffHours: Number(newTurfCancellationHours),
      });
    }

    setShowAddTurfModal(false);
    setEditingTurfId(null);
    setNewTurfName('');
    setNewTurfDesc('');
    setNewTurfAddress('');
    setNewTurfArea('Banani');
    setNewTurfPrice(1200);
    setNewTurfSports(['Football']);
    setNewTurfAmenities(['Floodlights', 'Washroom']);
    setNewTurfCancellationHours(3);
  };

  const openAddTurfModal = () => {
    setEditingTurfId(null);
    setNewTurfName('');
    setNewTurfDesc('');
    setNewTurfAddress('');
    setNewTurfArea('Banani');
    setNewTurfPrice(1200);
    setNewTurfSports(['Football']);
    setNewTurfAmenities(['Floodlights', 'Washroom']);
    setNewTurfCancellationHours(3);
    setShowAddTurfModal(true);
  };

  const openEditTurfModal = (turf: Turf) => {
    setEditingTurfId(turf.id);
    setNewTurfName(turf.name);
    setNewTurfDesc(turf.description);
    setNewTurfAddress(turf.address);
    setNewTurfArea(turf.area);
    setNewTurfPrice(turf.basePricePerHour);
    setNewTurfSports(turf.sportTypes);
    setNewTurfAmenities(turf.amenities);
    setNewTurfCancellationHours(turf.cancellationCutoffHours ?? 3);
    setShowAddTurfModal(true);
  };

  const handleConfirmDeleteTurf = () => {
    if (!turfPendingDelete) return;
    const result = deleteTurf(turfPendingDelete.id);
    if (!result.success) {
      setDeleteTurfError(result.message);
      return;
    }
    setTurfPendingDelete(null);
    setDeleteTurfError('');
  };

  const selectedTurfForAddons = selectedTurfForAddonsId ? turfs.find((t) => t.id === selectedTurfForAddonsId) ?? null : null;

  const handleAddAddonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTurfForAddons || !addonName.trim()) return;

    const existingAddons = selectedTurfForAddons.addons || [];
    const nextAddon: TurfAddon = {
      id: `addon-${Date.now()}`,
      turfId: selectedTurfForAddons.id,
      name: addonName.trim(),
      description: addonDescription.trim() || undefined,
      category: addonCategory,
      price: Number(addonPrice) || 0,
      stockQuantity: addonStock !== null && addonStock >= 0 ? addonStock : null,
      isActive: true,
      displayOrder: existingAddons.length + 1,
    };

    updateTurf(selectedTurfForAddons.id, {
      addons: [...existingAddons, nextAddon],
    });

    setAddonName('');
    setAddonDescription('');
    setAddonCategory('equipment');
    setAddonPrice(120);
    setAddonStock(null);
  };

  const handleAddonToggle = (addonId: string) => {
    if (!selectedTurfForAddons) return;

    updateTurf(selectedTurfForAddons.id, {
      addons: (selectedTurfForAddons.addons || []).map((addon) =>
        addon.id === addonId ? { ...addon, isActive: !addon.isActive } : addon
      ),
    });
  };

  const handleAddonDelete = (addonId: string) => {
    if (!selectedTurfForAddons) return;

    updateTurf(selectedTurfForAddons.id, {
      addons: (selectedTurfForAddons.addons || []).filter((addon) => addon.id !== addonId),
    });
  };

  const handleWithdrawalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = requestWithdrawal(Number(withdrawAmount), withdrawMethod, withdrawDetails || profile?.payoutDetails.accountNumber || '');
    setWithdrawMsg(res.message);
    if (res.success) {
      setTimeout(() => {
        setShowWithdrawModal(false);
        setWithdrawMsg('');
      }, 1500);
    }
  };

  const handleCreateStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName || !staffEmail || !staffPhone) return;
    createStaff(staffName, staffEmail, staffPhone, staffTurfIds, staffPerms);
    setShowAddStaffModal(false);
    setStaffName('');
    setStaffEmail('');
    setStaffPhone('');
  };

  return (
    <div className="min-h-screen bg-[#07130c] text-slate-100 pb-16">
      {/* Header & Approval Notice */}
      <div className="bg-[#0A1E14] border-b border-white/10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 text-[10px] font-bold tracking-wider uppercase rounded-full bg-[#C8FF5E]/15 text-[#C8FF5E] border border-[#C8FF5E]/30">
                  Turf Owner Console
                </span>
                <span className="text-xs text-white/60">Business: {profile?.businessName || currentUser.name}</span>
              </div>
              <h1 className="text-2xl font-black text-white mt-1">Grounds & Booking Operations</h1>
            </div>

            {/* Sub-tabs */}
            <div className="flex items-center gap-1.5 bg-white/[0.06] p-1 rounded-2xl border border-white/10 flex-wrap no-scrollbar">
              <button
                onClick={() => setActiveTab('bookings')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'bookings' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Bookings ({myBookings.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('turfs')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'turfs' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>My Turfs ({myTurfs.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('slots')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'slots' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Slots & Schedule</span>
              </button>
              <button
                onClick={() => setActiveTab('staff')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'staff' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Staff ({myStaff.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('wallet')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'wallet' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>Wallet & Payouts</span>
              </button>
              <button
                onClick={() => setActiveTab('tournaments')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                  activeTab === 'tournaments' ? 'bg-[#C8FF5E] text-[#0A1E14] shadow-md shadow-[#C8FF5E]/20' : 'text-white/70 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Tournaments (Sec 50)</span>
              </button>
            </div>
          </div>

          {/* Pending Approval Notice if not approved yet */}
          {!isApproved && (
            <div className="mt-4 rounded-2xl border border-amber-500/40 bg-amber-950/35 p-4 text-amber-100 shadow-[0_16px_40px_rgba(245,158,11,0.12)]">
              <div className="flex flex-col xl:flex-row xl:items-start gap-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className="mt-0.5 flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400/15 border border-amber-300/30 text-amber-300">
                    <AlertTriangle className="w-5 h-5" />
                  </div>

                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-300/80">
                          Onboarding Status
                        </p>
                        <h2 className="text-lg font-black text-white mt-1">Account pending admin approval</h2>
                      </div>

                      <span className="inline-flex items-center rounded-full border border-amber-400/40 bg-amber-500/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-200">
                        Awaiting Review
                      </span>
                    </div>

                    <p className="mt-2 text-sm text-amber-100/80 leading-relaxed">
                      Your turf owner profile has been submitted successfully. The platform is currently reviewing your business details,
                      payout setup, and verification information before your venue can go live for public bookings.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <div className="rounded-xl border border-white/10 bg-black/10 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-amber-200/70">Business Name</p>
                  <p className="mt-1 text-sm font-bold text-white">{profile?.businessName || 'Not provided yet'}</p>
                </div>

                <div className="rounded-xl border border-white/10 bg-black/10 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-amber-200/70">Trade License / NID</p>
                  <p className="mt-1 text-sm font-bold text-white">{profile?.nidOrTradeLicense || 'Under verification'}</p>
                </div>

                <div className="rounded-xl border border-white/10 bg-black/10 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-amber-200/70">Payout Method</p>
                  <p className="mt-1 text-sm font-bold text-white uppercase">{profile?.payoutMethod || 'Pending setup'}</p>
                </div>

                <div className="rounded-xl border border-white/10 bg-black/10 p-3">
                  <p className="text-[10px] uppercase tracking-wider text-amber-200/70">Submitted</p>
                  <p className="mt-1 text-sm font-bold text-white">{formatBDDate(new Date().toISOString())}</p>
                </div>
              </div>
            </div>
          )}

          {/* Quick Metrics KPI row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Active Turfs</div>
              <div className="text-xl font-black text-white mt-1">{myTurfs.filter((t) => t.status === 'active').length}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Total Bookings</div>
              <div className="text-xl font-black text-white mt-1">{myBookings.length}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Available Wallet</div>
              <div className="text-xl font-black text-[#C8FF5E] mt-1">৳{myWallet.availableBalance.toLocaleString()}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Held in Policy Window</div>
              <div className="text-xl font-black text-amber-400 mt-1">৳{myWallet.heldBalance.toLocaleString()}</div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Commission Rate</div>
              <div className="text-xl font-black text-emerald-400 mt-1">
                {profile?.commissionOverride || settings.globalCommissionRate}%
              </div>
            </div>
            <div className="bg-[#0e271a] p-3.5 rounded-2xl border border-white/10 hover:border-[#C8FF5E]/30 transition-all">
              <div className="text-[10px] text-white/50 font-medium uppercase">Staff Delegated</div>
              <div className="text-xl font-black text-white mt-1">{myStaff.length}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        {/* TAB 1: BOOKINGS & OPERATIONS */}
        {activeTab === 'bookings' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Booking Management & Check-ins</h2>
                <p className="text-xs text-white/60">View player contacts, record counter arrivals, and handle manual entries.</p>
              </div>

              {/* Action Button: Manual Booking */}
              <button
                onClick={() => setShowManualBookingModal(true)}
                className="px-4 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ New Manual / Counter Booking</span>
              </button>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-wrap gap-2 text-xs">
              <select
                value={bookingFilterTurf}
                onChange={(e) => setBookingFilterTurf(e.target.value)}
                className="bg-[#07130c] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C8FF5E] outline-none"
              >
                <option value="All">All Owned Turfs</option>
                {myTurfs.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>

              <select
                value={bookingFilterStatus}
                onChange={(e) => setBookingFilterStatus(e.target.value)}
                className="bg-[#07130c] border border-white/10 rounded-xl px-3 py-2 text-white focus:border-[#C8FF5E] outline-none"
              >
                <option value="All">All Statuses</option>
                <option value="confirmed">Confirmed</option>
                <option value="checked_in">Checked In</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="refunded">Refunded</option>
              </select>
            </div>

            {/* Table */}
            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-white/80">
                  <thead className="bg-[#0e271a] text-white/60 uppercase font-bold text-[10px] border-b border-white/10">
                    <tr>
                      <th className="py-3.5 px-4">Booking #</th>
                      <th className="py-3.5 px-4">Customer Contact</th>
                      <th className="py-3.5 px-4">Turf & Date</th>
                      <th className="py-3.5 px-4">Time Slot</th>
                      <th className="py-3.5 px-4">Source & Fee</th>
                      <th className="py-3.5 px-4">Net Owner Amount</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {filteredBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-white/[0.03] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{b.bookingNumber}</td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-white">{b.customerName}</div>
                          <div className="text-[11px] text-white/60 flex items-center gap-1">
                            <Phone className="w-3 h-3 text-[#C8FF5E]" /> {b.customerPhone}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-white font-medium">{b.turfName}</div>
                          <div className="text-[11px] text-white/60">{b.date}</div>
                        </td>
                        <td className="py-3 px-4 font-semibold text-white">
                          {b.startTime} - {b.endTime}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                              b.bookingSource === 'online'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/30'
                                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {b.bookingSource}
                          </span>
                          <div className="text-[10px] text-white/50 mt-0.5">
                            {b.hasGatewayFee ? 'SSLCommerz (2.5% fee)' : 'Manual (0 TK Gateway)'}
                          </div>
                        </td>
                        <td className="py-3 px-4 font-black text-[#C8FF5E] text-sm">৳{b.netOwnerAmount.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                              b.status === 'confirmed'
                                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                                : b.status === 'checked_in'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : b.status === 'completed'
                                ? 'bg-white/10 text-white/80 border-white/15'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {b.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                          {b.status === 'confirmed' && (
                            <button
                              onClick={() => checkInBooking(b.id)}
                              className="px-2.5 py-1 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-[11px] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer"
                            >
                              Check In
                            </button>
                          )}
                          {b.status === 'checked_in' && (
                            <button
                              onClick={() => completeBooking(b.id)}
                              className="px-2.5 py-1 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] text-[11px] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 transition-all cursor-pointer"
                            >
                              Complete Match
                            </button>
                          )}
                          {(b.status === 'confirmed' || b.status === 'checked_in') && (
                            <button
                              onClick={() => {
                                if (confirm('Owner-initiated cancellation triggers a 100% refund to player per platform rules. Proceed?')) {
                                  cancelBooking(b.id, 'Owner initiated cancellation due to ground unavailability', true);
                                }
                              }}
                              className="px-2 py-1 bg-rose-950/40 text-rose-300 hover:bg-rose-900/60 text-[11px] font-semibold rounded-xl border border-rose-800/40 transition-colors cursor-pointer"
                              title="Cancel Match (100% refund)"
                            >
                              Cancel
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredBookings.length === 0 && (
                      <tr>
                        <td colSpan={8} className="text-center py-8 text-white/50 text-xs">
                          No bookings found for the selected filter.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MY TURFS */}
        {activeTab === 'turfs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Your Listed Turfs</h2>
                <p className="text-xs text-white/60">Newly added turfs enter pending review status until admin approval.</p>
              </div>
              <button
                onClick={openAddTurfModal}
                className="px-4 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4" /> Add New Turf
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myTurfs.map((turf) => (
                <div key={turf.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
                  <div className="relative h-44 bg-[#07130c]">
                    <img src={turf.photos[0]} alt={turf.name} className="w-full h-full object-cover" />
                    <span
                      className={`absolute top-3 left-3 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider border ${
                        turf.status === 'active'
                          ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                          : turf.status === 'pending_review'
                          ? 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                          : 'bg-rose-950/80 text-rose-300 border-rose-800/40'
                      }`}
                    >
                      {turf.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-base text-white">{turf.name}</h3>
                      <p className="text-xs text-white/60 mt-1">{turf.address}</p>

                      <div className="flex flex-wrap gap-1 mt-3">
                        {turf.sportTypes.map((s) => (
                          <span key={s} className="text-[10px] bg-[#07130c] border border-white/10 px-2 py-0.5 rounded-full text-white/70">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-3 flex items-center gap-1.5 text-[11px] text-white/50">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Cancel cutoff: {turf.cancellationCutoffHours ?? 3}h before start</span>
                    </div>

                    <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs flex-wrap gap-2">
                      <div>
                        <span className="text-white/60">Base Price:</span>{' '}
                        <span className="font-black text-[#C8FF5E]">৳{turf.basePricePerHour}/hr</span>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <button
                          onClick={() => openEditTurfModal(turf)}
                          className="text-xs font-semibold px-2.5 py-1 rounded-xl border border-white/15 text-white/70 hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
                        >
                          Edit
                        </button>

                        <button
                          onClick={() => {
                            setDeleteTurfError('');
                            setTurfPendingDelete(turf);
                          }}
                          className="text-xs font-semibold px-2.5 py-1 rounded-xl border border-rose-500/40 text-rose-300 hover:bg-rose-500/10 transition-colors cursor-pointer"
                        >
                          Delete
                        </button>

                        <button
                          onClick={() => {
                            setSelectedTurfForAddonsId(turf.id);
                            setShowAddonsModal(true);
                          }}
                          className="text-xs font-semibold px-2.5 py-1 rounded-xl border border-[#C8FF5E]/40 text-[#C8FF5E] hover:bg-[#C8FF5E]/10 transition-colors cursor-pointer"
                        >
                          Add-ons
                        </button>

                        <button
                          onClick={() => {
                            const nextStatus = turf.status === 'active' ? 'inactive' : 'active';
                            updateTurf(turf.id, { status: nextStatus });
                          }}
                          className={`text-xs font-semibold px-2.5 py-1 rounded-xl border transition-colors cursor-pointer ${
                            turf.status === 'active'
                              ? 'border-white/15 text-white/60 hover:text-white hover:bg-white/[0.05]'
                              : 'border-[#C8FF5E] text-[#C8FF5E] hover:bg-[#C8FF5E]/10'
                          }`}
                        >
                          {turf.status === 'active' ? 'Deactivate' : 'Activate'}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: SLOTS & SCHEDULE MANAGEMENT */}
        {activeTab === 'slots' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Daily Slot Availability & Maintenance Blocking</h2>
                <p className="text-xs text-white/60">Click on any open slot to block it for maintenance or private club use.</p>
              </div>

              {/* Turf & Date Pickers */}
              <div className="flex gap-2 text-xs">
                <select
                  value={slotTurfId}
                  onChange={(e) => setSlotTurfId(e.target.value)}
                  className="bg-[#07130c] border border-white/10 rounded-xl px-3 py-1.5 text-white focus:border-[#C8FF5E] outline-none"
                >
                  {myTurfs.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>

                <input
                  type="date"
                  value={slotDate}
                  onChange={(e) => setSlotDate(e.target.value)}
                  className="bg-[#07130c] border border-white/10 rounded-xl px-3 py-1.5 text-white focus:border-[#C8FF5E] outline-none"
                />
              </div>
            </div>

            {/* Slot Matrix */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
              {slots
                .filter((s) => s.turfId === slotTurfId && s.date === slotDate)
                .map((slot) => {
                  const isAvailable = slot.status === 'available';
                  const isBlocked = slot.status === 'blocked';
                  const isBooked = slot.status === 'booked';

                  return (
                    <div
                      key={slot.id}
                      className={`p-3.5 rounded-2xl border flex flex-col justify-between transition-all ${
                        isAvailable
                          ? 'bg-[#0A1E14] border-white/10 text-white'
                          : isBlocked
                          ? 'bg-rose-950/20 border-rose-900/50 text-rose-300'
                          : 'bg-[#0e271a]/50 border-white/10 text-white/50'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold">
                          {slot.startTime} - {slot.endTime}
                        </div>
                        <div className="text-[11px] text-[#C8FF5E] font-bold mt-1">৳{slot.price}</div>
                        <span
                          className={`text-[9px] font-bold uppercase tracking-wider mt-2 inline-block px-2 py-0.5 rounded-full border ${
                            isAvailable
                              ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                              : isBlocked
                              ? 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                              : 'bg-white/10 text-white/50 border-white/10'
                          }`}
                        >
                          {slot.status}
                        </span>
                      </div>

                      <div className="mt-3 pt-2 border-t border-white/10">
                        {isBooked ? (
                          <span className="text-[10px] text-white/40">Reserved (Player)</span>
                        ) : (
                          <button
                            onClick={() => toggleSlotBlock(slot.id)}
                            className={`w-full py-1 text-[10px] font-bold rounded-xl flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                              isBlocked
                                ? 'bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40 hover:bg-[#C8FF5E]/20'
                                : 'bg-rose-950/50 text-rose-300 border border-rose-800/40 hover:bg-rose-900/60'
                            }`}
                          >
                            {isBlocked ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                            <span>{isBlocked ? 'Unblock' : 'Block Slot'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>

            {slots.filter((s) => s.turfId === slotTurfId && s.date === slotDate).length === 0 && (
              <div className="p-8 text-center bg-[#0A1E14] border border-white/10 rounded-2xl text-white/60 text-xs">
                No slots configured for this date.
                <button
                  onClick={() => addSlot(slotTurfId, slotDate, '18:00', '19:00', 1200)}
                  className="ml-2 text-[#C8FF5E] font-bold hover:underline"
                >
                  Generate 18:00 Slot
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: STAFF MANAGEMENT */}
        {activeTab === 'staff' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Delegated Staff Accounts (Section 8)</h2>
                <p className="text-xs text-white/60">
                  Staff accounts have operational rights on assigned turfs. They CANNOT see earnings, wallets or request withdrawals.
                </p>
              </div>
              <button
                onClick={() => setShowAddStaffModal(true)}
                className="px-4 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <Plus className="w-4 h-4" /> Add Staff Member
              </button>
            </div>

            {pendingSetupStaffCount > 0 && (
            <div className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-300/80">Account Setup</p>
                  <h3 className="mt-1 text-sm font-bold text-white">
                    {pendingSetupStaffCount} staff account{pendingSetupStaffCount > 1 ? 's are' : ' is'} waiting for setup
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowStaffSetupPreview(myStaff.find((staff) => staff.status === 'pending_setup') || null)}
                  className="px-3 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold text-[11px] rounded-xl cursor-pointer transition-colors"
                >
                  Review Invite
                </button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myStaff.map((staff) => (
                <div key={staff.id} className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-white text-base">{staff.staffName}</h4>
                      <p className="text-xs text-white/60">{staff.staffEmail} • {staff.staffPhone}</p>
                    </div>
                    <span
                      className={`text-[10px] uppercase tracking-wider font-bold px-2.5 py-0.5 rounded-full border ${
                        staff.status === 'pending_setup'
                          ? 'bg-amber-500/10 text-amber-300 border-amber-400/30'
                          : 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                      }`}
                    >
                      {staff.status === 'pending_setup' ? 'Pending setup' : 'Staff scoped'}
                    </span>
                  </div>

                  <div>
                    <div className="text-[10px] text-white/60 font-bold uppercase mb-1">Assigned Turf(s):</div>
                    <div className="flex flex-wrap gap-1">
                      {staff.turfIds.map((tid) => {
                        const t = turfs.find((x) => x.id === tid);
                        return (
                          <span key={tid} className="text-[11px] bg-[#07130c] text-white/80 px-2.5 py-0.5 rounded-full border border-white/10">
                            {t?.name || tid}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                    <div className="text-[10px] text-white/60">
                      {staff.status === 'pending_setup' ? (
                        <>
                          Invite sent{' '}
                          {staff.invitedAt ? formatBDDate(staff.invitedAt) : 'recently'}
                        </>
                      ) : (
                        'Account active'
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowStaffSetupPreview(staff)}
                      className="px-2.5 py-1.5 rounded-lg border border-white/10 bg-white/[0.03] text-[10px] font-bold text-white/80 hover:bg-white/[0.08] cursor-pointer transition-colors"
                    >
                      View setup screen
                    </button>
                  </div>

                  <div>
                    <div className="text-[10px] text-white/60 font-bold uppercase mb-1">Assigned Permissions:</div>
                    <div className="flex flex-wrap gap-1">
                      {staff.permissions.map((perm) => (
                        <span key={perm} className="text-[10px] bg-[#0e271a] text-[#C8FF5E] px-2 py-0.5 rounded-full border border-[#C8FF5E]/30">
                          {perm.replace('bookings.', '').replace('slots.', '')}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}

              {myStaff.length === 0 && (
                <div className="col-span-full text-center py-12 bg-[#0A1E14] border border-white/10 rounded-2xl text-white/50 text-xs">
                  No staff members created yet. Delegate check-ins and counter bookings to your team members!
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 5: WALLET & WITHDRAWALS */}
        {activeTab === 'wallet' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h2 className="text-base font-bold text-white">Owner Wallet & Payouts (Section 11)</h2>
                <p className="text-xs text-white/60">Available earnings are net of platform commission. Minimum withdrawal: ৳{settings.minWithdrawalAmount}.</p>
              </div>

              <button
                disabled={myWallet.availableBalance < settings.minWithdrawalAmount}
                onClick={() => setShowWithdrawModal(true)}
                className="px-4 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] disabled:opacity-40 text-[#0A1E14] font-bold text-xs rounded-xl shadow-md shadow-[#C8FF5E]/20 flex items-center gap-1.5 cursor-pointer transition-all"
              >
                <DollarSign className="w-4 h-4" /> Request Payout
              </button>
            </div>

            {/* Balance Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="text-xs text-white/60">Ready for Withdrawal</div>
                <div className="text-2xl font-black text-[#C8FF5E] mt-1">
                  ৳{myWallet.availableBalance.toLocaleString()}
                </div>
                <p className="text-[11px] text-white/50 mt-1">From matches past cancellation window</p>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="text-xs text-white/60">Held in Active Policy Window</div>
                <div className="text-2xl font-black text-amber-400 mt-1">
                  ৳{myWallet.heldBalance.toLocaleString()}
                </div>
                <p className="text-[11px] text-white/50 mt-1">Held until match end / window expiry</p>
              </div>

              <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg">
                <div className="text-xs text-white/60">Total Paid Out to Date</div>
                <div className="text-2xl font-black text-white mt-1">
                  ৳{myWallet.totalWithdrawn.toLocaleString()}
                </div>
                <p className="text-[11px] text-white/50 mt-1">Approved & transferred payouts</p>
              </div>
            </div>

            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                <div>
                  <h3 className="text-base font-bold text-white">Payout Details</h3>
                  <p className="text-[11px] text-white/60 mt-1">
                    Approved withdrawal requests are transferred to this account via online payment.
                  </p>
                </div>
                {!isEditingPayout && (
                  <button
                    type="button"
                    onClick={openEditPayoutForm}
                    className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-[#C8FF5E]/40 text-[#C8FF5E] hover:bg-[#C8FF5E]/10 transition-colors cursor-pointer"
                  >
                    {profile?.payoutDetails.accountNumber ? 'Edit' : 'Add Payout Info'}
                  </button>
                )}
              </div>

              {!isEditingPayout ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <div className="text-white/60">Method</div>
                    <div className="mt-1 font-bold text-white uppercase">{profile?.payoutMethod?.replace('_', ' ') || 'Not set'}</div>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <div className="text-white/60">Account / Wallet Number</div>
                    <div className="mt-1 font-bold text-white">{profile?.payoutDetails.accountNumber || 'Not set'}</div>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    <div className="text-white/60">Bank / Holder</div>
                    <div className="mt-1 font-bold text-white">
                      {profile?.payoutDetails.bankName
                        ? `${profile.payoutDetails.bankName}${profile.payoutDetails.branchName ? ` (${profile.payoutDetails.branchName})` : ''}`
                        : profile?.payoutDetails.accountHolderName || '—'}
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSavePayoutDetails} className="space-y-3 text-xs">
                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Payout Method:</label>
                    <select
                      value={payoutFormMethod}
                      onChange={(e) => setPayoutFormMethod(e.target.value as typeof payoutFormMethod)}
                      className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                    >
                      <option value="bkash">bKash</option>
                      <option value="nagad">Nagad</option>
                      <option value="rocket">Rocket</option>
                      <option value="bank_account">Bank Account</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">
                      {payoutFormMethod === 'bank_account' ? 'Bank Account Number:' : 'Wallet Number:'}
                    </label>
                    <input
                      type="text"
                      value={payoutFormAccountNumber}
                      onChange={(e) => setPayoutFormAccountNumber(e.target.value)}
                      placeholder={payoutFormMethod === 'bank_account' ? 'e.g. 20501234567890' : 'e.g. 01819-223344'}
                      className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Account Holder Name:</label>
                    <input
                      type="text"
                      value={payoutFormAccountHolder}
                      onChange={(e) => setPayoutFormAccountHolder(e.target.value)}
                      placeholder="Full name as registered"
                      className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                    />
                  </div>

                  {payoutFormMethod === 'bank_account' && (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-white/80 font-semibold mb-1 block">Bank Name:</label>
                        <input
                          type="text"
                          value={payoutFormBankName}
                          onChange={(e) => setPayoutFormBankName(e.target.value)}
                          className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-white/80 font-semibold mb-1 block">Branch Name:</label>
                        <input
                          type="text"
                          value={payoutFormBranchName}
                          onChange={(e) => setPayoutFormBranchName(e.target.value)}
                          className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                        />
                      </div>
                    </div>
                  )}

                  {payoutFormMessage && (
                    <div className="p-2.5 rounded-xl border border-[#C8FF5E]/30 bg-[#C8FF5E]/10 text-[11px] text-[#C8FF5E]">
                      {payoutFormMessage}
                    </div>
                  )}

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsEditingPayout(false)}
                      className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                    >
                      Save Payout Details
                    </button>
                  </div>
                </form>
              )}
            </div>

            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
                <div>
                  <h3 className="text-base font-bold text-white">Featured Turf Listing (Section 52)</h3>
                  <p className="text-[11px] text-white/60 mt-1">
                    Global flag: {settings.featureFlags?.featured_turf_enabled ? 'Enabled' : 'Disabled'}
                  </p>
                </div>
                <div className="rounded-full border border-[#C8FF5E]/40 bg-[#C8FF5E]/10 px-2.5 py-1 text-[10px] font-bold text-[#C8FF5E] uppercase">
                  Demo Credits: ৳{demoPlatformCredits.toLocaleString()}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(settings.featuredPackages || []).map((pkg) => (
                  <button
                    key={pkg.id}
                    type="button"
                    onClick={() => setSelectedFeaturedPackageId(pkg.id)}
                    className={`rounded-xl border p-3 text-left transition-all cursor-pointer ${
                      selectedFeaturedPackage?.id === pkg.id
                        ? 'border-[#C8FF5E]/50 bg-[#C8FF5E]/10 shadow-md shadow-[#C8FF5E]/10'
                        : 'border-white/10 bg-[#07130c] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-white">{pkg.name}</span>
                      <span className="text-[10px] font-bold text-[#C8FF5E]">Priority {pkg.priority}</span>
                    </div>

                    <div className="mt-2 text-xl font-black text-[#C8FF5E]">৳{pkg.price.toLocaleString()}</div>
                    <div className="mt-1 text-[11px] text-white/60">{pkg.durationDays} days • {pkg.description}</div>
                  </button>
                ))}
              </div>

              {selectedFeaturedPackage && (
                <div className="rounded-xl border border-white/10 bg-[#07130c] p-4 space-y-3">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                    <div>
                      <div className="text-[11px] text-white/60 uppercase tracking-wider font-bold">Selected package</div>
                      <div className="text-sm font-bold text-white mt-1">{selectedFeaturedPackage.name}</div>
                    </div>

                    <div className="text-right">
                      <div className="text-[11px] text-white/60 uppercase tracking-wider font-bold">Cost split</div>
                      <div className="text-sm font-bold text-[#C8FF5E] mt-1">
                        ৳{selectedFeaturedPackage.price.toLocaleString()} total
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="text-white/60">Platform credit available</div>
                      <div className="mt-1 font-bold text-[#C8FF5E]">৳{demoPlatformCredits.toLocaleString()}</div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="text-white/60">Cash portion</div>
                      <div className="mt-1 font-bold text-white">৳{Math.max(selectedFeaturedPackage.price - demoPlatformCredits, 0).toLocaleString()}</div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                      <div className="text-white/60">Payment flow</div>
                      <div className="mt-1 font-bold text-amber-300">SSLCommerz sandbox</div>
                    </div>
                  </div>

                  <button
                    type="button"
                    className="w-full py-2.5 rounded-xl bg-[#C8FF5E] hover:bg-[#A8FF5E] text-[#0A1E14] font-bold text-xs shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                  >
                    Purchase Featured Listing
                  </button>
                </div>
              )}
            </div>

            {/* Withdrawal Requests Table */}
            <div className="bg-[#0A1E14] border border-white/10 rounded-2xl overflow-hidden shadow-lg">
              <div className="p-4 border-b border-white/10">
                <h3 className="text-sm font-bold text-white">Payout History & Requests</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-white/80">
                  <thead className="bg-[#0e271a] text-white/60 uppercase font-bold text-[10px] border-b border-white/10">
                    <tr>
                      <th className="py-3 px-4">Request ID</th>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Method & Account</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Admin Reference / Note</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {myWithdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-white/[0.03] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{w.id}</td>
                        <td className="py-3 px-4 font-black text-[#C8FF5E] text-sm">৳{w.amount.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <div className="text-white font-medium">{w.payoutMethod}</div>
                          <div className="text-[11px] text-white/60">{w.payoutDetails}</div>
                        </td>
                        <td className="py-3 px-4 text-white/60">{formatBDDate(w.createdAt)}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${
                              w.status === 'paid'
                                ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                                : w.status === 'pending'
                                ? 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                                : 'bg-rose-950/40 text-rose-300 border-rose-800/40'
                            }`}
                          >
                            {w.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-white/60">
                          {w.reference || w.rejectionReason || 'Under review'}
                        </td>
                      </tr>
                    ))}
                    {myWithdrawals.length === 0 && (
                      <tr>
                        <td colSpan={6} className="text-center py-6 text-white/50 text-xs">
                          No payout requests yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: TOURNAMENTS (SECTION 50)                                           */}
        {/* ========================================================================= */}
        {activeTab === 'tournaments' && (
          <div className="mt-6">
            <TournamentsView />
          </div>
        )}
      </div>

      {/* MODAL 1: MANUAL / OFFLINE BOOKING (SECTION 7.4) */}
      {isManualModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-[#C8FF5E]" /> New Manual / Offline Booking (Section 7.4)
                </h3>
                <p className="text-[11px] text-white/60">Direct booking at counter or phone. 0 TK Gateway fee!</p>
              </div>
              <button onClick={closeManualModal} className="text-white/60 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleManualBookingSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Select Turf:</label>
                <select
                  value={mbTurfId}
                  onChange={(e) => {
                    setMbTurfId(e.target.value);
                    setMbSlotId('');
                  }}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  required
                >
                  {myTurfs.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} (৳{t.basePricePerHour}/hr)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Select Open Slot:</label>
                <select
                  value={mbSlotId}
                  onChange={(e) => setMbSlotId(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  required
                >
                  <option value="">-- Choose Slot --</option>
                  {availableSlotsForManual.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.date} | {s.startTime} - {s.endTime} (৳{s.price})
                    </option>
                  ))}
                </select>
                {availableSlotsForManual.length === 0 && (
                  <p className="text-[11px] text-amber-300 mt-1">No available slots for this turf. Generate slots first.</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Customer Name:</label>
                  <input
                    type="text"
                    value={mbCustomerName}
                    onChange={(e) => setMbCustomerName(e.target.value)}
                    placeholder="e.g. Captain Nayeem"
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                    required
                  />
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Customer Phone:</label>
                  <input
                    type="tel"
                    value={mbCustomerPhone}
                    onChange={(e) => setMbCustomerPhone(e.target.value)}
                    placeholder="e.g. +880 1711-223344"
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Payment Method:</label>
                  <select
                    value={mbPaymentMethod}
                    onChange={(e) => setMbPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="cash">Cash (In-person)</option>
                    <option value="bkash">bKash (Direct/Manual)</option>
                    <option value="nagad">Nagad (Direct/Manual)</option>
                    <option value="rocket">Rocket (Direct/Manual)</option>
                    <option value="bank_transfer">Bank Transfer</option>
                  </select>
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Payment Status:</label>
                  <select
                    value={mbPaymentStatus}
                    onChange={(e) => setMbPaymentStatus(e.target.value as PaymentStatus)}
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="paid">Paid Full</option>
                    <option value="pending">Pending Collection</option>
                    <option value="partial">Partial Advance</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Payment Ref / Receipt # (optional):</label>
                <input
                  type="text"
                  value={mbReference}
                  onChange={(e) => setMbReference(e.target.value)}
                  placeholder="e.g. CASH-REC-2041 or bKash TrxID"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Notes (optional):</label>
                <input
                  type="text"
                  value={mbNotes}
                  onChange={(e) => setMbNotes(e.target.value)}
                  placeholder="e.g. Needs referee + bibs"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                />
              </div>

              {/* Fee Notice */}
              <div className="p-3 bg-[#0e271a] border border-[#C8FF5E]/30 rounded-xl text-[11px] text-[#C8FF5E]">
                <strong>Pricing Rules (Section 10.2):</strong> Manual bookings do NOT use SSLCommerz, so{' '}
                <strong>Gateway Fee is 0 TK</strong>. Platform fee (5%) still applies.
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowManualBookingModal(false)}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!mbSlotId}
                  className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] disabled:opacity-40 text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                >
                  Confirm Manual Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD TURF */}
      {showAddTurfModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-sm text-white">{editingTurfId ? 'Edit Turf Details' : 'Add New Sports Ground / Turf'}</h3>
              <button
                onClick={() => {
                  setShowAddTurfModal(false);
                  setEditingTurfId(null);
                }}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddTurfSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Turf Name:</label>
                <input
                  type="text"
                  value={newTurfName}
                  onChange={(e) => setNewTurfName(e.target.value)}
                  placeholder="e.g. Uttara Kickoff Arena"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Address / Location:</label>
                <input
                  type="text"
                  value={newTurfAddress}
                  onChange={(e) => setNewTurfAddress(e.target.value)}
                  placeholder="e.g. Sector 7, Uttara, Dhaka"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Area:</label>
                  <select
                    value={newTurfArea}
                    onChange={(e) => setNewTurfArea(e.target.value)}
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                  >
                    <option value="Banani">Banani</option>
                    <option value="Gulshan">Gulshan</option>
                    <option value="Dhanmondi">Dhanmondi</option>
                    <option value="Uttara">Uttara</option>
                    <option value="Mirpur">Mirpur</option>
                  </select>
                </div>
                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Hourly Base Price (BDT):</label>
                  <input
                    type="number"
                    value={newTurfPrice}
                    onChange={(e) => setNewTurfPrice(Number(e.target.value))}
                    className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none font-bold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Sports Supported:</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {turfSportOptions.map((sport) => {
                    const selected = newTurfSports.includes(sport);
                    return (
                      <button
                        key={sport}
                        type="button"
                        onClick={() =>
                          setNewTurfSports((prev) =>
                            selected ? prev.filter((item) => item !== sport) : [...prev, sport]
                          )
                        }
                        className={`px-2.5 py-1.5 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                          selected
                            ? 'bg-[#C8FF5E] text-[#0A1E14] border-[#C8FF5E]'
                            : 'bg-[#07130c] text-white/70 border-white/10 hover:text-white'
                        }`}
                      >
                        {sport}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Amenities:</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {turfAmenityOptions.map((amenity) => {
                    const selected = newTurfAmenities.includes(amenity);
                    return (
                      <button
                        key={amenity}
                        type="button"
                        onClick={() =>
                          setNewTurfAmenities((prev) =>
                            selected ? prev.filter((item) => item !== amenity) : [...prev, amenity]
                          )
                        }
                        className={`px-2.5 py-1.5 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${
                          selected
                            ? 'bg-[#0e271a] text-[#C8FF5E] border-[#C8FF5E]/40'
                            : 'bg-[#07130c] text-white/70 border-white/10 hover:text-white'
                        }`}
                      >
                        {amenity}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Description:</label>
                <textarea
                  value={newTurfDesc}
                  onChange={(e) => setNewTurfDesc(e.target.value)}
                  placeholder="Pitch specifications, lighting quality, locker rooms..."
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  rows={2}
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Cancellation Cutoff (hours before slot start):</label>
                <input
                  type="number"
                  min={0}
                  max={72}
                  value={newTurfCancellationHours}
                  onChange={(e) => setNewTurfCancellationHours(Number(e.target.value))}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none font-bold"
                  required
                />
                <p className="text-[10px] text-white/50 mt-1">
                  Players cannot cancel a booking once fewer than this many hours remain before the slot starts.
                </p>
              </div>

              <div className="p-3 bg-amber-950/40 border border-amber-500/40 rounded-xl text-[11px] text-amber-300">
                {editingTurfId ? (
                  <>Updating core details keeps the turf's current approval status unchanged.</>
                ) : (
                  <>
                    New listings are submitted with <strong>pending_review</strong> status for Admin quality check before going live.
                  </>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddTurfModal(false);
                    setEditingTurfId(null);
                  }}
                  className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                >
                  {editingTurfId ? 'Save Changes' : 'Submit for Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: DELETE TURF CONFIRMATION */}
      {turfPendingDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-sm rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-500/15 border border-rose-500/40 flex items-center justify-center text-rose-300">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">Delete "{turfPendingDelete.name}"?</h3>
                <p className="text-[11px] text-white/60">This action cannot be undone.</p>
              </div>
            </div>

            {deleteTurfError && (
              <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded-xl text-[11px] text-rose-300">
                {deleteTurfError}
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setTurfPendingDelete(null);
                  setDeleteTurfError('');
                }}
                className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteTurf}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl shadow-md cursor-pointer transition-all text-xs"
              >
                Delete Turf
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: TURF ADD-ONS (PROTOYPE UI) */}
      {showAddonsModal && selectedTurfForAddons && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-3xl rounded-2xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#C8FF5E]">Add-on Manager</p>
                <h3 className="mt-1 font-bold text-sm text-white">Manage Add-ons for {selectedTurfForAddons.name}</h3>
              </div>
              <button
                onClick={() => {
                  setShowAddonsModal(false);
                  setSelectedTurfForAddonsId(null);
                  setAddonName('');
                  setAddonDescription('');
                  setAddonCategory('equipment');
                  setAddonPrice(120);
                  setAddonStock(null);
                }}
                className="text-white/60 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-4">
              <div className="space-y-3">
                <div className="rounded-2xl border border-white/10 bg-[#07130c] p-4">
                  <h4 className="text-[11px] font-bold uppercase tracking-[0.18em] text-white/60 mb-3">Existing Add-ons</h4>

                  {(selectedTurfForAddons.addons || []).length === 0 ? (
                    <p className="text-xs text-white/50">No add-ons configured for this turf yet.</p>
                  ) : (
                    <div className="space-y-2">
                      {(selectedTurfForAddons.addons || []).map((addon) => (
                        <div key={addon.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-bold text-white">{addon.name}</span>
                                <span className="text-[10px] font-bold uppercase tracking-[0.12em] bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40 rounded-full px-2 py-0.5">
                                  {addon.category}
                                </span>
                              </div>
                              {addon.description && <p className="text-[11px] text-white/60 mt-1">{addon.description}</p>}
                              <div className="mt-2 text-[11px] text-white/70 flex flex-wrap gap-2">
                                <span className="font-bold text-[#C8FF5E]">৳{addon.price}</span>
                                <span>•</span>
                                <span>{addon.stockQuantity === null ? 'Unlimited stock' : `${addon.stockQuantity} in stock`}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => handleAddonToggle(addon.id)}
                                className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                                  addon.isActive
                                    ? 'border-[#C8FF5E]/40 bg-[#C8FF5E]/10 text-[#C8FF5E]'
                                    : 'border-white/10 bg-white/[0.03] text-white/60'
                                }`}
                              >
                                {addon.isActive ? 'Active' : 'Inactive'}
                              </button>

                              <button
                                type="button"
                                onClick={() => handleAddonDelete(addon.id)}
                                className="px-2 py-1 rounded-lg text-[10px] font-bold border border-rose-800/40 bg-rose-950/30 text-rose-300 hover:bg-rose-900/40 cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <form onSubmit={handleAddAddonSubmit} className="space-y-3 text-xs rounded-2xl border border-white/10 bg-[#07130c] p-4">
                <h4 className="text-[11px] font-bold uppercase tracking-[0.18em] text-white/60">Add New Add-on</h4>

                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Add-on Name</label>
                  <input
                    type="text"
                    value={addonName}
                    onChange={(e) => setAddonName(e.target.value)}
                    placeholder="e.g. Bibs Set"
                    className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                    required
                  />
                </div>

                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Description</label>
                  <textarea
                    value={addonDescription}
                    onChange={(e) => setAddonDescription(e.target.value)}
                    placeholder="Optional short description"
                    rows={2}
                    className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Category</label>
                    <select
                      value={addonCategory}
                      onChange={(e) => setAddonCategory(e.target.value as 'equipment' | 'service' | 'food' | 'other')}
                      className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                    >
                      <option value="equipment">Equipment</option>
                      <option value="service">Service</option>
                      <option value="food">Food</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-white/80 font-semibold mb-1 block">Price (BDT)</label>
                    <input
                      type="number"
                      min={0}
                      value={addonPrice}
                      onChange={(e) => setAddonPrice(Number(e.target.value))}
                      className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-white/80 font-semibold mb-1 block">Stock Quantity (optional)</label>
                  <input
                    type="number"
                    min={0}
                    value={addonStock ?? ''}
                    onChange={(e) => setAddonStock(e.target.value === '' ? null : Number(e.target.value))}
                    placeholder="Leave empty for unlimited"
                    className="w-full bg-[#0A1E14] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddonsModal(false);
                      setSelectedTurfForAddonsId(null);
                      setAddonName('');
                      setAddonDescription('');
                      setAddonCategory('equipment');
                      setAddonPrice(120);
                      setAddonStock(null);
                    }}
                    className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                  >
                    Save Add-on
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: ADD STAFF */}
      {showAddStaffModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-sm text-white">Create Operational Staff Account</h3>
              <button onClick={() => setShowAddStaffModal(false)} className="text-white/60 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateStaffSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Staff Full Name:</label>
                <input
                  type="text"
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="e.g. Rakibul Islam"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Email Address:</label>
                <input
                  type="email"
                  value={staffEmail}
                  onChange={(e) => setStaffEmail(e.target.value)}
                  placeholder="e.g. staff@greenpitch.com"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Phone Number:</label>
                <input
                  type="tel"
                  value={staffPhone}
                  onChange={(e) => setStaffPhone(e.target.value)}
                  placeholder="e.g. +880 1600-000000"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Assign to Turf:</label>
                <select
                  value={staffTurfIds[0] || ''}
                  onChange={(e) => setStaffTurfIds([e.target.value])}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                >
                  {myTurfs.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddStaffModal(false)}
                  className="flex-1 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                >
                  Create Staff Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: WITHDRAWAL REQUEST */}
      {showStaffSetupPreview && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-lg rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#C8FF5E]">Staff setup preview</p>
                <h3 className="mt-1 font-bold text-sm text-white">Account Setup Screen</h3>
              </div>
              <button onClick={() => setShowStaffSetupPreview(null)} className="text-white/60 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-2xl border border-[#C8FF5E]/25 bg-[#C8FF5E]/8 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-white/60">Invite recipient</p>
                  <h4 className="mt-1 text-lg font-black text-white">{showStaffSetupPreview.staffName}</h4>
                </div>
                <span className="rounded-full border border-[#C8FF5E]/30 bg-[#C8FF5E]/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[#C8FF5E]">
                  {showStaffSetupPreview.status === 'pending_setup' ? 'Pending setup' : 'Active'}
                </span>
              </div>

              <div className="mt-3 space-y-3 text-xs text-white/70">
                <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/10 px-3 py-2">
                  <span>Email</span>
                  <span className="font-semibold text-white">{showStaffSetupPreview.staffEmail}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/10 px-3 py-2">
                  <span>Phone</span>
                  <span className="font-semibold text-white">{showStaffSetupPreview.staffPhone}</span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-white/10 bg-black/10 px-3 py-2">
                  <span>Assigned turf</span>
                  <span className="font-semibold text-white">
                    {turfs.find((t) => t.id === showStaffSetupPreview.turfIds[0])?.name || 'Assigned turf'}
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-[#07130c] p-4">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/50">Setup steps</p>
              <ol className="mt-3 space-y-2 text-xs text-white/70 list-decimal list-inside">
                <li>Staff opens the invite link and lands on the account setup screen.</li>
                <li>They choose a password, confirm phone number, and complete verification.</li>
                <li>After setup, the dashboard is scoped only to the assigned turf(s).</li>
              </ol>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowStaffSetupPreview(null)}
                className="flex-1 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
              >
                Close
              </button>
              <button
                type="button"
                className="flex-1 py-2.5 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
              >
                Send Reminder
              </button>
            </div>
          </div>
        </div>
      )}

      {showWithdrawModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0A1E14] border border-white/10 w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-sm text-white">Request Earnings Payout</h3>
              <button onClick={() => setShowWithdrawModal(false)} className="text-white/60 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-[#07130c] border border-white/10 p-3.5 rounded-xl text-xs space-y-1">
              <div className="flex justify-between text-white/80">
                <span>Available Balance:</span>
                <span className="font-black text-[#C8FF5E]">৳{myWallet.availableBalance.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-white/50 text-[11px]">
                <span>Minimum Withdrawal:</span>
                <span>৳{settings.minWithdrawalAmount}</span>
              </div>
            </div>

            <form onSubmit={handleWithdrawalSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-white/80 font-semibold mb-1 block">Payout Amount (BDT):</label>
                <input
                  type="number"
                  min={settings.minWithdrawalAmount}
                  max={myWallet.availableBalance}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(Number(e.target.value))}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white font-bold focus:border-[#C8FF5E] outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Payout Method:</label>
                <select
                  value={withdrawMethod}
                  onChange={(e) => setWithdrawMethod(e.target.value)}
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none"
                >
                  <option value="bKash Merchant">bKash (Merchant / Personal)</option>
                  <option value="Nagad">Nagad</option>
                  <option value="Rocket">Rocket</option>
                  <option value="Bank Transfer">Bank Transfer (BRAC/City/EBL)</option>
                </select>
              </div>

              <div>
                <label className="text-white/80 font-semibold mb-1 block">Account Number & Name:</label>
                <input
                  type="text"
                  value={withdrawDetails}
                  onChange={(e) => setWithdrawDetails(e.target.value)}
                  placeholder="e.g. 01819223344 (Tanvir Ahmed)"
                  className="w-full bg-[#07130c] border border-white/10 rounded-xl p-2.5 text-white focus:border-[#C8FF5E] outline-none placeholder:text-white/30"
                  required
                />
              </div>

              {withdrawMsg && (
                <div className="p-2.5 bg-[#0e271a] text-[#C8FF5E] border border-[#C8FF5E]/40 rounded-xl text-xs font-semibold">
                  {withdrawMsg}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowWithdrawModal(false)}
                  className="flex-1 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl font-semibold cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-[#C8FF5E] hover:bg-[#A8E63E] text-[#0A1E14] font-bold rounded-xl shadow-md shadow-[#C8FF5E]/20 cursor-pointer transition-all"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
