import express from 'express';
import dotenv from 'dotenv';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';

dotenv.config();

const app = express();
const { Pool } = pg;

const PORT = Number(process.env.PORT || 5000);
const JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET || 'dev-access-secret-change-me';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev-refresh-secret-change-me';

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || 'postgres',
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || '',
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : false,
});

const normalizeTurf = (row) => ({
  id: row.id,
  ownerId: row.owner_id,
  ownerName: row.owner_name || '',
  name: row.name,
  description: row.description || '',
  address: row.address || '',
  area: row.area || '',
  city: row.city || '',
  latitude: Number(row.latitude || 0),
  longitude: Number(row.longitude || 0),
  sportTypes: Array.isArray(row.sport_types) ? row.sport_types : [],
  amenities: Array.isArray(row.amenities) ? row.amenities : [],
  basePricePerHour: Number(row.base_price_per_hour || 0),
  pricingRules: Array.isArray(row.pricing_rules) ? row.pricing_rules : [],
  operatingHours: row.operating_hours || { openTime: '07:00', closeTime: '23:00' },
  photos: Array.isArray(row.photos)
    ? row.photos.map((photo) => (typeof photo === 'string' ? photo : photo.url)).filter(Boolean)
    : [],
  status: row.status || 'active',
  rating: Number(row.rating || 0),
  reviewCount: Number(row.review_count || 0),
  createdAt: row.created_at || new Date().toISOString(),
  cancellationPolicyId: row.cancellation_policy_id || undefined,
});

const sanitizeUser = (row) => ({
  id: row.id,
  name: row.name,
  email: row.email,
  phone: row.phone,
  role: row.role,
  status: row.status,
  avatar: row.avatar,
  createdAt: row.created_at,
});

const createAuthTokens = (user) => ({
  accessToken: jwt.sign(
    { sub: user.id, role: user.role, email: user.email, status: user.status },
    JWT_ACCESS_SECRET,
    { expiresIn: '15m' }
  ),
  refreshToken: jwt.sign(
    { sub: user.id, tokenType: 'refresh' },
    JWT_REFRESH_SECRET,
    { expiresIn: '30d' }
  ),
});

const requireAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ success: false, message: 'Missing bearer token.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_ACCESS_SECRET);
    const userResult = await pool.query('SELECT * FROM users WHERE id = $1 LIMIT 1', [decoded.sub]);

    if (userResult.rowCount === 0) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    const user = userResult.rows[0];

    if (user.status === 'suspended' || user.status === 'deactivated') {
      return res.status(403).json({ success: false, message: 'Account is not active.' });
    }

    req.user = sanitizeUser(user);
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Invalid or expired access token.', error: error.message });
  }
};

const validateRegistrationBody = (body, type) => {
  const name = String(body.name || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const phone = String(body.phone || '').trim();
  const password = String(body.password || '');

  if (!name || !email || !phone || !password) {
    return { valid: false, message: 'Name, email, phone and password are required.' };
  }

  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long.' };
  }

  if (type === 'turf_owner') {
    if (!String(body.businessName || '').trim()) {
      return { valid: false, message: 'Business name is required for turf owners.' };
    }
  }

  return { valid: true, data: { name, email, phone, password } };
};

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // SSLCommerz callbacks post as form-encoded

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.get('/api/health', async (req, res) => {
  try {
    const result = await pool.query('SELECT 1 AS ok');
    res.json({
      success: true,
      message: 'Server healthy',
      db: result.rows[0]?.ok === 1,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Database connection failed',
      error: error.message,
    });
  }
});

app.get('/api/test-db', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW() AS now, current_database() AS database_name, current_user AS current_user');
    res.json({
      success: true,
      message: 'Connected to PostgreSQL successfully',
      data: result.rows[0],
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to connect to PostgreSQL',
      error: error.message,
    });
  }
});

app.post('/api/auth/register/player', async (req, res) => {
  const validation = validateRegistrationBody(req.body, 'player');

  if (!validation.valid) {
    return res.status(400).json({ success: false, message: validation.message });
  }

  const { name, email, phone, password } = validation.data;

  try {
    const existingUser = await pool.query('SELECT id FROM users WHERE email = $1 LIMIT 1', [email]);

    if (existingUser.rowCount > 0) {
      return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const insertUser = await pool.query(
      `
        INSERT INTO users (name, email, phone, password_hash, role, status)
        VALUES ($1, $2, $3, $4, 'player', 'active')
        RETURNING *
      `,
      [name, email, phone, passwordHash]
    );

    const user = insertUser.rows[0];

    res.status(201).json({
      success: true,
      message: 'Player registration successful.',
      data: {
        user: sanitizeUser(user),
        ...createAuthTokens(user),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Unable to register player.', error: error.message });
  }
});

app.post('/api/auth/register/turf-owner', async (req, res) => {
  const validation = validateRegistrationBody(req.body, 'turf_owner');

  if (!validation.valid) {
    return res.status(400).json({ success: false, message: validation.message });
  }

  const { name, email, phone, password } = validation.data;
  const businessName = String(req.body.businessName || '').trim();
  const nidOrTradeLicense = String(req.body.nidOrTradeLicense || '').trim();
  const payoutMethod = String(req.body.payoutMethod || 'bkash');
  const accountNumber = String(req.body.accountNumber || '').trim();

  try {
    const existingUser = await pool.query('SELECT id FROM users WHERE email = $1 LIMIT 1', [email]);

    if (existingUser.rowCount > 0) {
      return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      const insertUser = await client.query(
        `
          INSERT INTO users (name, email, phone, password_hash, role, status)
          VALUES ($1, $2, $3, $4, 'turf_owner', 'pending_approval')
          RETURNING *
        `,
        [name, email, phone, passwordHash]
      );

      const user = insertUser.rows[0];

      await client.query(
        `
          INSERT INTO turf_owner_profiles (
            user_id,
            business_name,
            payout_method,
            payout_details,
            approval_status
          )
          VALUES ($1, $2, $3, $4, 'pending_approval')
        `,
        [
          user.id,
          businessName,
          payoutMethod,
          {
            accountNumber: accountNumber || phone,
            accountHolderName: name,
            bankName: req.body.bankName || null,
            branchName: req.body.branchName || null,
            nidOrTradeLicense: nidOrTradeLicense || null,
          },
        ]
      );

      await client.query('INSERT INTO wallets (owner_id, available_balance, updated_at) VALUES ($1, 0, NOW())', [user.id]);
      await client.query('COMMIT');

      res.status(201).json({
        success: true,
        message: 'Turf owner registration submitted. Admin approval is required before listing turfs.',
        data: {
          user: sanitizeUser(user),
          ...createAuthTokens(user),
        },
      });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Unable to register turf owner.', error: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required.' });
  }

  try {
    const userResult = await pool.query('SELECT * FROM users WHERE email = $1 LIMIT 1', [email]);

    if (userResult.rowCount === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const user = userResult.rows[0];

    if (!user.password_hash) {
      return res.status(401).json({ success: false, message: 'Account password is not configured.' });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    if (user.status === 'suspended' || user.status === 'deactivated') {
      return res.status(403).json({ success: false, message: 'This account is suspended and cannot log in.' });
    }

    res.json({
      success: true,
      message: 'Login successful.',
      data: {
        user: sanitizeUser(user),
        ...createAuthTokens(user),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Unable to log in.', error: error.message });
  }
});

app.post('/api/auth/refresh', async (req, res) => {
  const refreshToken = String(req.body.refreshToken || '').trim();

  if (!refreshToken) {
    return res.status(400).json({ success: false, message: 'Refresh token is required.' });
  }

  try {
    const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET);

    if (decoded.tokenType !== 'refresh') {
      return res.status(401).json({ success: false, message: 'Invalid refresh token.' });
    }

    const userResult = await pool.query('SELECT * FROM users WHERE id = $1 LIMIT 1', [decoded.sub]);

    if (userResult.rowCount === 0) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }

    const user = userResult.rows[0];

    if (user.status === 'suspended' || user.status === 'deactivated') {
      return res.status(403).json({ success: false, message: 'This account cannot be refreshed.' });
    }

    res.json({
      success: true,
      message: 'Token refreshed successfully.',
      data: {
        user: sanitizeUser(user),
        ...createAuthTokens(user),
      },
    });
  } catch (error) {
    res.status(401).json({ success: false, message: 'Invalid or expired refresh token.', error: error.message });
  }
});

app.post('/api/auth/logout', async (req, res) => {
  res.json({ success: true, message: 'Logout successful.' });
});

app.get('/api/auth/me', requireAuth, async (req, res) => {
  res.json({ success: true, data: { user: req.user } });
});

app.get('/api/turfs', async (req, res) => {
  try {
    const result = await pool.query(
      `
        SELECT
          t.id,
          t.owner_id,
          u.name AS owner_name,
          t.name,
          t.description,
          t.address,
          t.area,
          t.city,
          t.latitude,
          t.longitude,
          t.sport_types,
          t.amenities,
          t.base_price_per_hour,
          t.operating_hours,
          t.status,
          t.rating,
          t.review_count,
          t.created_at,
          COALESCE(
            (
              SELECT json_agg(
                json_build_object(
                  'id', tp.id,
                  'url', tp.url,
                  'sort_order', tp.sort_order
                )
                ORDER BY tp.sort_order
              )
              FROM turf_photos tp
              WHERE tp.turf_id = t.id
            ),
            '[]'::json
          ) AS photos
        FROM turfs t
        LEFT JOIN users u ON u.id = t.owner_id
        ORDER BY t.created_at DESC
        LIMIT 20
      `
    );

    res.json({
      success: true,
      count: result.rowCount,
      data: result.rows.map(normalizeTurf),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Unable to query turfs table',
      error: error.message,
    });
  }
});

const SSLCOMMERZ_SANDBOX_API = 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php';
const SSLCOMMERZ_LIVE_API = 'https://securepay.sslcommerz.com/gwprocess/v4/api.php';
const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:3000';

// Real SSLCommerz session initiation — sandbox or live, using the store credentials
// configured by the admin in the Payment Gateway settings panel.
app.post('/api/payments/sslcommerz/init', async (req, res) => {
  const {
    storeId,
    storePassword,
    isSandbox = true,
    amount,
    currency = 'BDT',
    bookingNumber,
    customerName,
    customerEmail,
    customerPhone,
  } = req.body;

  if (!storeId || !storePassword) {
    return res.status(400).json({ success: false, message: 'SSLCommerz store ID and password are required.' });
  }
  if (!amount || Number(amount) <= 0) {
    return res.status(400).json({ success: false, message: 'A valid payment amount is required.' });
  }

  const apiUrl = isSandbox ? SSLCOMMERZ_SANDBOX_API : SSLCOMMERZ_LIVE_API;
  const tranId = `TS-${bookingNumber || Date.now()}`;
  const serverBaseUrl = `${req.protocol}://${req.get('host')}`;

  const payload = new URLSearchParams({
    store_id: storeId,
    store_passwd: storePassword,
    total_amount: String(amount),
    currency,
    tran_id: tranId,
    success_url: `${serverBaseUrl}/api/payments/sslcommerz/success`,
    fail_url: `${serverBaseUrl}/api/payments/sslcommerz/fail`,
    cancel_url: `${serverBaseUrl}/api/payments/sslcommerz/cancel`,
    cus_name: customerName || 'TurfySlot Player',
    cus_email: customerEmail || 'player@turfyslot.com',
    cus_phone: customerPhone || '01700000000',
    cus_add1: 'Dhaka',
    cus_city: 'Dhaka',
    cus_country: 'Bangladesh',
    shipping_method: 'NO',
    product_name: 'Turf Slot Booking',
    product_category: 'Sports Booking',
    product_profile: 'general',
  });

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: payload.toString(),
    });
    const data = await response.json();

    if (data.status !== 'SUCCESS') {
      return res.status(502).json({ success: false, message: data.failedreason || 'SSLCommerz session initiation failed.' });
    }

    res.json({ success: true, gatewayPageURL: data.GatewayPageURL, tranId, sessionKey: data.sessionkey });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Unable to reach SSLCommerz.', error: error.message });
  }
});

// SSLCommerz posts here after the customer completes/fails/cancels payment on their page.
app.post('/api/payments/sslcommerz/success', (req, res) => {
  const tranId = req.body.tran_id || '';
  res.redirect(`${CLIENT_URL}?payment=success&tran_id=${encodeURIComponent(tranId)}`);
});

app.post('/api/payments/sslcommerz/fail', (req, res) => {
  const tranId = req.body.tran_id || '';
  res.redirect(`${CLIENT_URL}?payment=failed&tran_id=${encodeURIComponent(tranId)}`);
});

app.post('/api/payments/sslcommerz/cancel', (req, res) => {
  const tranId = req.body.tran_id || '';
  res.redirect(`${CLIENT_URL}?payment=cancelled&tran_id=${encodeURIComponent(tranId)}`);
});

// Builds a nodemailer transport from the SMTP settings configured in the Admin panel.
const createSmtpTransport = ({ host, port, secure, username, password }) =>
  nodemailer.createTransport({
    host,
    port: Number(port),
    secure: Boolean(secure), // true for 465 (SSL), false for 587/2525 (STARTTLS)
    auth: { user: username, pass: password },
  });

app.post('/api/email/send-test', async (req, res) => {
  const { host, port, secure, username, password, fromName, fromEmail, toEmail } = req.body;

  if (!host || !port || !username || !password || !fromEmail || !toEmail) {
    return res.status(400).json({ success: false, message: 'SMTP host, port, username, password, from email and recipient are required.' });
  }

  try {
    const transporter = createSmtpTransport({ host, port, secure, username, password });
    await transporter.verify();
    const info = await transporter.sendMail({
      from: `"${fromName || 'TurfySlot'}" <${fromEmail}>`,
      to: toEmail,
      subject: 'TurfySlot SMTP Test Email',
      text: 'This is a test email confirming your TurfySlot SMTP configuration is working correctly.',
      html: '<p>This is a test email confirming your <strong>TurfySlot</strong> SMTP configuration is working correctly.</p>',
    });
    res.json({ success: true, message: 'Test email sent successfully.', messageId: info.messageId });
  } catch (error) {
    res.status(502).json({ success: false, message: 'Failed to send test email.', error: error.message });
  }
});

app.post('/api/email/send', async (req, res) => {
  const { host, port, secure, username, password, fromName, fromEmail, toEmail, subject, html, text } = req.body;

  if (!host || !port || !username || !password || !fromEmail || !toEmail || !subject) {
    return res.status(400).json({ success: false, message: 'SMTP config, recipient and subject are required.' });
  }

  try {
    const transporter = createSmtpTransport({ host, port, secure, username, password });
    const info = await transporter.sendMail({
      from: `"${fromName || 'TurfySlot'}" <${fromEmail}>`,
      to: toEmail,
      subject,
      text: text || '',
      html: html || text || '',
    });
    res.json({ success: true, message: 'Email sent successfully.', messageId: info.messageId });
  } catch (error) {
    res.status(502).json({ success: false, message: 'Failed to send email.', error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Turfyslot server running on http://localhost:${PORT}`);
});
